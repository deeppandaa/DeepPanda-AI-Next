"""Simple, guided support home for first-time operators."""

from __future__ import annotations

import json
import sys
import threading
from datetime import datetime
from tkinter import messagebox

import customtkinter as ctk

from services.it_operations_service import ITOperationsService
from services.large_transfer_service import get_shared_large_transfer_service
from services.communication_session_service import get_shared_communication_service
from services.log_service import LogService
from services.remote_support_registry import get_shared_remote_support_service
from services.support_automation_service import SupportAutomationService
from services.support_recovery_service import SupportRecoveryService
from services.tls_certificate_service import TLSCertificateService
from services.screen_remote_service import get_shared_screen_remote_service


class GuidedSupportView(ctk.CTkFrame):
    BG = "#202A35"
    BAND = "#273544"
    TEXT = "#F2F5F7"
    MUTED = "#AEB9C4"

    def __init__(self, parent, open_advanced, open_capsules):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.open_advanced = open_advanced
        self.open_capsules = open_capsules
        self.support = get_shared_remote_support_service()
        self.automation = SupportAutomationService()
        self.recovery = SupportRecoveryService()
        self.large_transfers = get_shared_large_transfer_service()
        self.screen_remote = get_shared_screen_remote_service()
        self.communication = get_shared_communication_service()
        self.pending_transfer_id = ""
        self.pending_transfer_state = ""
        self.pending_screen_request_id = ""
        self.pending_meeting_request_id = ""
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(6, weight=1)
        self._build_ui()
        self.after(1000, self._poll_transfer_requests)
        self.after(1200, self._poll_collaboration_requests)

    def _build_ui(self):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=22, pady=(20, 10), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Hizli Destek",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=self.TEXT,
        ).grid(row=0, column=0, sticky="w")
        self.status = ctk.CTkLabel(
            header,
            text="Hazir",
            fg_color="#245F3A",
            corner_radius=6,
            padx=12,
            pady=6,
            text_color=self.TEXT,
        )
        self.status.grid(row=0, column=1, sticky="e")

        intro = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        intro.grid(row=1, column=0, padx=22, pady=8, sticky="ew")
        ctk.CTkLabel(
            intro,
            text="Ne yapmak istiyorsunuz?",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=16, pady=(14, 4))
        ctk.CTkLabel(
            intro,
            text="Sorunu bilmiyorsaniz once guvenli taniyi calistirin. Program veya ayar degisecekse Onarim Kapsulu kullanin.",
            text_color=self.MUTED,
            wraplength=900,
            justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 14))

        actions = ctk.CTkFrame(self, fg_color="transparent")
        actions.grid(row=2, column=0, padx=22, pady=8, sticky="ew")
        actions.grid_columnconfigure((0, 1, 2), weight=1, uniform="quick")
        self._action(
            actions,
            0,
            "1. Guvenli Tani",
            "Sistemi degistirmeden ag, driver, olay ve surec kontrolu yapar.",
            "Tek Tus Taniyi Baslat",
            self._confirm_one_click_diagnostic,
            "#2E7D32",
        )
        self._action(
            actions,
            1,
            "2. Kontrollu Onarim",
            "On kontrol, imza, uygulama ve otomatik geri alma ile islem yapar.",
            "Onarim Kapsullerini Ac",
            self.open_capsules,
            "#6A1B9A",
        )
        self._action(
            actions,
            2,
            "3. Gelismis Destek",
            "Paket, registry, komut ve uzak bilgisayar araclarini gosterir.",
            "Gelismis Paneli Ac",
            self.open_advanced,
            "#355C7D",
        )

        connection = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        connection.grid(row=3, column=0, padx=22, pady=8, sticky="ew")
        ctk.CTkLabel(
            connection,
            text="Android baglantisi",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=16, pady=(12, 4))
        self.connection_info_label = ctk.CTkLabel(
            connection,
            text=(
                "Android'de PC IP adresi, port 5000 ve Ayarlar > Uzak Erisim Hesabi bilgilerini girin. "
                f"TLS parmak izi: {TLSCertificateService.formatted_fingerprint()}"
            ),
            text_color=self.MUTED,
            font=("Consolas", 10),
            wraplength=950,
            justify="left",
        )
        self.connection_info_label.pack(anchor="w", padx=16, pady=(0, 8))
        ctk.CTkButton(
            connection,
            text="WAN Baglantisini Kontrol Et",
            width=190,
            command=self._check_wan_readiness,
        ).pack(anchor="w", padx=16, pady=(0, 12))
        ctk.CTkButton(
            connection,
            text="Tailscale Girisini Ac",
            width=190,
            fg_color="#355C7D",
            command=self._start_tailscale_login,
        ).pack(anchor="w", padx=16, pady=(0, 12))

        transfer = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        transfer.grid(row=4, column=0, padx=22, pady=8, sticky="ew")
        transfer.grid_columnconfigure(0, weight=1)
        self.transfer_request_label = ctk.CTkLabel(
            transfer,
            text="Bekleyen dosya aktarim istegi yok.",
            text_color=self.MUTED,
            justify="left",
        )
        self.transfer_request_label.grid(row=0, column=0, padx=16, pady=12, sticky="w")
        self.transfer_destination_menu = ctk.CTkOptionMenu(
            transfer,
            values=["inbox", "downloads", "desktop", "documents"],
            width=130,
        )
        self.transfer_destination_menu.set("inbox")
        self.transfer_destination_menu.grid(row=0, column=1, padx=6, pady=12)
        self.accept_transfer_button = ctk.CTkButton(
            transfer,
            text="Kabul Et",
            width=90,
            fg_color="#2E7D32",
            state="disabled",
            command=self._approve_transfer,
        )
        self.accept_transfer_button.grid(row=0, column=2, padx=6, pady=12)
        self.deny_transfer_button = ctk.CTkButton(
            transfer,
            text="Reddet",
            width=80,
            fg_color="#7A2635",
            state="disabled",
            command=self._deny_transfer,
        )
        self.deny_transfer_button.grid(row=0, column=3, padx=(6, 16), pady=12)

        collaboration = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        collaboration.grid(row=5, column=0, padx=22, pady=8, sticky="ew")
        collaboration.grid_columnconfigure(0, weight=1)
        self.collaboration_label = ctk.CTkLabel(
            collaboration,
            text="Bekleyen ekran veya gorusme istegi yok.",
            text_color=self.MUTED,
            justify="left",
        )
        self.collaboration_label.grid(row=0, column=0, padx=16, pady=12, sticky="w")
        self.view_only_button = ctk.CTkButton(
            collaboration,
            text="Sadece Goruntu",
            width=110,
            state="disabled",
            command=lambda: self._approve_screen(False),
        )
        self.view_only_button.grid(row=0, column=1, padx=5, pady=12)
        self.full_control_button = ctk.CTkButton(
            collaboration,
            text="Fare + Klavye",
            width=110,
            fg_color="#8A5A00",
            state="disabled",
            command=lambda: self._approve_screen(True),
        )
        self.full_control_button.grid(row=0, column=2, padx=5, pady=12)
        self.meeting_accept_button = ctk.CTkButton(
            collaboration,
            text="Gorusmeyi Kabul Et",
            width=130,
            fg_color="#2E7D32",
            state="disabled",
            command=self._approve_meeting,
        )
        self.meeting_accept_button.grid(row=0, column=3, padx=5, pady=12)
        self.collaboration_deny_button = ctk.CTkButton(
            collaboration,
            text="Reddet / Kes",
            width=95,
            fg_color="#7A2635",
            state="disabled",
            command=self._deny_or_revoke_collaboration,
        )
        self.collaboration_deny_button.grid(row=0, column=4, padx=(5, 16), pady=12)

        self.output = ctk.CTkTextbox(
            self,
            fg_color="#111820",
            text_color=self.TEXT,
            font=("Consolas", 11),
            wrap="word",
        )
        self.output.grid(row=6, column=0, padx=22, pady=(8, 20), sticky="nsew")
        self.output.insert("1.0", "Sonuclar burada gorunecek.\n")

    def _action(self, parent, column, title, description, button_text, command, color):
        section = ctk.CTkFrame(parent, fg_color=self.BAND, corner_radius=6)
        section.grid(row=0, column=column, padx=6, sticky="nsew")
        ctk.CTkLabel(
            section,
            text=title,
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=14, pady=(14, 5))
        ctk.CTkLabel(
            section,
            text=description,
            text_color=self.MUTED,
            wraplength=270,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 12))
        ctk.CTkButton(section, text=button_text, fg_color=color, command=command).pack(
            fill="x", padx=14, pady=(0, 14)
        )

    def _confirm_one_click_diagnostic(self):
        if not messagebox.askyesno(
            "Guvenli tani",
            "Sistem degistirilmeden otomatik tani ve dry-run raporu olusturulsun mu?",
            parent=self.winfo_toplevel(),
        ):
            return
        self.status.configure(text="Tani calisiyor", fg_color="#8A5A00")

        def worker():
            try:
                session = self.support.create_session_request(
                    "LOCAL-QUICK",
                    "Vana RescueOps",
                    "Tek tus guvenli tani",
                    ttl_seconds=900,
                )
                self.support.approve_session(session["session_id"], session["one_time_code"])
                apps = self.automation.scan_closable_apps()
                process_preview = self.automation.close_apps(apps, dry_run=True)
                recovery = self.recovery.run_recovery_cycle(
                    python_executable=sys.executable,
                    dry_run=True,
                    mode="one-click-safe",
                    write_report=True,
                )
                network = ITOperationsService.network_diagnostics("1.1.1.1")
                events = ITOperationsService.recent_errors(10)
                result = {
                    "session_id": session["session_id"],
                    "mode": "safe-dry-run",
                    "process_preview": process_preview,
                    "recovery": recovery,
                    "network": network,
                    "recent_events": events.get("events", []),
                }
                report_path = self._write_combined_report(result)
                result["combined_report"] = report_path
                self.after(0, lambda: self._finish(result))
            except Exception as exc:
                self.after(0, lambda: self._fail(str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def _check_wan_readiness(self):
        result = ITOperationsService.wan_readiness()
        vpn_ip = str(result.get("vpn_ip", ""))
        suffix = f" Android Host: {vpn_ip}, Port: 5000." if vpn_ip else ""
        self.connection_info_label.configure(
            text=f"{result.get('message', 'WAN durumu alinamadi.')}{suffix}\nTLS: {TLSCertificateService.formatted_fingerprint()}",
            text_color="#86B6A3" if result.get("ready") else "#D5B36A",
        )

    def _start_tailscale_login(self):
        result = ITOperationsService.start_tailscale_login()
        self.connection_info_label.configure(
            text=str(result.get("message", "Tailscale giris durumu alinamadi.")),
            text_color="#86B6A3" if result.get("status") == "success" else "#D98282",
        )

    @staticmethod
    def _write_combined_report(result: dict) -> str:
        export_dir = SupportRecoveryService.EXPORT_DIR
        export_dir.mkdir(parents=True, exist_ok=True)
        path = export_dir / f"one_click_diagnostic_{datetime.now():%Y%m%d_%H%M%S}.json"
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return str(path)

    def _finish(self, result):
        self.status.configure(text="Tani tamamlandi", fg_color="#245F3A")
        self.output.delete("1.0", "end")
        self.output.insert("end", json.dumps(result, ensure_ascii=False, indent=2, default=str))
        LogService.add_log("INFO", "Tek tus guvenli tani tamamlandi.", "Hizli Destek")

    def _fail(self, message):
        self.status.configure(text="Tani basarisiz", fg_color="#7A2635")
        self.output.insert("end", f"\nHATA: {message}\n")
        LogService.add_log("ERROR", message, "Hizli Destek")

    @staticmethod
    def _format_bytes(value: int) -> str:
        size = float(value)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024 or unit == "TB":
                return f"{size:.2f} {unit}"
            size /= 1024
        return f"{size:.2f} TB"

    def _poll_transfer_requests(self):
        try:
            pending = sorted(
                self.large_transfers.pending(),
                key=lambda row: float(row.get("created_at", 0)),
            )
            if pending:
                request = pending[0]
                self.pending_transfer_id = str(request["transfer_id"])
                self.pending_transfer_state = "pending_approval"
                requested = str(request.get("requested_destination", "inbox"))
                self.transfer_destination_menu.set(requested)
                destinations = self.large_transfers.destinations(int(request["total_size"]))
                selected = next((item for item in destinations if item["key"] == requested), None)
                free_text = self._format_bytes(int(selected["free_bytes"])) if selected else "bilinmiyor"
                self.transfer_request_label.configure(
                    text=(
                        f"{request['requester']} dosya gondermek istiyor: {request['file_name']}\n"
                        f"Boyut: {self._format_bytes(int(request['total_size']))} | "
                        f"Secili hedef bos alani: {free_text}"
                    ),
                    text_color=self.TEXT,
                )
                self.accept_transfer_button.configure(state="normal")
                self.deny_transfer_button.configure(text="Reddet", state="normal")
            else:
                active = sorted(
                    [
                        row for row in self.large_transfers.list_transfers()
                        if row.get("status") in {"approved", "transferring", "paused", "verifying"}
                    ],
                    key=lambda row: float(row.get("created_at", 0)),
                    reverse=True,
                )
                if active:
                    row = active[0]
                    self.pending_transfer_id = str(row["transfer_id"])
                    self.pending_transfer_state = str(row["status"])
                    status = self.large_transfers.status(self.pending_transfer_id)["transfer"]
                    rate = self._format_bytes(int(status.get("average_bytes_per_second", 0))) + "/sn"
                    eta_seconds = status.get("eta_seconds")
                    eta = self._format_duration(int(eta_seconds)) if eta_seconds is not None else "hesaplaniyor"
                    self.transfer_request_label.configure(
                        text=(
                            f"{status['file_name']} | {status['status']} | %{status['progress_percent']}\n"
                            f"{self._format_bytes(int(status['bytes_received']))} / "
                            f"{self._format_bytes(int(status['total_size']))} | Hiz: {rate} | Kalan: {eta}"
                        ),
                        text_color=self.TEXT,
                    )
                    self.accept_transfer_button.configure(state="disabled")
                    self.deny_transfer_button.configure(text="Iptal Et", state="normal")
                else:
                    self.pending_transfer_id = ""
                    self.pending_transfer_state = ""
                    self.transfer_request_label.configure(
                        text="Bekleyen dosya aktarim istegi yok.", text_color=self.MUTED
                    )
                    self.accept_transfer_button.configure(state="disabled")
                    self.deny_transfer_button.configure(text="Reddet", state="disabled")
        finally:
            self.after(2000, self._poll_transfer_requests)

    def _approve_transfer(self):
        if not self.pending_transfer_id:
            return
        destination = self.transfer_destination_menu.get()
        if not messagebox.askyesno(
            "Dosya aktarimini kabul et",
            f"Dosya '{destination}' hedefine kaydedilsin mi? Bos alan yeniden kontrol edilecek.",
            parent=self.winfo_toplevel(),
        ):
            return
        result = self.large_transfers.approve(self.pending_transfer_id, destination)
        if result.get("status") == "success":
            self.output.insert("end", f"\nAktarim kabul edildi: {result['transfer']['final_path']}\n")
        else:
            messagebox.showerror("Aktarim kabul edilemedi", str(result.get("message", "Hata")))

    @staticmethod
    def _format_duration(seconds: int) -> str:
        seconds = max(0, int(seconds))
        days, remainder = divmod(seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, _seconds = divmod(remainder, 60)
        if days:
            return f"{days} gun {hours} saat"
        if hours:
            return f"{hours} saat {minutes} dk"
        return f"{minutes} dk"

    def _deny_transfer(self):
        if not self.pending_transfer_id:
            return
        if self.pending_transfer_state == "pending_approval":
            result = self.large_transfers.deny(self.pending_transfer_id)
        else:
            if not messagebox.askyesno(
                "Aktarimi iptal et",
                "Kismi dosya silinsin ve aktarim tamamen iptal edilsin mi?",
                parent=self.winfo_toplevel(),
            ):
                return
            result = self.large_transfers.abort(self.pending_transfer_id, delete_partial=True)
        self.output.insert("end", f"\n{result.get('message', 'Aktarim reddedildi.')}\n")

    def _poll_collaboration_requests(self):
        try:
            screen_pending = self.screen_remote.pending_requests()
            meeting_pending = self.communication.pending_requests()
            if screen_pending:
                request = screen_pending[0]
                self.pending_screen_request_id = str(request["request_id"])
                mode = "goruntu + fare/klavye" if request.get("allow_control_requested") else "sadece goruntu"
                self.collaboration_label.configure(
                    text=f"{request['requester']} ekran erisimi istiyor: {mode}",
                    text_color=self.TEXT,
                )
                self.view_only_button.configure(state="normal")
                self.full_control_button.configure(
                    state="normal" if request.get("allow_control_requested") else "disabled"
                )
                self.meeting_accept_button.configure(state="disabled")
                self.collaboration_deny_button.configure(state="normal")
            elif meeting_pending:
                request = meeting_pending[0]
                self.pending_meeting_request_id = str(request["request_id"])
                mode = "sesli ve goruntulu" if request.get("video") else "sesli"
                self.collaboration_label.configure(
                    text=f"{request['requester']} {mode} gorusme istiyor.",
                    text_color=self.TEXT,
                )
                self.view_only_button.configure(state="disabled")
                self.full_control_button.configure(state="disabled")
                self.meeting_accept_button.configure(state="normal")
                self.collaboration_deny_button.configure(state="normal")
            else:
                approved = self.screen_remote.approved_requests()
                if approved:
                    request = approved[-1]
                    self.pending_screen_request_id = str(request["request_id"])
                    mode = "Fare + klavye acik" if request.get("allow_control") else "Sadece goruntu"
                    self.collaboration_label.configure(
                        text=f"Aktif ekran erisimi: {request['requester']} | {mode}",
                        text_color="#86B6A3",
                    )
                    self.view_only_button.configure(state="disabled")
                    self.full_control_button.configure(state="disabled")
                    self.meeting_accept_button.configure(state="disabled")
                    self.collaboration_deny_button.configure(state="normal")
                else:
                    self.pending_screen_request_id = ""
                    self.pending_meeting_request_id = ""
                    self.collaboration_label.configure(
                        text="Bekleyen ekran veya gorusme istegi yok.", text_color=self.MUTED
                    )
                    self.view_only_button.configure(state="disabled")
                    self.full_control_button.configure(state="disabled")
                    self.meeting_accept_button.configure(state="disabled")
                    self.collaboration_deny_button.configure(state="disabled")
        finally:
            self.after(1500, self._poll_collaboration_requests)

    def _approve_screen(self, allow_control: bool):
        if not self.pending_screen_request_id:
            return
        message = (
            "Uzak kullanici ekraninizi gorecek ve fare/klavyeyi kontrol edecek. Onayliyor musunuz?"
            if allow_control
            else "Uzak kullanici ekraninizi sadece gorecek. Onayliyor musunuz?"
        )
        if not messagebox.askyesno("Ekran erisimi", message, parent=self.winfo_toplevel()):
            return
        result = self.screen_remote.approve(self.pending_screen_request_id, allow_control)
        self.output.insert("end", f"\n{result.get('message', '')}\n")

    def _approve_meeting(self):
        if not self.pending_meeting_request_id:
            return
        if not messagebox.askyesno(
            "Sesli/goruntulu gorusme",
            "Mikrofon ve kamera izinleri tarayicida sorulacak. Gorusme acilsin mi?",
            parent=self.winfo_toplevel(),
        ):
            return
        result = self.communication.approve(self.pending_meeting_request_id, open_local=True)
        self.output.insert("end", f"\n{result.get('message', '')}\n")

    def _deny_or_revoke_collaboration(self):
        if self.pending_screen_request_id:
            status = self.screen_remote.request_status(self.pending_screen_request_id)
            request = status.get("request", {})
            result = (
                self.screen_remote.revoke(self.pending_screen_request_id)
                if request.get("status") == "approved"
                else self.screen_remote.deny(self.pending_screen_request_id)
            )
        elif self.pending_meeting_request_id:
            result = self.communication.deny(self.pending_meeting_request_id)
        else:
            return
        self.output.insert("end", f"\n{result.get('message', '')}\n")
