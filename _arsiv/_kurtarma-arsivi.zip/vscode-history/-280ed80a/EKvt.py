"""Simple, guided support home for first-time operators."""

from __future__ import annotations

import json
import sys
import threading
from datetime import datetime
from tkinter import messagebox

import customtkinter as ctk

from services.it_operations_service import ITOperationsService
from services.log_service import LogService
from services.remote_support_registry import get_shared_remote_support_service
from services.support_automation_service import SupportAutomationService
from services.support_recovery_service import SupportRecoveryService
from services.tls_certificate_service import TLSCertificateService


class GuidedSupportView(ctk.CTkFrame):
    BG = "#202A35"
    BAND = "#273544"
    TEXT = "#F2F5F7"
    MUTED = "#AEB9C4"

    def __init__(self, parent, open_advanced, open_capsules):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.open_advanced = open_advanced
        self.open_capsules = open_capsules
        self.support = get_shared_remote_support_service()
        self.automation = SupportAutomationService()
        self.recovery = SupportRecoveryService()
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)
        self._build_ui()

    def _build_ui(self):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=22, pady=(20, 10), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Hizli Destek",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=self.TEXT,
        ).grid(row=0, column=0, sticky="w")
        self.status = ctk.CTkLabel(
            header,
            text="Hazir",
            fg_color="#245F3A",
            corner_radius=6,
            padx=12,
            pady=6,
            text_color=self.TEXT,
        )
        self.status.grid(row=0, column=1, sticky="e")

        intro = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        intro.grid(row=1, column=0, padx=22, pady=8, sticky="ew")
        ctk.CTkLabel(
            intro,
            text="Ne yapmak istiyorsunuz?",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=16, pady=(14, 4))
        ctk.CTkLabel(
            intro,
            text="Sorunu bilmiyorsaniz once guvenli taniyi calistirin. Program veya ayar degisecekse Onarim Kapsulu kullanin.",
            text_color=self.MUTED,
            wraplength=900,
            justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 14))

        actions = ctk.CTkFrame(self, fg_color="transparent")
        actions.grid(row=2, column=0, padx=22, pady=8, sticky="ew")
        actions.grid_columnconfigure((0, 1, 2), weight=1, uniform="quick")
        self._action(
            actions,
            0,
            "1. Guvenli Tani",
            "Sistemi degistirmeden ag, driver, olay ve surec kontrolu yapar.",
            "Tek Tus Taniyi Baslat",
            self._confirm_one_click_diagnostic,
            "#2E7D32",
        )
        self._action(
            actions,
            1,
            "2. Kontrollu Onarim",
            "On kontrol, imza, uygulama ve otomatik geri alma ile islem yapar.",
            "Onarim Kapsullerini Ac",
            self.open_capsules,
            "#6A1B9A",
        )
        self._action(
            actions,
            2,
            "3. Gelismis Destek",
            "Paket, registry, komut ve uzak bilgisayar araclarini gosterir.",
            "Gelismis Paneli Ac",
            self.open_advanced,
            "#355C7D",
        )

        connection = ctk.CTkFrame(self, fg_color=self.BAND, corner_radius=6)
        connection.grid(row=3, column=0, padx=22, pady=8, sticky="ew")
        ctk.CTkLabel(
            connection,
            text="Android baglantisi",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=16, pady=(12, 4))
        ctk.CTkLabel(
            connection,
            text=(
                "Android'de PC IP adresi, port 5000 ve Ayarlar > Uzak Erisim Hesabi bilgilerini girin. "
                f"TLS parmak izi: {TLSCertificateService.formatted_fingerprint()}"
            ),
            text_color=self.MUTED,
            font=("Consolas", 10),
            wraplength=950,
            justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 12))

        self.output = ctk.CTkTextbox(
            self,
            fg_color="#111820",
            text_color=self.TEXT,
            font=("Consolas", 11),
            wrap="word",
        )
        self.output.grid(row=4, column=0, padx=22, pady=(8, 20), sticky="nsew")
        self.output.insert("1.0", "Sonuclar burada gorunecek.\n")

    def _action(self, parent, column, title, description, button_text, command, color):
        section = ctk.CTkFrame(parent, fg_color=self.BAND, corner_radius=6)
        section.grid(row=0, column=column, padx=6, sticky="nsew")
        ctk.CTkLabel(
            section,
            text=title,
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=self.TEXT,
        ).pack(anchor="w", padx=14, pady=(14, 5))
        ctk.CTkLabel(
            section,
            text=description,
            text_color=self.MUTED,
            wraplength=270,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 12))
        ctk.CTkButton(section, text=button_text, fg_color=color, command=command).pack(
            fill="x", padx=14, pady=(0, 14)
        )

    def _confirm_one_click_diagnostic(self):
        if not messagebox.askyesno(
            "Guvenli tani",
            "Sistem degistirilmeden otomatik tani ve dry-run raporu olusturulsun mu?",
            parent=self.winfo_toplevel(),
        ):
            return
        self.status.configure(text="Tani calisiyor", fg_color="#8A5A00")

        def worker():
            try:
                session = self.support.create_session_request(
                    "LOCAL-QUICK",
                    "Vana RescueOps",
                    "Tek tus guvenli tani",
                    ttl_seconds=900,
                )
                self.support.approve_session(session["session_id"], session["one_time_code"])
                apps = self.automation.scan_closable_apps()
                process_preview = self.automation.close_apps(apps, dry_run=True)
                recovery = self.recovery.run_recovery_cycle(
                    python_executable=sys.executable,
                    dry_run=True,
                    mode="one-click-safe",
                    write_report=True,
                )
                network = ITOperationsService.network_diagnostics("1.1.1.1")
                events = ITOperationsService.recent_errors(10)
                result = {
                    "session_id": session["session_id"],
                    "mode": "safe-dry-run",
                    "process_preview": process_preview,
                    "recovery": recovery,
                    "network": network,
                    "recent_events": events.get("events", []),
                }
                report_path = self._write_combined_report(result)
                result["combined_report"] = report_path
                self.after(0, lambda: self._finish(result))
            except Exception as exc:
                self.after(0, lambda: self._fail(str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    @staticmethod
    def _write_combined_report(result: dict) -> str:
        export_dir = SupportRecoveryService.EXPORT_DIR
        export_dir.mkdir(parents=True, exist_ok=True)
        path = export_dir / f"one_click_diagnostic_{datetime.now():%Y%m%d_%H%M%S}.json"
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return str(path)

    def _finish(self, result):
        self.status.configure(text="Tani tamamlandi", fg_color="#245F3A")
        self.output.delete("1.0", "end")
        self.output.insert("end", json.dumps(result, ensure_ascii=False, indent=2, default=str))
        LogService.add_log("INFO", "Tek tus guvenli tani tamamlandi.", "Hizli Destek")

    def _fail(self, message):
        self.status.configure(text="Tani basarisiz", fg_color="#7A2635")
        self.output.insert("end", f"\nHATA: {message}\n")
        LogService.add_log("ERROR", message, "Hizli Destek")
