import unittest

from services.app_settings_service import AppSettingsService


class AIRuntimeLifecycleTests(unittest.TestCase):
    def test_local_ai_autostart_is_disabled_by_default(self):
        self.assertFalse(AppSettingsService.DEFAULTS["ai_local_autostart"])

    def test_ollama_backend_is_not_started_by_desktop_autostart_setting(self):
        settings = dict(AppSettingsService.DEFAULTS)
        settings.update({"ai_local_autostart": True, "ai_local_backend": "ollama"})
        self.assertTrue(settings["ai_local_autostart"])
        self.assertEqual("ollama", settings["ai_local_backend"])
        # The desktop lifecycle owns llama.cpp only; Ollama remains externally managed.


if __name__ == "__main__":
    unittest.main()