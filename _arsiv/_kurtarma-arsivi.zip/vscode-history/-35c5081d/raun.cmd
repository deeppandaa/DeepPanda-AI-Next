@echo off
for %%I in ("%~dp0..") do set "AI_ROOT=%%~fI"
for /f "delims=" %%P in ('wsl.exe -d Ubuntu -- wslpath -a "%AI_ROOT%"') do set "WSL_ROOT=%%P"
if not defined WSL_ROOT exit /b 1
wsl.exe -d Ubuntu --cd "%WSL_ROOT%" -- bash -lc "./.venv-wsl-kt/bin/python training/split_dataset.py && ./training/run_lora_wsl.sh --dataset training/splits/train.jsonl --output AI-Runtimes/models/localqwen-offline-lora-v3"
pause
