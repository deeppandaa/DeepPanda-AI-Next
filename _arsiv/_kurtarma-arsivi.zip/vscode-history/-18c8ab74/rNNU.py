"""
SystemCore v2 - Ana Pencere (GUI Yönetimi)
"""

import customtkinter as ctk
from typing import Optional, Dict

from gui.dashboard import DashboardView
from gui.settings_panel import SettingsPanel
from gui.security_view import SecurityView
from gui.log_view import LogView
from gui.serial_view import SerialView
from gui.driver_view import DriverView
from gui.sound_view import SoundView
from gui.advanced_system_view import AdvancedSystemView
from gui.remote_support_view import RemoteSupportView
from gui.it_operations_view import ITOperationsView
from gui.repair_capsule_view import RepairCapsuleView
from services.hardware_monitor import HardwareMonitor
from services.app_settings_service import AppSettingsService
from core.lan_remote import LANRemoteServer


class MainWindow:
    PRIMARY = "#4F8CC9"
    SIDEBAR_BG = "#17202B"
    MAIN_BG = "#202A35"
    TEXT_PRIMARY = "#F2F5F7"
    TEXT_SECONDARY = "#AEB9C4"
    ACTIVE_BTN_BG = "#2B4055"

    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("SystemCore v2")
        self.root.geometry("1280x760")
        self.root.configure(fg_color=self.MAIN_BG)

        # Servisler
        self.monitor = HardwareMonitor()
        self.current_view: Optional[object] = None
        self.nav_buttons: Dict[str, ctk.CTkButton] = {}

        # LAN Uzak Yönetim Sunucusunu Başlat
        self.lan_server = LANRemoteServer()
        try:
            self.lan_server.start()
        except Exception as e:
            print(f"[LAN Server Error]: {e}")

        # Pencere kapatma olayını yakala (Graceful Shutdown)
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        self._setup_ui()
        self.root.after(50, self._present_window)

        # Varsayılan ekranı yükle ve izleme döngüsünü başlat
        self._show_dashboard()
        self._start_monitoring_loop()

    def _present_window(self):
        """Bring the main window to the foreground on startup."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            self.root.attributes("-topmost", True)
            self.root.after(250, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def _setup_ui(self):
        self.root.grid_columnconfigure(0, weight=0)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_content_area()

    def _build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self.root, fg_color=self.SIDEBAR_BG, width=220, corner_radius=6)
        self.sidebar.grid(row=0, column=0, sticky="ns", pady=12, padx=(12, 6))
        self.sidebar.grid_propagate(False)

        title = ctk.CTkLabel(
            self.sidebar,
            text="SYSTEMCORE",
            font=ctk.CTkFont(size=17, weight="bold"),
            fg_color="#243548",
            text_color=self.TEXT_PRIMARY,
            corner_radius=5,
            padx=15,
            pady=10,
        )
        title.pack(pady=(15, 10), fill="x", padx=10)

        nav_items = [
            ("dashboard", "Genel Bakış", self._show_dashboard),
            ("settings", "Ayarlar", self._show_settings),
            ("security", "Güvenlik", self._show_security),
            ("logs", "Loglar", self._show_logs),
            ("serial", "Seri Port", self._show_serial),
            ("drivers", "Sürücüler ve GPU", self._show_drivers),
            ("sound", "Ses Cihazları", self._show_sound),
            ("advanced", "Araç Paketi", self._show_advanced_system),
            ("support", "Teknik Servis", self._show_remote_support),
            ("it", "IT Operasyon", self._show_it_operations),
            ("capsules", "Onarim Kapsulleri", self._show_repair_capsules),
        ]

        for key, label_text, callback in nav_items:
            btn = ctk.CTkButton(
                self.sidebar,
                text=label_text,
                font=ctk.CTkFont(size=15),
                fg_color="transparent",
                text_color=self.TEXT_SECONDARY,
                hover_color="#223244",
                corner_radius=5,
                height=40,
                anchor="w",
                command=callback,
            )
            btn.pack(pady=(0, 4), fill="x", padx=15)
            self.nav_buttons[key] = btn

    def _setActive_button(self, active_key: str):
        """Aktif sekmeyi görsel olarak vurgular."""
        for key, btn in self.nav_buttons.items():
            if key == active_key:
                btn.configure(fg_color=self.ACTIVE_BTN_BG, text_color=self.PRIMARY)
            else:
                btn.configure(fg_color="transparent", text_color=self.TEXT_SECONDARY)

    def _build_content_area(self):
        self.content_frame = ctk.CTkFrame(self.root, fg_color=self.MAIN_BG, corner_radius=6)
        self.content_frame.grid(row=0, column=1, sticky="nsew", pady=12, padx=(6, 12))
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)

    def _clear_content(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.current_view = None

    def _show_dashboard(self):
        self._clear_content()
        self._setActive_button("dashboard")
        self.current_view = DashboardView(parent=self.content_frame)

    def _show_settings(self):
        self._clear_content()
        self._setActive_button("settings")
        self.current_view = SettingsPanel(parent=self.content_frame)

    def _show_security(self):
        self._clear_content()
        self._setActive_button("security")
        self.current_view = SecurityView(parent=self.content_frame)

    def _show_logs(self):
        self._clear_content()
        self._setActive_button("logs")
        self.current_view = LogView(parent=self.content_frame)

    def _show_serial(self):
        self._clear_content()
        self._setActive_button("serial")
        self.current_view = SerialView(parent=self.content_frame)

    def _show_drivers(self):
        self._clear_content()
        self._setActive_button("drivers")
        self.current_view = DriverView(parent=self.content_frame)

    def _show_sound(self):
        self._clear_content()
        self._setActive_button("sound")
        self.current_view = SoundView(parent=self.content_frame)

    def _show_advanced_system(self):
        self._clear_content()
        self._setActive_button("advanced")
        self.current_view = AdvancedSystemView(parent=self.content_frame)

    def _show_remote_support(self):
        self._clear_content()
        self._setActive_button("support")
        self.current_view = RemoteSupportView(parent=self.content_frame)

    def _show_it_operations(self):
        self._clear_content()
        self._setActive_button("it")
        self.current_view = ITOperationsView(parent=self.content_frame)

    def _show_repair_capsules(self):
        self._clear_content()
        self._setActive_button("capsules")
        self.current_view = RepairCapsuleView(parent=self.content_frame)

    def _start_monitoring_loop(self):
        # Sadece Dashboard açıkken donanım metriklerini güncelle
        if isinstance(self.current_view, DashboardView):
            try:
                cpu_data = self.monitor.get_cpu_info()
                ram_data = self.monitor.get_ram_info()
                disk_data = self.monitor.get_disk_info()
                net_data = getattr(self.monitor, "get_network_info", lambda: None)()

                if hasattr(self.current_view, "update_metrics"):
                    self.current_view.update_metrics(
                        cpu=cpu_data, ram=ram_data, disks=disk_data, net=net_data
                    )
            except Exception as e:
                print(f"[Monitoring Error]: {e}")

        # Döngüyü devam ettir (ayar panelindeki yenileme aralığını kullan)
        interval_sec = float(AppSettingsService.load().get("refresh_interval", 1.5))
        interval_ms = max(500, int(interval_sec * 1000))
        self.root.after(interval_ms, self._start_monitoring_loop)

    def _on_closing(self):
        """Uygulama kapatılırken arka plan servislerini temizler."""
        print("[SystemCore] Kapatılıyor...")
        try:
            if hasattr(self.lan_server, "stop"):
                self.lan_server.stop()
        except Exception as e:
            print(f"[Shutdown Error]: {e}")
        
        self.root.destroy()

    def run(self):
        self.root.mainloop()