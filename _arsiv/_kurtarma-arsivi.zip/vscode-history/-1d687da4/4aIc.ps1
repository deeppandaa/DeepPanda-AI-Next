$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Venv = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'
$ModelStore = Join-Path $Root 'AI-Runtimes\OllamaModels'
$MemoryRoot = Join-Path $Root 'data\memory'
$PackageRoot = Join-Path $Root 'packages'
$OllamaRoot = Join-Path $PackageRoot 'ollama'
$OllamaExe = Join-Path $OllamaRoot 'ollama.exe'
$BrowserRoot = Join-Path $PackageRoot 'playwright-browsers'
$CacheRoot = Join-Path $PackageRoot 'cache'
$PipCache = Join-Path $PackageRoot 'pip-cache'

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw 'Python Launcher (py) bulunamadi. Python 3.12+ kurun ve tekrar deneyin.'
}

if (-not (Test-Path $Python)) {
    & py -3 -m venv $Venv
}

$env:PIP_CACHE_DIR = $PipCache
$env:PLAYWRIGHT_BROWSERS_PATH = $BrowserRoot
$env:HF_HOME = Join-Path $CacheRoot 'huggingface'
$env:TORCH_HOME = Join-Path $CacheRoot 'torch'
New-Item -ItemType Directory -Force -Path $MemoryRoot,$ModelStore,$BrowserRoot,$env:HF_HOME,$env:TORCH_HOME,$PipCache | Out-Null

& $Python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip guncellenemedi.' }
& $Python -m pip install -r (Join-Path $Root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Python paketleri kurulamadi.' }
& $Python -m playwright install chromium
if ($LASTEXITCODE -ne 0) { throw 'Playwright Chromium kurulamadi.' }

[Environment]::SetEnvironmentVariable('OLLAMA_MODELS', $ModelStore, 'User')
if (-not (Test-Path $OllamaExe)) {
    $InstalledOllama = Get-Command ollama -ErrorAction SilentlyContinue
    if ($InstalledOllama) {
        New-Item -ItemType Directory -Force -Path $OllamaRoot | Out-Null
        Copy-Item -Path (Join-Path (Split-Path $InstalledOllama.Source -Parent) '*') -Destination $OllamaRoot -Recurse -Force
    }
}

$envFile = Join-Path $Root '.env'
$managedSettings = [ordered]@{
    OLLAMA_BASE_URL = 'http://127.0.0.1:11434'
    OLLAMA_MODEL = 'qwen3.6:latest'
    OLLAMA_EMBED_MODEL = 'nomic-embed-text'
    WORKSPACE_ROOT = $Root
    MEMORY_DB = 'data/memory/memory.db'
    IMAGE_MODEL_PATH = 'models/tiny-sd'
    VIDEO_MODEL_PATH = 'models/text-to-video-ms-1.7b'
    PIPER_MODEL_PATH = 'models/piper-voices/tr_TR-dfki-medium/tr_TR-dfki-medium.onnx'
    OLLAMA_EXECUTABLE = $OllamaExe
    PLAYWRIGHT_BROWSERS_PATH = $BrowserRoot
    HF_HOME = (Join-Path $CacheRoot 'huggingface')
    TORCH_HOME = (Join-Path $CacheRoot 'torch')
    MAX_UPLOAD_MB = '265'
    AGENT_DEV_MODE = 'workspace'
    REQUIRE_MEMORY_APPROVAL = 'off'
}
$preservedLines = @()
if (Test-Path $envFile) {
    foreach ($line in Get-Content -LiteralPath $envFile) {
        if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=') {
            if ($managedSettings.Contains($Matches[1])) { continue }
        }
        $preservedLines += $line
    }
}
$generatedLines = foreach ($name in $managedSettings.Keys) { "$name=$($managedSettings[$name])" }
@($preservedLines) + @($generatedLines) | Set-Content -LiteralPath $envFile -Encoding utf8

Write-Output "Kurulum tamamlandi: $Root"
Write-Output "Model yolu: $ModelStore"
Write-Output "Python paketleri: $Venv"
Write-Output "Ollama paketi: $OllamaRoot"
Write-Output 'Baslatmak icin: .\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8787'
Write-Output 'Baslatmak icin: .\Start-LocalQwenAgent.cmd'
