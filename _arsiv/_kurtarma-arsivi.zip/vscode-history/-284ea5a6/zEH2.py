"""Local-only Transmission RPC integration for DeepPanda."""

from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, urlopen

import psutil


class TransmissionError(RuntimeError):
    pass


class TransmissionService:
    DEFAULT_ENDPOINT = "http://127.0.0.1:9091/transmission/rpc"
    TORRENT_FIELDS = (
        "id",
        "name",
        "status",
        "percent_done",
        "rate_download",
        "rate_upload",
        "eta",
        "total_size",
        "error_string",
    )
    ACTIONS = {"start": "torrent_start", "stop": "torrent_stop", "verify": "torrent_verify"}

    def __init__(
        self,
        endpoint: str = DEFAULT_ENDPOINT,
        executable_path: str | None = None,
        timeout: float = 4.0,
    ) -> None:
        self.endpoint = self._validate_endpoint(endpoint)
        self.executable_path = executable_path
        self.timeout = timeout
        self._session_id = ""
        self._request_id = 0
        self._lock = threading.Lock()

    def status(self) -> dict[str, Any]:
        try:
            session = self._rpc("session_get", {"fields": ["version", "rpc_version_semver", "download_dir"]})
            stats = self._rpc("session_stats")
        except TransmissionError as exc:
            return {"status": "offline", "message": str(exc)}
        return {"status": "online", "message": "Transmission bağlı.", "session": session, "stats": stats}

    def list_torrents(self) -> list[dict[str, Any]]:
        result = self._rpc("torrent_get", {"fields": list(self.TORRENT_FIELDS)})
        torrents = result.get("torrents", [])
        return torrents if isinstance(torrents, list) else []

    def add_source(self, source: str, paused: bool = False) -> dict[str, Any]:
        value = str(source or "").strip()
        if value.lower().startswith("magnet:"):
            self._validate_magnet(value)
            params: dict[str, Any] = {"filename": value, "paused": bool(paused)}
        else:
            path = Path(value).expanduser().resolve()
            if path.suffix.lower() != ".torrent" or not path.is_file():
                raise TransmissionError("Geçerli bir magnet bağlantısı veya .torrent dosyası seçin.")
            if path.stat().st_size > 16 * 1024 * 1024:
                raise TransmissionError(".torrent dosyası 16 MB sınırını aşıyor.")
            params = {
                "metainfo": base64.b64encode(path.read_bytes()).decode("ascii"),
                "paused": bool(paused),
            }
        return self._rpc("torrent_add", params)

    def action(self, action: str, torrent_ids: list[int]) -> dict[str, Any]:
        method = self.ACTIONS.get(action)
        ids = self._validate_ids(torrent_ids)
        if method is None:
            raise TransmissionError("Geçersiz torrent işlemi.")
        return self._rpc(method, {"ids": ids})

    def remove(self, torrent_ids: list[int]) -> dict[str, Any]:
        ids = self._validate_ids(torrent_ids)
        return self._rpc("torrent_remove", {"ids": ids, "delete_local_data": False})

    def start_local_engine(self) -> dict[str, Any]:
        online = self.status()
        if online.get("status") == "online":
            return online
        executable = self.find_executable()
        if executable is None:
            return {
                "status": "error",
                "message": "Transmission bulunamadı. Örnek klasörü veya kurulu Transmission gerekli.",
            }
        if self._is_process_running():
            return {
                "status": "error",
                "message": "Transmission çalışıyor ancak RPC kapalı. Programı kapatıp yeniden deneyin.",
            }
        configured = self.configure_local_rpc()
        if configured.get("status") != "success":
            return configured
        try:
            process = subprocess.Popen([str(executable)], cwd=str(executable.parent), shell=False)
        except OSError as exc:
            return {"status": "error", "message": f"Transmission başlatılamadı: {exc}"}
        return {
            "status": "starting",
            "message": "Transmission başlatılıyor...",
            "process_id": process.pid,
        }

    def configure_local_rpc(self) -> dict[str, Any]:
        settings_path = self.find_settings()
        if settings_path is None:
            return {"status": "error", "message": "Transmission settings.json bulunamadı."}
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return {"status": "error", "message": f"Transmission ayarları okunamadı: {exc}"}
        if not isinstance(settings, dict):
            return {"status": "error", "message": "Transmission ayar biçimi geçersiz."}

        snake_case = "rpc_enabled" in settings
        key = lambda snake, legacy: snake if snake_case else legacy
        auth_key = key("rpc_authentication_required", "rpc-authentication-required")
        if bool(settings.get(auth_key, False)):
            return {
                "status": "error",
                "message": "RPC kimlik doğrulaması açık. DeepPanda parolayı saklamadan bağlanamaz.",
            }
        settings[key("rpc_enabled", "rpc-enabled")] = True
        settings[key("rpc_bind_address", "rpc-bind-address")] = "127.0.0.1"
        settings[key("rpc_whitelist_enabled", "rpc-whitelist-enabled")] = True
        settings[key("rpc_whitelist", "rpc-whitelist")] = "127.0.0.1"
        settings[key("rpc_host_whitelist_enabled", "rpc-host-whitelist-enabled")] = True

        backup_path = settings_path.with_suffix(".deeppanda-backup.json")
        temp_path = settings_path.with_suffix(".deeppanda.tmp")
        try:
            if not backup_path.exists():
                shutil.copy2(settings_path, backup_path)
            temp_path.write_text(json.dumps(settings, ensure_ascii=False, indent=4), encoding="utf-8")
            os.replace(temp_path, settings_path)
        except OSError as exc:
            temp_path.unlink(missing_ok=True)
            return {"status": "error", "message": f"Transmission RPC ayarı yazılamadı: {exc}"}
        return {
            "status": "success",
            "message": "Yerel Transmission RPC güvenli biçimde etkinleştirildi.",
            "settings_path": str(settings_path),
            "backup_path": str(backup_path),
        }

    def find_executable(self) -> Path | None:
        candidates = [
            self.executable_path,
            str(Path.home() / "Desktop" / "Transmission" / "transmission-qt.exe"),
            str(Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Transmission" / "transmission-qt.exe"),
            shutil.which("transmission-qt.exe"),
        ]
        for value in candidates:
            if value and Path(value).is_file():
                return Path(value).resolve()
        return None

    @staticmethod
    def find_settings() -> Path | None:
        root = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        path = root / "transmission" / "settings.json"
        return path if path.is_file() else None

    def _rpc(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        with self._lock:
            self._request_id += 1
            payload = json.dumps(
                {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": self._request_id}
            ).encode("utf-8")
            return self._send(payload, retry_session=True)

    def _send(self, payload: bytes, retry_session: bool) -> dict[str, Any]:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self._session_id:
            headers["X-Transmission-Session-Id"] = self._session_id
        request = Request(self.endpoint, data=payload, headers=headers, method="POST")
        try:
            with urlopen(request, timeout=self.timeout) as response:
                raw = response.read()
        except HTTPError as exc:
            if exc.code == 409 and retry_session:
                session_id = exc.headers.get("X-Transmission-Session-Id", "")
                if session_id:
                    self._session_id = session_id
                    return self._send(payload, retry_session=False)
            if exc.code == 401:
                raise TransmissionError("Transmission RPC kimlik doğrulaması istiyor.") from exc
            raise TransmissionError(f"Transmission RPC HTTP hatası: {exc.code}") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise TransmissionError("Yerel Transmission RPC'ye bağlanılamadı.") from exc
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise TransmissionError("Transmission geçersiz bir RPC yanıtı döndürdü.") from exc
        if not isinstance(decoded, dict):
            raise TransmissionError("Transmission RPC yanıt biçimi geçersiz.")
        if decoded.get("error"):
            error = decoded["error"]
            message = error.get("message", "Bilinmeyen RPC hatası") if isinstance(error, dict) else str(error)
            raise TransmissionError(f"Transmission RPC hatası: {message}")
        result = decoded.get("result", {})
        return result if isinstance(result, dict) else {}

    @staticmethod
    def _validate_endpoint(value: str) -> str:
        parsed = urlsplit(str(value or ""))
        if (
            parsed.scheme != "http"
            or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
            or parsed.username is not None
            or parsed.password is not None
        ):
            raise ValueError("Transmission RPC yalnız yerel HTTP adresinde kullanılabilir.")
        return value

    @staticmethod
    def _validate_magnet(value: str) -> None:
        parsed = urlsplit(value)
        topics = parse_qs(parsed.query).get("xt", [])
        if parsed.scheme.lower() != "magnet" or not any(
            topic.lower().startswith(("urn:btih:", "urn:btmh:")) for topic in topics
        ):
            raise TransmissionError("Magnet bağlantısında geçerli bir BitTorrent kimliği yok.")

    @staticmethod
    def _validate_ids(values: list[int]) -> list[int]:
        if not values or any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in values):
            raise TransmissionError("Geçerli bir torrent seçin.")
        return values

    @staticmethod
    def _is_process_running() -> bool:
        for process in psutil.process_iter(["name"]):
            try:
                if str(process.info.get("name", "")).casefold() == "transmission-qt.exe":
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False