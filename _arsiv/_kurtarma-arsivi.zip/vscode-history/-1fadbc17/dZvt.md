# LocalQwenAgent Distribution and Licensing

## Product scope

The licensed product is the LocalQwenAgent interface, local orchestration, approval-gated tools, SQLite/document workflows, and the installer. Qwen is an independently licensed open model/runtime dependency, not a proprietary model owned by this product.

The bootstrap package does not include model weights. A customer can install the app first, then explicitly approve the Qwen download from the local setup panel. The optional model-payload package bundles the present Ollama/model directories and can be tens of gigabytes; Python packages and Playwright Chromium still require internet during setup, so this is not a fully offline installer.

## Build a customer package

From the AI project root:

```powershell
.\Package-LocalQwenAgent.ps1
```

The default output is `LocalQwenAgent-Releases` beside the project folder and contains a small bootstrap ZIP plus a JSON manifest. It excludes `.env`, SQLite memory, uploaded assets, logs, development environments, caches, private keys, training datasets, and model weights. The packager fails if a `license_private_key.pem` is found inside the AI source tree.

To bundle the local model/runtime payload, explicitly opt in:

```powershell
.\Package-LocalQwenAgent.ps1 -IncludeModelPayload
```

Review the manifest and package contents before distribution. The model-payload package is expected to be multi-gigabyte; it is not the default sales download and does not eliminate the initial dependency/bootstrap downloads.

## Customer installation

1. Extract the bootstrap ZIP into a customer-owned folder such as `%LOCALAPPDATA%\Programs\LocalQwenAgent`.
2. Open PowerShell in the extracted `LocalQwenAgent` folder.
3. Run `powershell -File setup_portable.ps1 -InstallOllama` if Ollama is not already installed. This creates `.venv`, installs core dependencies and Chromium, and creates a customer `.env` with license enforcement enabled.
4. Run `Start-LocalQwenAgent.cmd`.
5. In the app's setup panel, explicitly approve downloading the configured Qwen model. Do not imply model weights were bundled with the bootstrap ZIP.

The setup writes managed paths relative to the extracted application folder by default and does not change the Windows user's persistent `OLLAMA_MODELS` setting. If `-WorkspaceRoot` is supplied, that explicitly selected workspace remains an external absolute path.

This is a reinstallable bootstrap, not a self-contained folder that can be moved and run without setup. For another folder or PC, extract the bootstrap there and run setup again; the package intentionally excludes `.venv`, local license state, SQLite data, uploads, and model weights by default. Back up or transfer customer data and optional model payloads separately. Python dependencies and Chromium still require internet access during setup.

`-InstallMediaExtras` installs the heavier local image/video/Whisper dependency set. It is optional and can require substantial download space. Python 3.12+ and Windows are prerequisites; GPU capability depends on the customer's driver and hardware.

## Issue a quarterly or annual license

The app starts a 30-day machine-bound trial. In the app, open **Hafıza, lisans ve kurulum** and copy the **Kurulum Kimliği**. Generate only the chosen paid plan from the vendor machine:

```powershell
.\.venv\Scripts\python.exe ..\DeepPanda-License-Admin\tools\generate_localqwen_license.py `
  --customer "Customer Name" `
  --plan quarterly `
  --installation-id "CUSTOMER-INSTALLATION-ID"
```

Use `--plan annual` for the 365-day plan. Quarterly is 90 days. The generator writes a signed `VANA1` `.txt` license under the admin records folder by default. Send the customer only that license file; never send the admin executable, admin folder, or `keys\license_private_key.pem`.

The customer selects the `.txt` file in the app and clicks **Lisansı etkinleştir**. The app verifies the Ed25519 signature and installation ID locally, then stores the key/trial state under `%LOCALAPPDATA%\DeepPanda\LocalQwenAgent`, outside the install directory.

## Security and commercial limits

- The installer contains only the public verification key in source; the private signing key stays on the vendor machine.
- The current license is offline and machine-bound. There is no online revocation, seat transfer, payment processor, or automatic renewal.
- Device changes use vendor-approved reissuance: verify the existing signed license and customer's request, issue a replacement for the new Installation ID with `--transfer-from-license`, `--transfer-from-installation-id`, and `--transfer-reason`, and retain `DeepPanda-License-Admin/records/license_transfers.csv` as the audit trail. The replacement preserves the original plan and expiry. This is an administrative control, not technical revocation: an already-issued offline key can continue working on the old device until it expires.
- Offline client-side license enforcement is not tamper-proof DRM. A determined user with local administrator access can patch a local program. For stronger revocation, subscriptions, or seat management, add a hosted activation/licensing service later.
- The quarterly and annual price points, refund policy, support policy, privacy notice, and distribution terms still need owner decisions before taking payment.
- Audit third-party model and package licenses separately from the LocalQwenAgent product license.
