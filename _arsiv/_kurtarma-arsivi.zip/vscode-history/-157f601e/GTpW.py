"""Support recovery service for approved technical sessions."""

from __future__ import annotations

import importlib.util
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Sequence, Tuple


class SupportRecoveryService:
    """Runs missing package checks and driver/system scans for support workflows."""

    EXPORT_DIR = Path(__file__).resolve().parent.parent / "exports"

    DEFAULT_MODULES: Sequence[Tuple[str, str]] = (
        ("customtkinter", "customtkinter"),
        ("psutil", "psutil"),
    )

    def scan_missing_modules(
        self,
        modules: Sequence[Tuple[str, str]] | None = None,
    ) -> List[Dict[str, str]]:
        module_pairs = modules or self.DEFAULT_MODULES
        missing: List[Dict[str, str]] = []
        for module_name, package_name in module_pairs:
            if importlib.util.find_spec(module_name) is None:
                missing.append({"module": module_name, "package": package_name})
        return missing

    def repair_missing_modules(
        self,
        python_executable: str,
        missing: Sequence[Dict[str, str]],
        dry_run: bool = False,
        retry_count: int = 2,
        backoff_seconds: float = 1.5,
    ) -> Dict[str, object]:
        installed = 0
        failed = 0
        retries_used = 0
        details: List[str] = []

        for item in missing:
            package = item.get("package", "")
            module = item.get("module", "")
            if not package:
                failed += 1
                details.append(f"Paket bilgisi eksik: {module}")
                continue

            if dry_run:
                installed += 1
                details.append(f"DRY-RUN install: {package} (module: {module})")
                continue

            try:
                attempts_total = max(1, int(retry_count) + 1)
                success = False
                last_error = ""
                for attempt in range(1, attempts_total + 1):
                    proc = subprocess.run(
                        [python_executable, "-m", "pip", "install", package],
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                        timeout=180,
                    )
                    if proc.returncode == 0:
                        installed += 1
                        details.append(f"Kuruldu: {package} (attempt {attempt}/{attempts_total})")
                        success = True
                        break

                    last_error = (proc.stderr or proc.stdout or "Bilinmeyen hata").strip()[:240]
                    if attempt < attempts_total:
                        retries_used += 1
                        sleep_time = max(0.0, float(backoff_seconds)) * attempt
                        details.append(
                            f"Kurulum denemesi basarisiz ({package}) attempt {attempt}/{attempts_total}. "
                            f"{sleep_time:.1f}s sonra yeniden denenecek."
                        )
                        if sleep_time > 0:
                            time.sleep(sleep_time)

                if not success:
                    failed += 1
                    details.append(f"Kurulum hatası ({package}): {last_error}")
            except Exception as exc:
                failed += 1
                details.append(f"Kurulum istisnası ({package}): {exc}")

        return {
            "installed": installed,
            "failed": failed,
            "retries_used": retries_used,
            "details": details,
        }

    def scan_driver_health(self, dry_run: bool = False) -> Dict[str, object]:
        if dry_run:
            return {
                "ok": True,
                "issues": 0,
                "summary": "DRY-RUN: Driver sağlık taraması planlandı.",
                "raw": "",
            }

        command = (
            "$problems = @(); "
            "if (Get-Command Get-PnpDevice -ErrorAction SilentlyContinue) { "
            "$problems = Get-PnpDevice -PresentOnly | Where-Object { $_.Status -ne 'OK' } "
            "| Select-Object Class,FriendlyName,Status,Problem; }; "
            "$drivers = Get-CimInstance Win32_PnPSignedDriver | "
            "Select-Object -First 40 DeviceName,DriverVersion,Manufacturer; "
            "Write-Output '===DRIVER_PROBLEMS==='; $problems | Format-Table -AutoSize; "
            "Write-Output '===DRIVER_SAMPLE==='; $drivers | Format-Table -AutoSize"
        )
        try:
            proc = subprocess.run(
                ["powershell", "-Command", command],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            output = (proc.stdout or "").strip()
            issues = 0
            if "===DRIVER_PROBLEMS===" in output:
                chunk = output.split("===DRIVER_PROBLEMS===", 1)[1]
                chunk = chunk.split("===DRIVER_SAMPLE===", 1)[0]
                lines = [ln for ln in chunk.splitlines() if ln.strip() and "---" not in ln]
                issues = max(0, len(lines) - 1) if lines else 0

            if proc.returncode != 0:
                return {
                    "ok": False,
                    "issues": issues,
                    "summary": "Driver taraması hata verdi.",
                    "raw": ((proc.stderr or proc.stdout or "").strip())[:1200],
                }

            return {
                "ok": True,
                "issues": issues,
                "summary": f"Driver taraması tamamlandı. Potansiyel sorun: {issues}",
                "raw": output[:1200],
            }
        except Exception as exc:
            return {
                "ok": False,
                "issues": 0,
                "summary": f"Driver taraması istisnası: {exc}",
                "raw": "",
            }

    def run_recovery_cycle(
        self,
        python_executable: str,
        dry_run: bool = False,
        retry_count: int = 2,
        backoff_seconds: float = 1.5,
        mode: str = "manual",
        write_report: bool = True,
    ) -> Dict[str, object]:
        missing = self.scan_missing_modules()
        repair = self.repair_missing_modules(
            python_executable,
            missing,
            dry_run=dry_run,
            retry_count=retry_count,
            backoff_seconds=backoff_seconds,
        )
        drivers = self.scan_driver_health(dry_run=dry_run)

        result = {
            "missing_modules": missing,
            "repair": repair,
            "drivers": drivers,
        }

        if write_report:
            result["report_path"] = self.export_recovery_report(result, mode=mode, dry_run=dry_run)

        return result

    def export_recovery_report(self, cycle_result: Dict[str, object], mode: str, dry_run: bool) -> str:
        self.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = self.EXPORT_DIR / f"support_recovery_{stamp}.txt"

        missing = cycle_result.get("missing_modules", [])
        repair = cycle_result.get("repair", {})
        drivers = cycle_result.get("drivers", {})

        lines: List[str] = [
            "SystemCore v2 - Teknik Servis Onarim Raporu",
            f"Olusturma Zamani: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Calisma Modu: {mode}",
            f"Dry Run: {'Evet' if dry_run else 'Hayir'}",
            "",
            f"Eksik Paket Sayisi: {len(missing)}",
            "Eksik Paketler:",
        ]
        if missing:
            lines.extend([f"- {item.get('module')} ({item.get('package')})" for item in missing])
        else:
            lines.append("- Eksik paket bulunmadi.")

        lines.extend([
            "",
            "Paket Duzeltme Ozeti:",
            f"- Kurulan: {repair.get('installed', 0)}",
            f"- Basarisiz: {repair.get('failed', 0)}",
            f"- Kullanilan Retry: {repair.get('retries_used', 0)}",
            "Detaylar:",
        ])
        details = repair.get("details", [])
        if details:
            lines.extend([f"- {item}" for item in details])
        else:
            lines.append("- Detay yok.")

        lines.extend([
            "",
            "Driver Tarama Ozeti:",
            f"- Durum: {'OK' if drivers.get('ok') else 'HATA'}",
            f"- Potansiyel Sorun: {drivers.get('issues', 0)}",
            f"- Aciklama: {drivers.get('summary', '')}",
        ])
        raw = str(drivers.get("raw", "")).strip()
        if raw:
            lines.extend(["", "Driver Ham Cikti:", raw])

        path.write_text("\n".join(lines), encoding="utf-8")
        return str(path)
