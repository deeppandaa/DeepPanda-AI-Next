import tempfile
import unittest
from pathlib import Path

from services.ai_knowledge_service import AIKnowledgeService


class AIKnowledgeServiceTests(unittest.TestCase):
    def test_retrieves_guide_context_without_reading_binary_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "KULLANIM_KILAVUZU.md").write_text(
                "Paket kurulumunda Dry-run kullanilir.\n", encoding="utf-8"
            )
            (root / "ignored.iso").write_bytes(b"binary")

            context = AIKnowledgeService(app_root=root, vm_root=root / "vm-tests").context_for("Paket kurulumu")

        self.assertIn("Paket kurulumunda Dry-run", context)
        self.assertNotIn("binary", context)

    def test_retrieves_vm_log_context(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            logs = root / "Siemens-CArm-Service-Lab" / "Logs"
            logs.mkdir(parents=True)
            (logs / "VBox.log").write_text(
                "CArm lab boot failed with timeout\n", encoding="utf-8"
            )

            context = AIKnowledgeService(app_root=root, vm_root=root).context_for("CArm timeout")

        self.assertIn("CArm lab boot failed with timeout", context)
        self.assertIn("Siemens-CArm-Service-Lab", context)