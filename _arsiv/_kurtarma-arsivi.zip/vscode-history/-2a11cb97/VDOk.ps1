param(
    [string]$InnoSetupPath = "$env:USERPROFILE\Desktop\Inno Setup 6\ISCC.exe"
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$compilerCandidates = @(
    $InnoSetupPath,
    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$compiler = $compilerCandidates | Where-Object { $_ -and (Test-Path $_ -PathType Leaf) } | Select-Object -First 1

if (-not $compiler) {
    throw "Inno Setup 6 ISCC.exe bulunamadi. -InnoSetupPath ile konum belirtin."
}
if (-not (Test-Path "$projectRoot\dist\DeepPanda.exe" -PathType Leaf)) {
    throw "dist\DeepPanda.exe bulunamadi. Once PyInstaller paketini olusturun."
}
if (-not (Test-Path "$projectRoot\dist_legacy\DeepPandaLegacy.exe" -PathType Leaf)) {
    throw "dist_legacy\DeepPandaLegacy.exe bulunamadi. Once build_legacy.ps1 calistirin."
}
$requiredPayloads = @(
    "$projectRoot\assets\mobile\DeepPandaMobile-release.apk",
    "$projectRoot\assets\tailscale\windows\tailscale.exe",
    "$projectRoot\assets\tailscale\windows\tailscaled.exe",
    "$projectRoot\assets\tailscale\licenses\TAILSCALE-LICENSE.txt",
    "$projectRoot\..\DeepPanda-Panel\runtime\start-db.mjs",
    "$projectRoot\..\DeepPanda-Panel\web\server.js",
    "$projectRoot\..\DeepPanda-Panel\node\node.exe",
    "$projectRoot\..\DeepPanda_Panel_Baslat.ps1",
    "$projectRoot\..\DeepPanda_Panel.cmd"
)
$missingPayloads = $requiredPayloads | Where-Object { -not (Test-Path $_ -PathType Leaf) }
if ($missingPayloads) {
    throw "Installer payload dosyalari eksik:`n$($missingPayloads -join "`n")"
}
$vcRuntime = "$projectRoot\tools\legacy-build\vc_redist.x86.exe"
if (-not (Test-Path $vcRuntime -PathType Leaf)) {
    throw "Windows 7 VC++ x86 runtime bulunamadi. Once build_legacy.ps1 calistirin."
}
$vcSignature = Get-AuthenticodeSignature $vcRuntime
if ($vcSignature.Status -ne "Valid" -or $vcSignature.SignerCertificate.Subject -notmatch "Microsoft Corporation") {
    throw "Windows 7 VC++ x86 runtime imzasi dogrulanamadi."
}

Push-Location $projectRoot
try {
    & $compiler "$projectRoot\DeepPanda.iss"
    if ($LASTEXITCODE -ne 0) {
        throw "Inno Setup derlemesi $LASTEXITCODE koduyla basarisiz oldu."
    }
} finally {
    Pop-Location
}

Get-Item "$projectRoot\installer\DeepPanda-Setup-2.7.1.exe"