param(
    [string]$InnoSetupPath = "$env:USERPROFILE\Desktop\Inno Setup 6\ISCC.exe"
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$compilerCandidates = @(
    $InnoSetupPath,
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$compiler = $compilerCandidates | Where-Object { $_ -and (Test-Path $_ -PathType Leaf) } | Select-Object -First 1

if (-not $compiler) {
    throw "Inno Setup 6 ISCC.exe bulunamadi. -InnoSetupPath ile konum belirtin."
}
if (-not (Test-Path "$projectRoot\dist\DeepPanda.exe" -PathType Leaf)) {
    throw "dist\DeepPanda.exe bulunamadi. Once PyInstaller paketini olusturun."
}

Push-Location $projectRoot
try {
    & $compiler "$projectRoot\DeepPanda.iss"
    if ($LASTEXITCODE -ne 0) {
        throw "Inno Setup derlemesi $LASTEXITCODE koduyla basarisiz oldu."
    }
} finally {
    Pop-Location
}

Get-Item "$projectRoot\installer\DeepPanda-Setup-2.7.1.exe"