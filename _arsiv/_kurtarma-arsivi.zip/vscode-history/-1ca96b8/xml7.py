"""Minimal AI-free DeepPanda agent for legacy Windows systems."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import ssl
import sys
import threading
import tkinter as tk
import urllib.error
import urllib.parse
import urllib.request
import winreg
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any, Dict, List, Optional

from legacy_agent import LEGACY_VERSION


APP_NAME = "DeepPanda Legacy Agent"
HEARTBEAT_INTERVAL_MS = 60_000


def settings_path() -> Path:
    root = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DeepPandaLegacy"
    root.mkdir(parents=True, exist_ok=True)
    return root / "settings.json"


def load_settings(path: Optional[Path] = None) -> Dict[str, Any]:
    target = path or settings_path()
    defaults = {"control_plane_url": "", "agent_token": "", "autostart": True}
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            defaults.update(value)
    except (OSError, ValueError, TypeError):
        pass
    return defaults


def save_settings(value: Dict[str, Any], path: Optional[Path] = None) -> None:
    target = path or settings_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def validate_base_url(value: str) -> str:
    clean = str(value or "").strip().rstrip("/")
    parsed = urllib.parse.urlparse(clean)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Gecerli bir panel adresi girin.")
    if parsed.scheme != "https" and parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("Uzak panel adresi HTTPS kullanmalidir.")
    return clean


def machine_guid() -> str:
    access = winreg.KEY_READ
    if hasattr(winreg, "KEY_WOW64_64KEY"):
        access |= winreg.KEY_WOW64_64KEY
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, access) as key:
        return str(winreg.QueryValueEx(key, "MachineGuid")[0])


def installation_id(guid: Optional[str] = None) -> str:
    source = (guid or machine_guid()).strip().lower().encode("utf-8")
    return "legacy-" + hashlib.sha256(source).hexdigest()[:40]


def serial_ports() -> List[Dict[str, str]]:
    ports: List[Dict[str, str]] = []
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM") as key:
            index = 0
            while True:
                try:
                    name, value, _kind = winreg.EnumValue(key, index)
                    ports.append({"device": str(value), "source": str(name)})
                    index += 1
                except OSError:
                    break
    except OSError:
        pass
    return sorted(ports, key=lambda item: item["device"])


def system_payload(guid: Optional[str] = None) -> Dict[str, Any]:
    ports = serial_ports()
    return {
        "installationId": installation_id(guid),
        "hostname": socket.gethostname() or "Legacy-Windows-PC",
        "osName": "%s %s %s" % (platform.system(), platform.release(), platform.version()),
        "appVersion": LEGACY_VERSION,
        "riskScore": 20 if platform.release() == "7" else 5,
        "event": {
            "title": "legacy.agent.heartbeat",
            "detail": "AI kapali; COM port sayisi: %d" % len(ports),
            "component": "system",
            "severity": "warning" if platform.release() == "7" else "info",
            "status": "detected",
        },
    }


class HeartbeatClient:
    def __init__(self, base_url: str, token: str):
        self.base_url = validate_base_url(base_url)
        self.token = str(token or "").strip()
        if not self.token:
            raise ValueError("Agent token bos olamaz.")

    def send(self, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        request = urllib.request.Request(
            self.base_url + "/api/agent/heartbeat",
            data=json.dumps(payload or system_payload()).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": "Bearer " + self.token,
                "Content-Type": "application/json",
                "User-Agent": "DeepPandaLegacy/" + LEGACY_VERSION,
            },
        )
        context = ssl.create_default_context()
        if hasattr(ssl, "TLSVersion"):
            context.minimum_version = ssl.TLSVersion.TLSv1_2
        with urllib.request.urlopen(request, timeout=15, context=context) as response:
            return json.loads(response.read(1024 * 1024).decode("utf-8"))


def set_autostart(enabled: bool) -> None:
    executable = Path(sys.executable).resolve()
    command = '"%s"' % executable
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as key:
        if enabled:
            winreg.SetValueEx(key, "DeepPandaLegacy", 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, "DeepPandaLegacy")
            except FileNotFoundError:
                pass


class LegacyAgentApp:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.geometry("620x430")
        self.root.minsize(560, 390)
        self.settings = load_settings()
        self.url = tk.StringVar(value=str(self.settings.get("control_plane_url", "")))
        self.token = tk.StringVar(value=str(self.settings.get("agent_token", "")))
        self.autostart = tk.BooleanVar(value=bool(self.settings.get("autostart", True)))
        self.status = tk.StringVar(value="Hazir. AI bu surumde devre disidir.")
        self._build()
        self.root.after(800, self._automatic_heartbeat)

    def _build(self) -> None:
        container = ttk.Frame(self.root, padding=20)
        container.pack(fill="both", expand=True)
        ttk.Label(container, text=APP_NAME, font=("Segoe UI", 17, "bold")).pack(anchor="w")
        ttk.Label(container, text="Windows 7 SP1 uyumlu, AI'siz izleme agenti").pack(anchor="w", pady=(2, 18))
        form = ttk.Frame(container)
        form.pack(fill="x")
        ttk.Label(form, text="Panel adresi").grid(row=0, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=self.url).grid(row=1, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(form, text="Agent token").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=self.token, show="*").grid(row=3, column=0, sticky="ew", pady=(0, 10))
        form.columnconfigure(0, weight=1)
        ttk.Checkbutton(container, text="Windows acilisinda baslat", variable=self.autostart).pack(anchor="w", pady=8)
        actions = ttk.Frame(container)
        actions.pack(fill="x", pady=8)
        ttk.Button(actions, text="Kaydet", command=self._save).pack(side="left")
        ttk.Button(actions, text="Heartbeat gonder", command=self._send_async).pack(side="left", padx=8)
        ttk.Button(actions, text="COM portlarini yenile", command=self._show_ports).pack(side="left")
        ttk.Separator(container).pack(fill="x", pady=14)
        ttk.Label(container, textvariable=self.status, wraplength=560).pack(anchor="w")
        self.ports = tk.Text(container, height=6, state="disabled", font=("Consolas", 9))
        self.ports.pack(fill="both", expand=True, pady=(12, 0))
        self._show_ports()

    def _save(self) -> bool:
        try:
            clean_url = validate_base_url(self.url.get())
            if not self.token.get().strip():
                raise ValueError("Agent token bos olamaz.")
            value = {"control_plane_url": clean_url, "agent_token": self.token.get().strip(), "autostart": self.autostart.get()}
            save_settings(value)
            set_autostart(self.autostart.get())
            self.status.set("Ayarlar kaydedildi.")
            return True
        except (OSError, ValueError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return False

    def _send_async(self) -> None:
        if not self._save():
            return
        self.status.set("Heartbeat gonderiliyor...")
        threading.Thread(target=self._send_worker, daemon=True).start()

    def _send_worker(self) -> None:
        try:
            result = HeartbeatClient(self.url.get(), self.token.get()).send()
            message = "Panel baglantisi basarili. Cihaz ID: %s" % result.get("deviceId", "-")
        except (OSError, ValueError, urllib.error.URLError, json.JSONDecodeError) as exc:
            message = "Heartbeat hatasi: %s" % exc
        self.root.after(0, lambda: self.status.set(message))

    def _automatic_heartbeat(self) -> None:
        if self.url.get().strip() and self.token.get().strip():
            self._send_async()
        self.root.after(HEARTBEAT_INTERVAL_MS, self._automatic_heartbeat)

    def _show_ports(self) -> None:
        lines = ["%s  %s" % (item["device"], item["source"]) for item in serial_ports()]
        self.ports.configure(state="normal")
        self.ports.delete("1.0", "end")
        self.ports.insert("end", "\n".join(lines) if lines else "Aktif COM portu bulunamadi.")
        self.ports.configure(state="disabled")

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    LegacyAgentApp().run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())