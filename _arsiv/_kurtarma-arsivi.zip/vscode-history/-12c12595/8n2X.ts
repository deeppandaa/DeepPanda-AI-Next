import { NextResponse } from "next/server";
import { z } from "zod";
import { auditEvent } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";

const createSchema = z.object({
  title: z.string().trim().min(3).max(200),
  description: z.string().trim().max(4000).optional(),
  category: z.enum(["technical", "medical", "network", "software", "hardware", "maintenance"]),
  priority: z.enum(["low", "normal", "high", "critical"]),
  customerId: z.string().uuid().nullable().optional(),
  deviceId: z.string().uuid().nullable().optional(),
  technicianId: z.string().uuid().nullable().optional(),
});

const SLA_HOURS = { low: 72, normal: 24, high: 8, critical: 2 } as const;

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  const result = await tenantQuery(session.organizationId, `SELECT
    t.id,t.ticket_number,t.title,t.description,t.category,t.priority,t.status,t.sla_due_at,
    t.created_at,t.updated_at,c.name customer_name,d.hostname device_name,u.name technician_name,
    (t.sla_due_at IS NOT NULL AND t.sla_due_at < now() AND t.status NOT IN ('resolved','closed','cancelled')) sla_breached
    FROM service_tickets t
    LEFT JOIN customers c ON c.id=t.customer_id
    LEFT JOIN devices d ON d.id=t.device_id
    LEFT JOIN users u ON u.id=t.assigned_technician_id
    WHERE t.organization_id=$1
    ORDER BY CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END,
      t.created_at DESC LIMIT 200`);
  return NextResponse.json({ tickets: result.rows });
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!['owner', 'admin', 'technician'].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }
  const parsed = createSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Geçersiz iş emri verisi." }, { status: 400 });
  const input = parsed.data;
  const scope = await tenantQuery<{ customers_valid: boolean; devices_valid: boolean; technicians_valid: boolean }>(
    session.organizationId,
    `SELECT
      ($2::uuid IS NULL OR EXISTS(SELECT 1 FROM customers WHERE organization_id=$1 AND id=$2)) customers_valid,
      ($3::uuid IS NULL OR EXISTS(SELECT 1 FROM devices WHERE organization_id=$1 AND id=$3)) devices_valid,
      ($4::uuid IS NULL OR EXISTS(SELECT 1 FROM users WHERE organization_id=$1 AND id=$4 AND role IN ('owner','admin','technician') AND active)) technicians_valid`,
    [input.customerId ?? null, input.deviceId ?? null, input.technicianId ?? null],
  );
  const validity = scope.rows[0];
  if (!validity?.customers_valid || !validity.devices_valid || !validity.technicians_valid) {
    return NextResponse.json({ message: "Müşteri, cihaz veya teknisyen organizasyon kapsamında değil." }, { status: 400 });
  }
  const result = await tenantQuery<{ id: string; ticket_number: string }>(session.organizationId,
    `INSERT INTO service_tickets
      (organization_id,customer_id,device_id,assigned_technician_id,created_by,title,description,category,priority,status,sla_due_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now() + ($11::text || ' hours')::interval)
     RETURNING id,ticket_number::text`,
    [input.customerId ?? null, input.deviceId ?? null, input.technicianId ?? null, session.userId,
      input.title, input.description ?? "", input.category, input.priority,
      input.technicianId ? "assigned" : "open", SLA_HOURS[input.priority]],
  );
  const ticket = result.rows[0];
  await tenantQuery(session.organizationId,
    `INSERT INTO service_ticket_activities (organization_id,ticket_id,actor_user_id,event_type,body,detail)
     VALUES ($1,$2,$3,'created',$4,$5::jsonb)`,
    [ticket.id, session.userId, "İş emri oluşturuldu.", JSON.stringify({ status: input.technicianId ? "assigned" : "open" })]);
  await auditEvent({ organizationId: session.organizationId, actorUserId: session.userId,
    action: "ticket.create", targetType: "service_ticket", targetId: ticket.id,
    detail: { ticketNumber: ticket.ticket_number, title: input.title, priority: input.priority, category: input.category } });
  return NextResponse.json(ticket, { status: 201 });
}