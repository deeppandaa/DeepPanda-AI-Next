import { createHmac } from "crypto";
import { strict as assert } from "assert";
import { verifyIyzicoHppWebhook, type IyzicoHppWebhook } from "../src/lib/payments";

const secret = "sandbox-secret";
const body: IyzicoHppWebhook = {
  paymentConversationId: "vana-order-123",
  merchantId: "merchant-1",
  token: "checkout-token",
  status: "SUCCESS",
  iyziReferenceCode: "reference-1",
  iyziEventType: "CHECKOUT_FORM_AUTH",
  iyziEventTime: 1_700_000_000,
  iyziPaymentId: 123456,
};
const message =
  secret +
  body.iyziEventType +
  body.iyziPaymentId +
  body.token +
  body.paymentConversationId +
  body.status;
const signature = createHmac("sha256", secret).update(message).digest("hex");
assert.equal(verifyIyzicoHppWebhook(body, signature, secret), true);
assert.equal(verifyIyzicoHppWebhook(body, "0".repeat(64), secret), false);
assert.equal(verifyIyzicoHppWebhook({ ...body, status: "FAILURE" }, signature, secret), false);
console.log("iyzico HPP V3 signature verification OK");
