# llama.cpp Windows Ollama Bridge

Run a model already installed by Ollama with the native Windows Vulkan build of `llama.cpp`, without downloading a second GGUF copy.

This project was extracted from a real Windows desktop integration and reduced to a reusable, dependency-free Python package.

## What it does

- Resolves an Ollama model manifest to its local GGUF blob.
- Verifies the `GGUF` file header before launch.
- Downloads a pinned official `llama.cpp` Windows Vulkan archive.
- Verifies the archive with a pinned SHA-256 digest before extraction.
- Starts `llama-server.exe` on `127.0.0.1` only.
- Generates a random API key for every server process.
- Uses Vulkan GPU offload and exposes an OpenAI-compatible endpoint.

## Requirements

- Windows 10 or Windows 11 x64
- Python 3.10 or newer
- Ollama with a local model, for example `qwen2.5:latest`
- A Vulkan-capable GPU and current graphics driver

The bridge itself has no third-party Python runtime dependencies.

## Quick start

```powershell
ollama pull qwen2.5
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install .
ollama-llamacpp-bridge --model qwen2.5:latest
```

On first use, the command downloads the pinned official Vulkan runtime into `runtime/`. It does not download the model again.

The command prints output similar to:

```json
{
  "endpoint": "http://127.0.0.1:8081/v1/chat/completions",
  "api_key": "process-specific-secret"
}
```

Use the API key as a bearer token:

```powershell
$headers = @{ Authorization = "Bearer process-specific-secret" }
$body = @{
  model = "local-model"
  messages = @(@{ role = "user"; content = "Hello" })
} | ConvertTo-Json -Depth 5
Invoke-RestMethod http://127.0.0.1:8081/v1/chat/completions `
  -Method Post -Headers $headers -ContentType 'application/json' -Body $body
```

Treat the printed API key as sensitive. The server binds only to loopback and is not intended for LAN or internet exposure.

## Options

```text
--model qwen2.5:latest
--runtime runtime
--port 8081
--context 4096
--threads 14
--gpu-layers 99
--install-only
```

If Ollama stores models elsewhere, set `OLLAMA_MODELS` to its models directory.

## Turkish / Türkçe

Bu araç, Ollama ile daha önce indirilmiş GGUF modeli ikinci kez indirmeden Windows Vulkan `llama.cpp` sunucusunda çalıştırır. Sunucu yalnızca `127.0.0.1` adresine bağlanır ve her çalıştırmada rastgele API anahtarı üretir.

```powershell
ollama pull qwen2.5
pip install .
ollama-llamacpp-bridge --model qwen2.5:latest
```

Ekrana yazılan API anahtarını gizli tutun. Araç LAN veya internet üzerinden doğrudan yayın yapmak için tasarlanmamıştır.

## Verification

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m unittest discover -s tests -v
```

## Upgrading llama.cpp

Runtime version and SHA-256 are intentionally pinned in `runtime.py`. To upgrade:

1. Select an official `ggml-org/llama.cpp` Windows Vulkan release asset.
2. Update `RELEASE`, `RUNTIME_URL`, and `RUNTIME_SHA256` together.
3. Run the tests and a real `/v1/chat/completions` request.
4. Review upstream release notes and licenses.

## License

This bridge is released under the MIT License. Downloaded `llama.cpp` binaries remain subject to their upstream licenses.
