# libGDX decision note

- Domain: Java cross-platform game development framework; not a full visual editor.
- Decision fit: choose when Java/JVM, explicit application lifecycle, desktop/mobile targets, and direct control over game screens/input are priorities.
- Architecture evidence: `gdx/src/com/badlogic/gdx/ApplicationListener.java` defines the application callbacks; `Game.java` and `Screen.java` provide screen-oriented organization; `InputProcessor.java` defines input callbacks. The repository is organized as Gradle modules and includes platform backends.
- Do not infer: ECS is not established as a built-in default from these sources. Select an ECS separately only when the project's needs justify it.
- Verification scope: README, API declarations, and archive paths inspected statically; no project was built or run. Example/test tree includes `tests/gdx-tests-android/src/com/badlogic/gdx/tests/android/`.
- Provenance: `C:\Users\emre\Downloads\libgdx-master.zip`; SHA-256 `f120789a7ed9976e7b68bec509b1d295b09a7e72db08a553532684d0822ad314`; archive root `libgdx-master/`; reviewed 2026-10-05.
- Use this note as a decision aid, not as a claim that every backend or target is equally maintained. Recheck current platform support and license before shipping.
