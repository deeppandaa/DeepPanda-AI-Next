#Requires -Version 5.1
<#
DeepPanda tek tik kurulum / geri yukleme.
_TASINABILIR klasorundeki yedegi sisteme geri yukler, Python ortamini kurar,
kurulumu calistirir ve masaustu kisayollarini olusturur.
#>

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$portable = Join-Path $root '_TASINABILIR'
$desktop = [Environment]::GetFolderPath('Desktop')

function Write-Step($n, $text) { Write-Host "[$n] $text" -ForegroundColor Cyan }
function Write-Ok($text) { Write-Host "    OK - $text" -ForegroundColor Green }
function Write-Skip($text) { Write-Host "    ATLANDI - $text" -ForegroundColor Yellow }

Write-Host ''
Write-Host '=== DeepPanda Kurulum ===' -ForegroundColor White
Write-Host ''

# 0) Onkontrol
Write-Step 0 'Gereklilik kontrolu'
$missing = @()
foreach ($item in @(
        @{ Path = $portable; Label = '_TASINABILIR yedegi' },
        @{ Path = (Join-Path $root 'DeepPanda-App\requirements.txt'); Label = 'requirements.txt' },
        @{ Path = (Join-Path $root 'ProgramLauncher\Programs'); Label = 'ProgramLauncher\Programs' }
    )) {
    if (Test-Path $item.Path) { Write-Ok $item.Label } else { $missing += $item.Label }
}
foreach ($label in $missing) { Write-Skip "$label eksik" }

# 1) Calisma verisi
Write-Step 1 'Calisma verisi geri yukleniyor (%LOCALAPPDATA%\DeepPanda)'
$srcData = Join-Path $portable 'LocalAppData-DeepPanda'
$dstData = Join-Path $env:LOCALAPPDATA 'DeepPanda'
if (Test-Path $srcData) {
    robocopy $srcData $dstData /E /NFL /NDL /NJH /NJS /R:1 /W:1 | Out-Null
    Write-Ok $dstData
} else {
    Write-Skip "$srcData bulunamadi"
}

# 2) Ollama modelleri
Write-Step 2 'Ollama modelleri geri yukleniyor (buyuk, zaman alir)'
$srcOllama = Join-Path $portable 'ollama-models'
$dstOllama = Join-Path $env:USERPROFILE '.ollama'
if (Test-Path $srcOllama) {
    robocopy $srcOllama $dstOllama /E /NFL /NDL /NJH /NJS /R:1 /W:1 | Out-Null
    Write-Ok $dstOllama
} else {
    Write-Skip "$srcOllama bulunamadi"
}

# 3) Kayit defteri kimligi
Write-Step 3 'Kayit defteri kimligi geri yukleniyor'
$registryDir = Join-Path $portable 'registry'
if (Test-Path $registryDir) {
    $regFiles = Get-ChildItem $registryDir -Filter '*.reg' -ErrorAction SilentlyContinue
    foreach ($regFile in $regFiles) {
        $previous = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        reg.exe import $regFile.FullName 2>&1 | Out-Null
        $ErrorActionPreference = $previous
        Write-Ok $regFile.Name
    }
    if (-not $regFiles) { Write-Skip 'registry klasoru bos' }
} else {
    Write-Skip "$registryDir bulunamadi"
}

# 4) Python sanal ortami
Write-Step 4 'Python sanal ortami hazirlaniyor'
$venv = Join-Path $root '.venv'
$venvPython = Join-Path $venv 'Scripts\python.exe'
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Skip 'python bulunamadi - once Python 3.11+ kurun'
} else {
    if (-not (Test-Path $venvPython)) {
        python -m venv $venv
    }
    & $venvPython -m pip install --upgrade pip --quiet
    & $venvPython -m pip install -r (Join-Path $root 'DeepPanda-App\requirements.txt') --quiet
    Write-Ok '.venv + bagimliliklar'
}

# 5) Uygulama kurulumu
Write-Step 5 'DeepPanda kurulumu'
$setup = Join-Path $root 'DeepPanda_kurulum.exe'
if (Test-Path $setup) {
    $staleShortcuts = @(
        'DeepPanda Panel.lnk',
        'DeepPanda Panel (Proje).lnk',
        'DeepPanda (Gelistirme).lnk'
    )
    foreach ($shortcutName in $staleShortcuts) {
        $shortcutPath = Join-Path $desktop $shortcutName
        if (Test-Path $shortcutPath) { Remove-Item $shortcutPath -Force }
    }
    Write-Host '    Kurulum sihirbazi aciliyor, tamamlayip devam edin...' -ForegroundColor Gray
    Start-Process $setup -Wait
    Write-Ok 'kurulum tamamlandi'
} else {
    Write-Skip 'DeepPanda_kurulum.exe bulunamadi'
}

Write-Host ''
Write-Host 'KURULUM TAMAMLANDI' -ForegroundColor Green
Write-Host ''
