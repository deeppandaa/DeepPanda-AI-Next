[CmdletBinding()]
param(
    [string]$WorkspaceRoot = '',
    [switch]$InstallOllama,
    [switch]$InstallMediaExtras
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Workspace = if ([string]::IsNullOrWhiteSpace($WorkspaceRoot)) { $Root } else { [IO.Path]::GetFullPath($WorkspaceRoot) }
$WorkspaceSetting = if ([string]::IsNullOrWhiteSpace($WorkspaceRoot)) { '.' } else { $Workspace }
$null = New-Item -ItemType Directory -Force -Path $Workspace
$Venv = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'
$ModelStore = Join-Path $Root 'AI-Runtimes\OllamaModels'
$MemoryRoot = Join-Path $Root 'data\memory'
$PackageRoot = Join-Path $Root 'packages'
$OllamaRoot = Join-Path $PackageRoot 'ollama'
$OllamaExe = Join-Path $OllamaRoot 'ollama.exe'
$FfmpegRoot = Join-Path $PackageRoot 'ffmpeg'
$FfmpegExe = Join-Path $FfmpegRoot 'ffmpeg.exe'
$BrowserRoot = Join-Path $PackageRoot 'playwright-browsers'
$CacheRoot = Join-Path $PackageRoot 'cache'
$PipCache = Join-Path $PackageRoot 'pip-cache'

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw 'Python Launcher (py) bulunamadi. Python 3.12+ kurun ve tekrar deneyin.'
}
if (-not (Test-Path $Python)) {
    & py -3 -m venv $Venv
    if ($LASTEXITCODE -ne 0) { throw 'Python sanal ortami olusturulamadi.' }
}

$env:PIP_CACHE_DIR = $PipCache
$env:PLAYWRIGHT_BROWSERS_PATH = $BrowserRoot
$env:HF_HOME = Join-Path $CacheRoot 'huggingface'
$env:TORCH_HOME = Join-Path $CacheRoot 'torch'
$env:PATH = "$OllamaRoot;$FfmpegRoot;$env:PATH"
New-Item -ItemType Directory -Force -Path $MemoryRoot, $ModelStore, $BrowserRoot, $env:HF_HOME, $env:TORCH_HOME, $PipCache, $FfmpegRoot | Out-Null

& $Python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip guncellenemedi.' }
$RequirementsFile = Join-Path $Root 'requirements-portable.txt'
if ($InstallMediaExtras) { $RequirementsFile = Join-Path $Root 'requirements.txt' }
& $Python -m pip install -r $RequirementsFile
if ($LASTEXITCODE -ne 0) { throw 'Python paketleri kurulamadi.' }
& $Python -m playwright install chromium
if ($LASTEXITCODE -ne 0) { throw 'Playwright Chromium kurulamadi.' }

if (-not (Test-Path $OllamaExe)) {
    $InstalledOllama = Get-Command ollama -ErrorAction SilentlyContinue
    if (-not $InstalledOllama -and $InstallOllama) {
        $Winget = Get-Command winget -ErrorAction SilentlyContinue
        if (-not $Winget) { throw 'Ollama kurulumu istendi ancak winget bulunamadi.' }
        & $Winget.Source install --id Ollama.Ollama --exact --source winget --accept-source-agreements --accept-package-agreements --silent
        if ($LASTEXITCODE -ne 0) { throw 'Ollama winget ile kurulamadi.' }
        $InstalledPath = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
        if (Test-Path $InstalledPath) { $InstalledOllama = Get-Item $InstalledPath }
        if (-not $InstalledOllama) { $InstalledOllama = Get-Command ollama -ErrorAction SilentlyContinue }
    }
    if ($InstalledOllama) {
        $InstalledOllamaPath = if ($InstalledOllama.Source) { $InstalledOllama.Source } else { $InstalledOllama.FullName }
        New-Item -ItemType Directory -Force -Path $OllamaRoot | Out-Null
        Copy-Item -Path (Join-Path (Split-Path $InstalledOllamaPath -Parent) '*') -Destination $OllamaRoot -Recurse -Force
    }
}

if (-not (Test-Path $FfmpegExe)) {
    $InstalledFfmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($InstalledFfmpeg) { Copy-Item -LiteralPath $InstalledFfmpeg.Source -Destination $FfmpegExe }
}

$EnvFile = Join-Path $Root '.env'
$ManagedSettings = [ordered]@{
    OLLAMA_BASE_URL = 'http://127.0.0.1:11434'
    OLLAMA_MODEL = 'qwen3.6:latest'
    OLLAMA_EMBED_MODEL = 'nomic-embed-text'
    WORKSPACE_ROOT = $WorkspaceSetting
    WORKSPACE_EXCLUDED_DIRS = 'DeepPanda-App'
    MEMORY_DB = 'data/memory/memory.db'
    IMAGE_MODEL_PATH = 'models/tiny-sd'
    VIDEO_MODEL_PATH = 'models/text-to-video-ms-1.7b'
    PIPER_MODEL_PATH = 'models/piper-voices/tr_TR-dfki-medium/tr_TR-dfki-medium.onnx'
    OLLAMA_EXECUTABLE = 'packages/ollama/ollama.exe'
    FFMPEG_EXECUTABLE = 'packages/ffmpeg/ffmpeg.exe'
    PLAYWRIGHT_BROWSERS_PATH = 'packages/playwright-browsers'
    HF_HOME = 'packages/cache/huggingface'
    TORCH_HOME = 'packages/cache/torch'
    PIP_CACHE_DIR = 'packages/pip-cache'
    MAX_UPLOAD_MB = '265'
    AGENT_DEV_MODE = 'workspace'
    REQUIRE_MEMORY_APPROVAL = 'off'
    LICENSE_ENFORCEMENT = 'on'
}
$PreservedLines = @()
if (Test-Path $EnvFile) {
    foreach ($Line in Get-Content -LiteralPath $EnvFile) {
        if ($Line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=') {
            if ($ManagedSettings.Contains($Matches[1])) { continue }
        }
        $PreservedLines += $Line
    }
}
$GeneratedLines = foreach ($Name in $ManagedSettings.Keys) { "$Name=$($ManagedSettings[$Name])" }
@($PreservedLines) + @($GeneratedLines) | Set-Content -LiteralPath $EnvFile -Encoding utf8

Write-Output "Kurulum hazir: $Root"
Write-Output "Python ortami: $Venv"
Write-Output "Model dizini: $ModelStore"
if (-not (Test-Path $OllamaExe)) { Write-Output 'Ollama eksik. Kurmak icin: .\setup_portable.ps1 -InstallOllama' }
Write-Output 'Qwen modeli setup UI uzerinden ayri onayla indirilebilir; model kurulumda otomatik indirilmez.'
if (-not $InstallMediaExtras) { Write-Output 'Agir medya paketleri istege bagli: .\setup_portable.ps1 -InstallMediaExtras' }
Write-Output 'Baslatmak icin: .\Start-LocalQwenAgent.cmd'