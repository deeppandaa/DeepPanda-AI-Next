import tempfile
import unittest
from pathlib import Path

from services.app_settings_service import AppSettingsService
from services.i18n_service import I18nService


class I18nServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.original_path = AppSettingsService.SETTINGS_PATH
        AppSettingsService.SETTINGS_PATH = Path(self.temp_dir.name) / "settings.json"

    def tearDown(self):
        AppSettingsService.SETTINGS_PATH = self.original_path
        self.temp_dir.cleanup()

    def test_language_selection_persists(self):
        I18nService.set_language("English")
        self.assertEqual("en", I18nService.language())
        self.assertEqual("Quick Support", I18nService.t("nav.support"))
        self.assertEqual("English", I18nService.language_label())

    def test_german_and_turkish_translations(self):
        I18nService.set_language("de")
        self.assertEqual("Einstellungen", I18nService.t("nav.settings"))
        I18nService.set_language("tr")
        self.assertEqual("Ayarlar", I18nService.t("nav.settings"))

    def test_missing_key_falls_back_to_key(self):
        I18nService.set_language("en")
        self.assertEqual("unknown.key", I18nService.t("unknown.key"))


if __name__ == "__main__":
    unittest.main()
