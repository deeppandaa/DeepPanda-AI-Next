"""
DeepPanda - Ana Pencere (GUI Yönetimi)
"""

import customtkinter as ctk
import winsound
from tkinter import messagebox
from typing import Optional, Dict

from gui.dashboard import DashboardView
from gui.settings_panel import SettingsPanel
from gui.security_view import SecurityView
from gui.log_view import LogView
from gui.serial_view import SerialView
from gui.driver_view import DriverView
from gui.sound_view import SoundView
from services.log_service import LogService
from gui.advanced_system_view import AdvancedSystemView
from gui.remote_support_view import RemoteSupportView
from gui.it_operations_view import ITOperationsView
from gui.repair_capsule_view import RepairCapsuleView
from gui.guided_support_view import GuidedSupportView
from gui.tools_hub_view import ToolsHubView
from gui.programs_view import ProgramsView
from gui.simplewall_view import SimplewallView
from gui.ai_assistant_view import AIAssistantView
from gui.carm_service_view import CArmServiceView
from gui.work_orders_view import WorkOrdersView
from services.hardware_monitor import HardwareMonitor
from services.app_settings_service import AppSettingsService
from services.i18n_service import I18nService
from services.license_service import LicenseService
from services.control_plane_agent_service import ControlPlaneAgentService
from services.work_order_service import WorkOrderService
from services.auto_repair_orchestrator import AutoRepairOrchestrator
from services.serial_service import SerialService
from core.lan_remote import LANRemoteServer


class MainWindow:
    PRIMARY = "#4F8CC9"
    SIDEBAR_BG = "#17202B"
    MAIN_BG = "#202A35"
    TEXT_PRIMARY = "#F2F5F7"
    TEXT_SECONDARY = "#AEB9C4"
    ACTIVE_BTN_BG = "#2B4055"

    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("DeepPanda")
        self.root.geometry("1280x760")
        self.root.configure(fg_color=self.MAIN_BG)

        # Servisler
        self.monitor = HardwareMonitor()
        self.license_service = LicenseService()
        self.license_status = self.license_service.status()
        self.control_plane_agent = ControlPlaneAgentService()
        self.auto_repair = AutoRepairOrchestrator(event_sink=self.control_plane_agent.send_event)
        install_settings = AppSettingsService.load()
        self.install_profile = str(install_settings.get("install_profile", "administrator"))
        self.enabled_modules = set(install_settings.get("enabled_modules", AppSettingsService.ALLOWED_MODULES))
        self.enabled_modules.add("work_orders")
        self.enabled_tools = set(install_settings.get("enabled_tools", AppSettingsService.ALLOWED_TOOLS))
        self.current_view: Optional[object] = None
        self.nav_buttons: Dict[str, ctk.CTkButton] = {}

        # LAN Uzak Yönetim Sunucusunu Başlat
        self.lan_server = LANRemoteServer()
        try:
            self.lan_server.start()
        except Exception as e:
            LogService.add_log("ERROR", f"LAN Sunucusu baslatiladi: {e}", "Ag")

        # Pencere kapatma olayını yakala (Graceful Shutdown)
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        self._setup_ui()
        self.root.after(50, self._present_window)

        self._show_initial_view()
        self._start_monitoring_loop()
        self.control_plane_agent.start(self._current_risk_score)
        self.work_order_service = WorkOrderService()
        self.work_order_service.start_notifications(self._notify_work_orders)

    def _present_window(self):
        """Bring the main window to the foreground on startup."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            self.root.attributes("-topmost", True)
            self.root.after(250, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def _setup_ui(self):
        self.root.grid_columnconfigure(0, weight=0)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_content_area()

    def _build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self.root, fg_color=self.SIDEBAR_BG, width=220, corner_radius=6)
        self.sidebar.grid(row=0, column=0, sticky="ns", pady=12, padx=(12, 6))
        self.sidebar.grid_propagate(False)

        title = ctk.CTkLabel(
            self.sidebar,
            text="DEEPPANDA",
            font=ctk.CTkFont(size=17, weight="bold"),
            fg_color="#243548",
            text_color=self.TEXT_PRIMARY,
            corner_radius=5,
            padx=15,
            pady=10,
        )
        title.pack(pady=(15, 10), fill="x", padx=10)

        nav_items = [
            ("dashboard", I18nService.t("nav.home"), self._show_dashboard),
            ("work_orders", "İş Emirleri", self._show_work_orders),
            ("support", I18nService.t("nav.support"), self._show_guided_support),
            ("capsules", I18nService.t("nav.repair"), self._show_repair_capsules),
            ("it", I18nService.t("nav.it"), self._show_it_operations),
            ("ai", "AI Asistan", self._show_ai_assistant),
            ("programs", I18nService.t("nav.programs"), self._show_programs),
            ("medical", "C Kollu-Rontgen", self._show_carm_service),
            ("tools", I18nService.t("nav.tools"), self._show_tools_hub),
            ("logs", I18nService.t("nav.logs"), self._show_logs),
            ("settings", I18nService.t("nav.settings"), self._show_settings),
        ]

        for key, label_text, callback in nav_items:
            if key not in self.enabled_modules:
                continue
            btn = ctk.CTkButton(
                self.sidebar,
                text=label_text,
                font=ctk.CTkFont(size=15),
                fg_color="transparent",
                text_color=self.TEXT_SECONDARY,
                hover_color="#223244",
                corner_radius=5,
                height=40,
                anchor="w",
                command=callback,
            )
            btn.pack(pady=(0, 4), fill="x", padx=15)
            self.nav_buttons[key] = btn

        if "work_orders" not in self.nav_buttons:
            btn = ctk.CTkButton(
                self.sidebar,
                text="İş Emirleri",
                font=ctk.CTkFont(size=15),
                fg_color="transparent",
                text_color=self.TEXT_SECONDARY,
                hover_color="#223244",
                corner_radius=5,
                height=40,
                anchor="w",
                command=self._show_work_orders,
            )
            btn.pack(pady=(0, 4), fill="x", padx=15)
            self.nav_buttons["work_orders"] = btn

        self.language_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=list(I18nService.LANGUAGES.keys()),
            command=self._change_language,
            width=180,
        )
        self.language_menu.set(I18nService.language_label())
        self.language_menu.pack(side="bottom", pady=16, padx=15)
        plan = str(self.license_status.get("plan", "trial"))
        if plan == "trial":
            license_text = f"Trial: {self.license_status.get('remaining_days', 0)} days"
        elif plan == "annual":
            license_text = "License: 1 year"
        elif plan == "unlimited":
            license_text = "License: Unlimited"
        elif plan == "enterprise":
            license_text = "License: Enterprise"
        else:
            license_text = "License required"
        self.license_badge = ctk.CTkLabel(
            self.sidebar,
            text=license_text,
            text_color="#86B6A3" if self.license_status.get("active") else "#D98282",
        )
        self.license_badge.pack(side="bottom", padx=15)

    def _show_initial_view(self):
        if "support" in self.enabled_modules:
            self._show_guided_support()
        else:
            self._show_dashboard()

    def _change_language(self, selected: str):
        I18nService.set_language(selected)
        self.sidebar.destroy()
        self.content_frame.destroy()
        self.nav_buttons = {}
        self._setup_ui()
        self._show_initial_view()

    def _setActive_button(self, active_key: str):
        """Aktif sekmeyi görsel olarak vurgular."""
        for key, btn in self.nav_buttons.items():
            if key == active_key:
                btn.configure(fg_color=self.ACTIVE_BTN_BG, text_color=self.PRIMARY)
            else:
                btn.configure(fg_color="transparent", text_color=self.TEXT_SECONDARY)

    def _build_content_area(self):
        self.content_frame = ctk.CTkFrame(self.root, fg_color=self.MAIN_BG, corner_radius=6)
        self.content_frame.grid(row=0, column=1, sticky="nsew", pady=12, padx=(6, 12))
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)

    def _clear_content(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.current_view = None

    def _show_dashboard(self):
        self._clear_content()
        self._setActive_button("dashboard")
        self.current_view = DashboardView(parent=self.content_frame)

    def _show_work_orders(self):
        self._clear_content()
        self._setActive_button("work_orders")
        self.current_view = WorkOrdersView(parent=self.content_frame)

    def _notify_work_orders(self, orders):
        def show():
            try: winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            except Exception: self.root.bell()
            self._show_work_orders()
            messagebox.showinfo("Yeni iş emri", f"{len(orders)} yeni iş emri geldi.")
        self.root.after(0, show)

    def _show_settings(self):
        self._clear_content()
        self._setActive_button("settings")
        self.current_view = SettingsPanel(parent=self.content_frame)

    def _show_security(self):
        self._clear_content()
        self._setActive_button("security")
        self.current_view = SecurityView(parent=self.content_frame)

    def _show_logs(self):
        self._clear_content()
        self._setActive_button("logs")
        self.current_view = LogView(parent=self.content_frame)

    def _show_serial(self):
        self._clear_content()
        self._setActive_button("serial")
        self.current_view = SerialView(parent=self.content_frame)

    def _show_drivers(self):
        self._clear_content()
        self._setActive_button("drivers")
        self.current_view = DriverView(parent=self.content_frame)

    def _show_sound(self):
        self._clear_content()
        self._setActive_button("sound")
        self.current_view = SoundView(parent=self.content_frame)

    def _show_advanced_system(self):
        self._clear_content()
        self._setActive_button("advanced")
        self.current_view = AdvancedSystemView(parent=self.content_frame)

    def _show_remote_support(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("tools")
        self.current_view = RemoteSupportView(parent=self.content_frame)

    def _show_guided_support(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("support")
        self.current_view = GuidedSupportView(
            parent=self.content_frame,
            open_advanced=self._show_remote_support,
            open_capsules=self._show_repair_capsules,
        )

    def _show_it_operations(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("it")
        self.current_view = ITOperationsView(parent=self.content_frame)

    def _show_ai_assistant(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("ai")
        self.current_view = AIAssistantView(parent=self.content_frame)

    def _show_repair_capsules(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("capsules")
        self.current_view = RepairCapsuleView(parent=self.content_frame)

    def _show_programs(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("programs")
        self.current_view = ProgramsView(parent=self.content_frame)

    def _show_carm_service(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("medical")
        self.current_view = CArmServiceView(parent=self.content_frame)

    def _show_tool_view(self, view_class):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("tools")
        self.current_view = view_class(parent=self.content_frame)

    def _show_tools_hub(self):
        if not self._ensure_license():
            return
        self._clear_content()
        self._setActive_button("tools")
        available_tools = [
            ("advanced_support", "Gelismis Teknik Servis", "Paket, registry, komut ve uzak bilgisayar yonetimi.", self._show_remote_support),
            ("security", "Guvenlik", "Guvenlik kontrolleri ve koruma araclari.", lambda: self._show_tool_view(SecurityView)),
            ("simplewall", "simplewall Ag Filtresi", "Windows Filtering Platform kurallarini yonetin.", lambda: self._show_tool_view(SimplewallView)),
            ("drivers", "Suruculer ve GPU", "Driver ve ekran karti bilgileri.", lambda: self._show_tool_view(DriverView)),
            ("sound", "Ses Cihazlari", "Ses aygitlari ve test araclari.", lambda: self._show_tool_view(SoundView)),
            ("serial", "Seri Port", "COM portlari ve seri cihazlar.", lambda: self._show_tool_view(SerialView)),
            ("windows_tools", "Arac Paketi", "Gelismis Windows yonetim araclari.", lambda: self._show_tool_view(AdvancedSystemView)),
        ]
        tools = [(name, description, callback) for key, name, description, callback in available_tools if key in self.enabled_tools]
        self.current_view = ToolsHubView(parent=self.content_frame, tools=tools)

    def _ensure_license(self) -> bool:
        self.license_status = self.license_service.status()
        if self.license_status.get("active"):
            return True
        self._show_settings()
        messagebox.showwarning(
            I18nService.t("license.title"),
            str(self.license_status.get("message", I18nService.t("license.invalid"))),
            parent=self.root,
        )
        return False

    def _start_monitoring_loop(self):
        # Sadece Dashboard açıkken donanım metriklerini güncelle
        if isinstance(self.current_view, DashboardView):
            try:
                cpu_data = self.monitor.get_cpu_info()
                ram_data = self.monitor.get_ram_info()
                disk_data = self.monitor.get_disk_info()
                net_data = getattr(self.monitor, "get_network_info", lambda: None)()

                if hasattr(self.current_view, "update_metrics"):
                    self.current_view.update_metrics(
                        cpu=cpu_data, ram=ram_data, disks=disk_data, net=net_data
                    )
                main_disk = disk_data[0] if disk_data else None
                self.auto_repair.submit_snapshot(
                    {
                        "cpu_percent": float(getattr(cpu_data, "usage_percent", 0.0)),
                        "memory_percent": float(getattr(ram_data, "usage_percent", 0.0)),
                        "disk_percent": float(getattr(main_disk, "usage_percent", 0.0)),
                        "disk_path": str(getattr(main_disk, "path", "")),
                        "usb_ports": SerialService.list_available_ports(),
                    }
                )
            except Exception as e:
                print(f"[Monitoring Error]: {e}")

        # Döngüyü devam ettir (ayar panelindeki yenileme aralığını kullan)
        interval_sec = float(AppSettingsService.load().get("refresh_interval", 1.5))
        interval_ms = max(500, int(interval_sec * 1000))
        self.root.after(interval_ms, self._start_monitoring_loop)

    def _current_risk_score(self) -> int:
        if isinstance(self.current_view, DashboardView):
            result = getattr(self.current_view, "_latest_health_result", None) or {}
            return int(result.get("risk_score", 0) or 0)
        return 0

    def _on_closing(self):
        self.work_order_service.stop_notifications()
        """Uygulama kapatılırken arka plan servislerini temizler."""
        print("[SystemCore] Kapatılıyor...")
        try:
            if hasattr(self.lan_server, "stop"):
                self.lan_server.stop()
        except Exception as e:
            print(f"[Shutdown Error]: {e}")
        self.control_plane_agent.stop()
        
        self.root.destroy()

    def run(self):
        self.root.mainloop()