"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { LockKeyhole, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: form.get("email"), password: form.get("password") }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.message ?? "Giriş başarısız.");
      setBusy(false);
      return;
    }
    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <main className="login-shell">
      <section className="login-context">
        <div className="brand-lockup"><ShieldCheck size={24} /> VANA RESCUEOPS</div>
        <h1>Teknik operasyonlar için tek kontrol düzlemi.</h1>
        <p>Cihaz filoları, teknisyen yetkileri, lisanslar ve denetim kayıtları aynı organizasyon sınırları içinde yönetilir.</p>
        <dl className="security-facts">
          <div><dt>TLS</dt><dd>Agent iletişimi</dd></div>
          <div><dt>RBAC</dt><dd>Rol bazlı erişim</dd></div>
          <div><dt>Audit</dt><dd>İşlem izi</dd></div>
        </dl>
      </section>
      <section className="login-panel">
        <form onSubmit={submit} className="login-form">
          <LockKeyhole size={28} />
          <div><h2>Yönetim paneli</h2><p>Kurumsal hesabınızla giriş yapın.</p></div>
          <label>E-posta<input name="email" type="email" autoComplete="username" required /></label>
          <label>Parola<input name="password" type="password" autoComplete="current-password" minLength={8} required /></label>
          {message && <p className="form-error">{message}</p>}
          <button type="submit" disabled={busy}>{busy ? "Kontrol ediliyor..." : "Giriş yap"}</button>
        </form>
      </section>
    </main>
  );
}
