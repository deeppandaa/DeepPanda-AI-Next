"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { KeyRound, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const data = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: data.get("email"), password: data.get("password") }),
    });
    setBusy(false);
    if (!response.ok) return setError("E-posta veya parola hatalı.");
    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <main className="login-page">
      <section className="login-brand">
        <div className="brand-mark"><ShieldCheck size={28} /></div>
        <p className="eyebrow">VANA RESCUEOPS</p>
        <h1>Teknik operasyon merkezi</h1>
        <p>Cihaz filonuzu, teknisyenleri, müşterileri ve lisansları tek güvenli alandan yönetin.</p>
        <div className="trust-line"><span /> TLS cihaz iletişimi <span /> Tenant izolasyonu <span /> Denetim kaydı</div>
      </section>
      <section className="login-panel">
        <form onSubmit={submit}>
          <KeyRound size={25} />
          <h2>Yönetim paneline giriş</h2>
          <p>Firma hesabınızla devam edin.</p>
          <label>E-posta<input name="email" type="email" autoComplete="email" required /></label>
          <label>Parola<input name="password" type="password" autoComplete="current-password" minLength={8} required /></label>
          {error && <div className="form-error">{error}</div>}
          <button disabled={busy}>{busy ? "Doğrulanıyor..." : "Giriş yap"}</button>
        </form>
      </section>
    </main>
  );
}
