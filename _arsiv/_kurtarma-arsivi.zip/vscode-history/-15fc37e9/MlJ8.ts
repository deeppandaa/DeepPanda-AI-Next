import { NextResponse } from "next/server";
import { z } from "zod";
import { query } from "@/lib/db";

const schema = z.object({
  companyName: z.string().trim().min(2).max(200),
  slug: z.string().trim().min(2).max(80).regex(/^[a-z0-9-]+$/),
  contactName: z.string().trim().min(2).max(160),
  email: z.string().email().max(254),
  phone: z.string().trim().max(40).optional(),
  plan: z.enum(["trial", "annual", "unlimited"]).default("trial"),
});

export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Şirket kayıt bilgilerini kontrol edin." }, { status: 400 });
  try {
    await query(`INSERT INTO organization_requests(company_name,slug,contact_name,contact_email,contact_phone,requested_plan)
      VALUES($1,$2,$3,$4,$5,$6)`, [parsed.data.companyName, parsed.data.slug, parsed.data.contactName, parsed.data.email.toLowerCase(), parsed.data.phone ?? "", parsed.data.plan]);
  } catch (error) {
    if ((error as { code?: string }).code === "23505") return NextResponse.json({ message: "Bu firma kodu için başvuru zaten var." }, { status: 409 });
    throw error;
  }
  return NextResponse.json({ ok: true, message: "Başvurunuz alındı. İnceleme sonrası iletişim kurulacak." }, { status: 201 });
}