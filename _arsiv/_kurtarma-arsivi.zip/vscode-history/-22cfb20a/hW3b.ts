import bcrypt from "bcryptjs";
import { createHash } from "crypto";
import { Pool } from "pg";

const required = (name: string) => {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required`);
  return value;
};

async function main() {
  const pool = new Pool({ connectionString: required("DATABASE_URL") });
  try {
  const organizationName = required("SEED_ORGANIZATION");
  const slug = required("SEED_SLUG");
  const ownerName = required("SEED_OWNER_NAME");
  const ownerEmail = required("SEED_OWNER_EMAIL").toLowerCase();
  const ownerPassword = required("SEED_OWNER_PASSWORD");
  const ownerRole = process.env.SEED_OWNER_ROLE ?? "owner";
  if (ownerPassword.length < 8) throw new Error("SEED_OWNER_PASSWORD must be at least 8 characters");
  if (process.env.NODE_ENV === "production" && ownerPassword === "12345678+") {
    throw new Error("SEED_OWNER_PASSWORD must be changed before production seeding");
  }
  if (!["owner", "admin"].includes(ownerRole)) throw new Error("SEED_OWNER_ROLE must be owner or admin");

  const organization = await pool.query<{ id: string }>(
    `INSERT INTO organizations (name,slug,plan,trial_ends_at)
     VALUES ($1,$2,'trial',now()+interval '30 days')
     ON CONFLICT (slug) DO UPDATE SET name=excluded.name RETURNING id`,
    [organizationName, slug],
  );
  const hash = await bcrypt.hash(ownerPassword, 12);
  await pool.query(
    `INSERT INTO users (organization_id,email,name,password_hash,role)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (organization_id,email) DO UPDATE SET
       name=excluded.name,password_hash=excluded.password_hash,role=excluded.role,active=true`,
    [organization.rows[0].id, ownerEmail, ownerName, hash, ownerRole],
  );
  const agentToken = required("SEED_AGENT_TOKEN");
  const tokenHash = createHash("sha256").update(agentToken).digest("hex");
  await pool.query(
    `INSERT INTO agent_credentials (organization_id,name,token_hash)
     VALUES ($1,'Default fleet token',$2)
     ON CONFLICT (token_hash) DO UPDATE SET organization_id=excluded.organization_id,active=true`,
    [organization.rows[0].id, tokenHash],
  );
    console.log(`Seed complete for ${ownerEmail}`);
  } finally {
    await pool.end();
  }
}

main().catch((error) => { console.error(error); process.exit(1); });
