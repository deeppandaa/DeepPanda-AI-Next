# core/engine.py
from typing import Dict, Any, Optional
from config import get_mode, Mode, DASHSCOPE_API_KEY, DASHSCOPE_BASE_URL
from core.ollama_client import OllamaClient
from openai import OpenAI


class HybridAIEngine:
    """App Moduna (Offline/Online/Hybrid) göre istekleri otomatik yönlendiren AI Motoru."""

    def __init__(self, api_key: Optional[str] = None):
        self.ollama_client = OllamaClient()
        self.api_key = api_key or DASHSCOPE_API_KEY
        self.base_url = DASHSCOPE_BASE_URL
        self._openai_client: Optional[OpenAI] = None

    @property
    def openai_client(self) -> Optional[OpenAI]:
        """OpenAI client nesnesini lazy-loading ile bir kez oluşturur ve hazırlar."""
        if self._openai_client is None and self.api_key:
            self._openai_client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
        return self._openai_client

    def set_api_key(self, api_key: str) -> None:
        """Dinamik API key güncellemesi için."""
        self.api_key = api_key.strip()
        self._openai_client = None  # Yeni key ile istemcinin tekrar oluşmasını sağla

    def is_configured(self) -> bool:
        """Sistemin mevcut modda çalışmaya hazır olup olmadığını kontrol eder."""
        mode = get_mode()
        if mode == Mode.OFFLINE:
            return True
        return bool(self.api_key and self.api_key.strip())

    def _build_prompt(self, system_summary: Dict[str, Any], user_question: Optional[str] = None) -> str:
        """Sistem analiz promptunu hazırlar."""
        prompt = f"""
Sen SystemCore v2 yapay zeka sistem uzmanısın.
Sistem Metrikleri:
{system_summary}

Görevin:
1. Kaynak kullanımlarını değerlendir.
2. Varsa darboğazları tespit et.
3. Kısa ve net Türkçe optimizasyon tavsiyeleri sun.
"""
        if user_question:
            prompt += f"\nKullanıcı Sorusu: {user_question}\n"
        return prompt

    def _run_offline(self, prompt: str) -> str:
        """Ollama üzerinden çevrimdışı analiz çalıştırır."""
        system_instruction = "Sen tecrübeli bir sistem yöneticisisin. Kısa, teknik ve Türkçe yanıtlar ver."
        res = self.ollama_client.generate(prompt=prompt, system_prompt=system_instruction)
        return f"🔒 [ÇEVRİMDIŞI MOD - Ollama]\n\n{res}"

    def _run_online(self, prompt: str) -> str:
        """Qwen API üzerinden çevrimiçi analiz çalıştırır."""
        if not self.openai_client:
            raise ValueError("DASHSCOPE_API_KEY bulunamadı veya API istemcisi başlatılamadı.")

        response = self.openai_client.chat.completions.create(
            model="qwen-max",
            messages=[
                {"role": "system", "content": "Sen bilge ve uzman bir sistem yöneticisisin."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=600
        )
        content = response.choices[0].message.content or "Yanıt alınamadı."
        return f"🌐 [ÇEVRİMİÇİ MOD - Qwen AI]\n\n{content}"

    def generate_optimization_recommendations(self, system_summary: Dict[str, Any], user_question: Optional[str] = None) -> str:
        """Sistem optimizasyonu için güvenli ve onay isteyerek öneriler üretir."""
        summary_text = "\n".join(f"- {key}: {value}" for key, value in system_summary.items())

        prompt = f"""
Sen SystemCore v2 sistem optimizasyon uzmanısın.
Aşağıdaki sistem durumu verisi var:
{summary_text}

Görev:
1. Kısa, teknik ve Türkçe öneriler üret.
2. Özellikle önbellek temizliği, geçici dosya / temp temizliği, gereksiz dosya ve rem boşaltma gibi güvenli optimizasyon adımlarını öner.
3. Stress altında olan alanlara dikkat çek.
4. Her öneriyi güvenli şekilde yaz, ancak hiçbir işlemi otomatik çalıştırma.
5. En sonunda mutlaka şunu ekle: "İşlemi yapmadan önce onay verin."
6. Kullanıcı onayı gelmeden hiçbir sistem değişikliği yapma.
"""

        if user_question:
            prompt += f"\nKullanıcı sorusu: {user_question}\n"

        mode = get_mode()
        if mode == Mode.OFFLINE:
            try:
                return self._run_offline(prompt)
            except Exception as e:
                return f"❌ Çevrimdışı optimizasyon önerisi hatası: {str(e)}"
        elif mode == Mode.HYBRID:
            try:
                return self._run_online(prompt)
            except Exception as online_err:
                try:
                    offline_res = self._run_offline(prompt)
                    return f"⚡ [HİBRİT MOD - Çevrimiçi Hata Verdi, Çevrimdışına Geçildi]\nUyarı: {str(online_err)}\n\n{offline_res}"
                except Exception as offline_err:
                    return f"❌ Hibrit optimizasyon hatası: {str(online_err)} | {str(offline_err)}"
        else:
            try:
                return self._run_online(prompt)
            except Exception as e:
                return f"❌ Çevrimiçi optimizasyon önerisi hatası: {str(e)}"

    def analyze_system(self, system_summary: Dict[str, Any], user_question: Optional[str] = None) -> str:
        """Çalışma moduna göre analizi ilgili servise yönlendirir."""
        mode = get_mode()
        prompt = self._build_prompt(system_summary, user_question)

        # 1. ÇEVRİMDIŞI MOD
        if mode == Mode.OFFLINE:
            try:
                return self._run_offline(prompt)
            except Exception as e:
                return f"❌ Çevrimdışı AI Hatası: {str(e)}"

        # 2. HİBRİT MOD (Önce Online dener, başarısız olursa Otomatik Offline'a geçer)
        elif mode == Mode.HYBRID:
            try:
                return self._run_online(prompt)
            except Exception as online_err:
                try:
                    offline_res = self._run_offline(prompt)
                    return f"⚡ [HİBRİT MOD - Çevrimiçi Hata Verdi, Çevrimdışına Geçildi]\nUyarı: {str(online_err)}\n\n{offline_res}"
                except Exception as offline_err:
                    return f"❌ Hibrit Mod Hatası (Hem Online hem Offline başarısız): {str(online_err)} | {str(offline_err)}"

        # 3. ÇEVRİMİÇİ MOD
        else:
            try:
                return self._run_online(prompt)
            except Exception as e:
                return f"❌ Çevrimiçi AI Hatası: {str(e)}"