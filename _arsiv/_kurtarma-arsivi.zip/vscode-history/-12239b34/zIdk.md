# Security Policy

## Supported versions

Only the latest commit is supported until the first stable release.

## Reporting a vulnerability

Do not open a public issue for a vulnerability that exposes credentials or enables remote access. Use GitHub's private vulnerability reporting feature when enabled on the repository.

## Security boundaries

- The server is intentionally bound to `127.0.0.1`.
- A random API key is generated for every process.
- The runtime download is accepted only after SHA-256 verification.
- Model files are read from the local Ollama store and are never uploaded.
- Do not bind the server to `0.0.0.0` without adding transport security, authentication, and firewall controls.
