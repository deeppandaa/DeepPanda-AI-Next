"""Windows-native llama.cpp server lifecycle management."""

from __future__ import annotations

import atexit
import json
import os
import secrets
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.error import URLError
from urllib.request import urlopen


class LlamaCppError(RuntimeError):
    pass


class LlamaCppService:
    HOST = "127.0.0.1"
    DEFAULT_PORT = 8081
    MODEL_ALIAS = "qwen2.5-local"
    MODEL_DIGEST = "sha256-2bada8a7450677000f678be90653b85d364de7db25eb5ea54136ada5f3933730"

    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        self.settings = settings or {}
        self._process: Optional[subprocess.Popen] = None
        self._log_handle = None
        self._lock = threading.RLock()
        self._api_key = secrets.token_urlsafe(32)

    @property
    def endpoint(self) -> str:
        port = self._bounded_int("ai_llama_cpp_port", self.DEFAULT_PORT, 1024, 65535)
        return f"http://{self.HOST}:{port}/v1/chat/completions"

    def ensure_ready(self) -> Dict[str, str]:
        if self._healthy():
            return {"endpoint": self.endpoint, "model": self.MODEL_ALIAS, "api_key": self._api_key}

        with self._lock:
            if self._healthy():
                return {"endpoint": self.endpoint, "model": self.MODEL_ALIAS, "api_key": self._api_key}
            if self._process is not None and self._process.poll() is not None:
                self._close_log()
                self._process = None
            if self._process is None:
                self._start()
            self._wait_until_ready()
            return {"endpoint": self.endpoint, "model": self.MODEL_ALIAS, "api_key": self._api_key}

    def status(self) -> Dict[str, Any]:
        running = self._healthy()
        return {
            "running": running,
            "owned": self._process is not None and self._process.poll() is None,
            "endpoint": self.endpoint,
        }

    def stop(self) -> None:
        with self._lock:
            process = self._process
            self._process = None
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            self._close_log()

    def _start(self) -> None:
        executable = self._find_executable()
        model = self._find_model()
        port = self._bounded_int("ai_llama_cpp_port", self.DEFAULT_PORT, 1024, 65535)
        context = self._bounded_int("ai_llama_cpp_context", 4096, 512, 32768)
        threads = self._bounded_int("ai_llama_cpp_threads", 14, 1, max(1, os.cpu_count() or 1))
        gpu_layers = self._bounded_int("ai_llama_cpp_gpu_layers", 99, 0, 999)
        device = str(self.settings.get("ai_llama_cpp_device", "Vulkan0")).strip()
        log_path = self._log_path()
        self._trim_log(log_path)
        self._log_handle = log_path.open("ab")
        creation_flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        command = [
            str(executable),
            "--model", str(model),
            "--host", self.HOST,
            "--port", str(port),
            "--ctx-size", str(context),
            "--threads", str(threads),
            "--n-gpu-layers", str(gpu_layers),
            "--alias", self.MODEL_ALIAS,
            "--api-key", self._api_key,
        ]
        if device:
            command[command.index("--alias"):command.index("--alias")] = ["--device", device]
        try:
            self._process = subprocess.Popen(
                command,
                cwd=str(executable.parent),
                stdin=subprocess.DEVNULL,
                stdout=self._log_handle,
                stderr=subprocess.STDOUT,
                creationflags=creation_flags,
            )
        except OSError as exc:
            self._close_log()
            raise LlamaCppError(f"llama.cpp baslatilamadi: {exc}") from exc

    def _wait_until_ready(self) -> None:
        deadline = time.monotonic() + 120.0
        while time.monotonic() < deadline:
            if self._healthy():
                return
            if self._process is not None and self._process.poll() is not None:
                code = self._process.returncode
                self._close_log()
                self._process = None
                raise LlamaCppError(f"llama.cpp beklenmedik bicimde kapandi (kod {code}).")
            time.sleep(0.25)
        self.stop()
        raise LlamaCppError("llama.cpp 120 saniye icinde hazir olmadi.")

    def _healthy(self) -> bool:
        health_url = self.endpoint.rsplit("/v1/chat/completions", 1)[0] + "/health"
        try:
            with urlopen(health_url, timeout=0.5) as response:
                return response.status == 200
        except (OSError, URLError):
            return False

    def _find_executable(self) -> Path:
        configured = str(self.settings.get("ai_llama_cpp_executable", "")).strip()
        candidates = []
        if configured:
            candidates.append(Path(configured).expanduser())
        if getattr(sys, "frozen", False):
            bundle = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
            candidates.append(bundle / "AI-Runtimes" / "llama.cpp" / "windows-vulkan-x64" / "llama-server.exe")
        candidates.append(
            Path(__file__).resolve().parents[2]
            / "DeepPanda-AI"
            / "AI-Runtimes"
            / "DeepPanda-App"
            / "llama.cpp"
            / "windows-vulkan-x64"
            / "llama-server.exe"
        )
        candidates.append(
            Path(__file__).resolve().parent.parent
            / "AI-Runtimes" / "llama.cpp" / "windows-vulkan-x64" / "llama-server.exe"
        )
        for candidate in candidates:
            if candidate.is_file():
                return candidate
        raise LlamaCppError("llama-server.exe bulunamadi.")

    def _find_model(self) -> Path:
        configured = str(self.settings.get("ai_llama_cpp_model_path", "")).strip()
        if configured:
            model = Path(configured).expanduser()
            if model.is_file():
                return model
            raise LlamaCppError("Yapilandirilan llama.cpp modeli bulunamadi.")

        manifest = (
            Path.home() / ".ollama" / "models" / "manifests"
            / "registry.ollama.ai" / "library" / "qwen2.5" / "latest"
        )
        if manifest.is_file():
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                layer = next(
                    item for item in data.get("layers", [])
                    if item.get("mediaType") == "application/vnd.ollama.image.model"
                )
                digest = str(layer["digest"]).replace(":", "-")
                model = Path.home() / ".ollama" / "models" / "blobs" / digest
                if model.is_file():
                    return model
            except (OSError, ValueError, KeyError, StopIteration, TypeError):
                pass

        known_model = Path.home() / ".ollama" / "models" / "blobs" / self.MODEL_DIGEST
        if known_model.is_file():
            return known_model
        raise LlamaCppError("Ollama qwen2.5 GGUF modeli bulunamadi.")

    @staticmethod
    def _log_path() -> Path:
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DeepPanda"
        base.mkdir(parents=True, exist_ok=True)
        return base / "llama_cpp.log"

    @staticmethod
    def _trim_log(path: Path) -> None:
        if path.is_file() and path.stat().st_size > 262144:
            with path.open("rb") as source:
                source.seek(-262144, os.SEEK_END)
                tail = source.read()
            path.write_bytes(tail)

    def _close_log(self) -> None:
        if self._log_handle is not None:
            self._log_handle.close()
            self._log_handle = None

    def _bounded_int(self, key: str, default: int, minimum: int, maximum: int) -> int:
        try:
            value = int(self.settings.get(key, default))
        except (TypeError, ValueError):
            value = default
        return max(minimum, min(maximum, value))


_shared_service: Optional[LlamaCppService] = None


def get_llama_cpp_service(settings: Dict[str, Any]) -> LlamaCppService:
    global _shared_service
    if _shared_service is None:
        _shared_service = LlamaCppService(settings)
        atexit.register(_shared_service.stop)
    else:
        _shared_service.settings = settings
    return _shared_service