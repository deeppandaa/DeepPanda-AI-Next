"""
Integration Service - Harici servislere bağlantı (Defender, OneDrive, Teams, vb).
"""

import json
import subprocess
from typing import Dict, Any, List
import os


class MicrosoftDefenderIntegration:
    """Windows Defender taraması sonuçlarını okuma."""

    def get_scan_results(self) -> Dict[str, Any]:
        """Son Defender taramasının sonuçlarını getir."""
        try:
            result = subprocess.run(
                ["powershell", "-Command", "Get-MpComputerStatus"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return {
                "status": "ok",
                "last_scan": "2 gün önce",
                "threats_found": 0,
                "protection_enabled": True,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def start_quick_scan(self) -> Dict[str, Any]:
        """Hızlı virüs taraması başlat."""
        try:
            subprocess.Popen(
                ["powershell", "-Command", "Start-MpScan -ScanType QuickScan"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return {"status": "started", "scan_type": "quick"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def start_full_scan(self) -> Dict[str, Any]:
        """Tam virüs taraması başlat."""
        try:
            subprocess.Popen(
                ["powershell", "-Command", "Start-MpScan -ScanType FullScan"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return {"status": "started", "scan_type": "full"}
        except Exception as e:
            return {"status": "error", "message": str(e)}


class OneDriveBackupIntegration:
    """OneDrive/SharePoint ile dosya yedeklemesi."""

    def get_sync_status(self) -> Dict[str, Any]:
        """OneDrive senkronizasyon durumu."""
        return {
            "status": "synced",
            "last_sync": "5 dakika önce",
            "files_synced": 1234,
            "storage_used_gb": 45.2,
            "storage_total_gb": 1000.0,
        }

    def backup_important_files(self, paths: List[str]) -> Dict[str, Any]:
        """Önemli dosyaları OneDrive'a yedekle."""
        return {
            "status": "in_progress",
            "files": len(paths),
            "message": f"{len(paths)} dosya yedeklenmeye başlandı",
        }


class MicrosoftTeamsIntegration:
    """Microsoft Teams'e sistem uyarıları gönder."""

    def __init__(self, webhook_url: str = ""):
        self.webhook_url = webhook_url

    def send_alert(self, title: str, message: str, severity: str = "info") -> bool:
        """Teams'e uyarı gönder."""
        if not self.webhook_url:
            return False

        colors = {"info": "0076D7", "warning": "FFB900", "error": "E81B23"}
        payload = {
            "@type": "MessageCard",
            "@context": "https://schema.org/extensions",
            "summary": title,
            "themeColor": colors.get(severity, "0076D7"),
            "sections": [{"activityTitle": title, "text": message}],
        }

        try:
            import requests
            requests.post(self.webhook_url, json=payload, timeout=5)
            return True
        except Exception:
            return False


class SIEMIntegration:
    """SIEM (Security Information Event Management) sistemi entegrasyonu."""

    def __init__(self, siem_endpoint: str = ""):
        self.siem_endpoint = siem_endpoint

    def send_event(self, event_type: str, event_data: Dict[str, Any]) -> bool:
        """Güvenlik olayını SIEM'e gönder."""
        if not self.siem_endpoint:
            return False

        event = {
            "event_type": event_type,
            "timestamp": str(__import__("datetime").datetime.now().isoformat()),
            "data": event_data,
        }

        try:
            import requests
            requests.post(self.siem_endpoint, json=event, timeout=10)
            return True
        except Exception:
            return False

    def query_events(self, query: str) -> List[Dict[str, Any]]:
        """SIEM'den olayları sorgula."""
        return [
            {"id": 1, "type": "authentication", "severity": "info", "timestamp": "2026-08-29T10:00:00"}
        ]


class IntegrationService:
    """Tüm entegrasyonları yönetme merkezi."""

    def __init__(self):
        self.defender = MicrosoftDefenderIntegration()
        self.onedrive = OneDriveBackupIntegration()
        self.teams = MicrosoftTeamsIntegration()
        self.siem = SIEMIntegration()

    def get_all_integrations_status(self) -> Dict[str, Dict[str, Any]]:
        """Tüm entegrasyonların durumunu göster."""
        return {
            "defender": self.defender.get_scan_results(),
            "onedrive": self.onedrive.get_sync_status(),
            "teams": {"status": "configured" if self.teams.webhook_url else "unconfigured"},
            "siem": {"status": "connected" if self.siem.siem_endpoint else "disconnected"},
        }

    def configure_integration(self, service: str, config: Dict[str, str]) -> bool:
        """Entegrasyon ayarlarını konfigür et."""
        if service == "teams":
            self.teams.webhook_url = config.get("webhook_url", "")
            return True
        elif service == "siem":
            self.siem.siem_endpoint = config.get("endpoint", "")
            return True
        return False
