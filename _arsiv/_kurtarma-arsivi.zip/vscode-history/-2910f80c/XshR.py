#!/usr/bin/env python3
"""
Convert solver output to Kaggle submission format
"""

import json

# Load our predictions
with open('submission.json') as f:
    predictions = json.load(f)

# Convert to Kaggle format: [problem_id, {attempts}]
submission_data = []

for problem_id, prediction_list in predictions.items():
    # Kaggle expects multiple attempts (attempt_1, attempt_2, etc.)
    attempts = {}
    
    for idx, prediction in enumerate(prediction_list, 1):
        attempts[f"attempt_{idx}"] = prediction
    
    submission_data.append([problem_id, attempts])

# Save in correct format
with open('submission_formatted.json', 'w') as f:
    json.dump(submission_data, f)

print("[OK] Submission formatted")
print("  Problems: {}".format(len(submission_data)))
print("  Output: submission_formatted.json")
