"""Persistent application settings storage."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


class AppSettingsService:
    SETTINGS_PATH = Path(__file__).resolve().parent.parent / "app_settings.json"

    DEFAULTS: Dict[str, Any] = {
        "refresh_interval": 1.5,
        "notifications_enabled": True,
        "autostart_enabled": False,
        "thresholds": {
            "cpu": 85.0,
            "ram": 90.0,
            "disk": 90.0,
        },
        "security_pin": "1234",
        "support_admin_wait_seconds": 15,
        "support_protected_processes": [
            "anydesk.exe",
            "teamviewer.exe",
            "rustdesk.exe",
            "mstsc.exe",
            "code.exe",
            "devenv.exe",
            "systemcore.exe",
        ],
        "remote_access_username": "admin",
        "remote_access_password_hash": "",
        "remote_access_salt": "vana-v1",
        "remote_access_role": "admin",
    }

    @classmethod
    def load(cls) -> Dict[str, Any]:
        if not cls.SETTINGS_PATH.exists():
            return dict(cls.DEFAULTS)

        try:
            raw = json.loads(cls.SETTINGS_PATH.read_text(encoding="utf-8"))
            merged = dict(cls.DEFAULTS)
            merged.update(raw)
            merged_thresholds = dict(cls.DEFAULTS.get("thresholds", {}))
            merged_thresholds.update(raw.get("thresholds", {}))
            merged["thresholds"] = merged_thresholds
            return merged
        except Exception:
            return dict(cls.DEFAULTS)

    @classmethod
    def save(cls, settings: Dict[str, Any]) -> None:
        merged = dict(cls.DEFAULTS)
        merged.update(settings)
        merged_thresholds = dict(cls.DEFAULTS.get("thresholds", {}))
        merged_thresholds.update(settings.get("thresholds", {}))
        merged["thresholds"] = merged_thresholds
        cls.SETTINGS_PATH.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
