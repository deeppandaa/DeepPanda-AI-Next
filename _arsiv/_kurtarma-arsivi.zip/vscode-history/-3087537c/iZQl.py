"""
Audit Log Service - Tüm sistem değişikliklerinin denetim kaydını tutar.
"""

import sqlite3
import time
import json
from typing import Dict, List, Any
from datetime import datetime


class AuditLogService:
    """Sistem işlemlerinin ve konfigürasyon değişikliklerinin tam denetim kaydı."""

    def __init__(self, db_path: str = "systemcore.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Denetim tablosunu oluştur."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    user_id TEXT,
                    action TEXT NOT NULL,
                    resource TEXT,
                    old_value BLOB,
                    new_value BLOB,
                    status TEXT,
                    details TEXT,
                    ip_address TEXT
                )
            """)
            conn.commit()

    def log_action(
        self,
        action: str,
        resource: str,
        user_id: str = "system",
        old_value: Any = None,
        new_value: Any = None,
        status: str = "success",
        details: str = "",
    ):
        """Sistem işlemini denetim kaydına yaz."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO audit_logs 
                   (timestamp, user_id, action, resource, old_value, new_value, status, details)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    time.time(),
                    user_id,
                    action,
                    resource,
                    json.dumps(old_value) if old_value else None,
                    json.dumps(new_value) if new_value else None,
                    status,
                    details,
                ),
            )
            conn.commit()

    def get_recent_logs(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Son işlemleri getir."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT id, timestamp, user_id, action, resource, status 
                   FROM audit_logs ORDER BY timestamp DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [
            {
                "id": r[0],
                "timestamp": datetime.fromtimestamp(r[1]).isoformat(),
                "user": r[2],
                "action": r[3],
                "resource": r[4],
                "status": r[5],
            }
            for r in rows
        ]

    def search_logs(self, action: str = "", user_id: str = "", limit: int = 100) -> List[Dict[str, Any]]:
        """Denetim günlüğünde ara."""
        query = "SELECT * FROM audit_logs WHERE 1=1"
        params = []
        if action:
            query += " AND action LIKE ?"
            params.append(f"%{action}%")
        if user_id:
            query += " AND user_id = ?"
            params.append(user_id)
        query += f" ORDER BY timestamp DESC LIMIT {limit}"

        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(query, params).fetchall()
        return [{"id": r[0], "timestamp": r[1], "user": r[2], "action": r[3]} for r in rows]

    def export_audit_report(self, format: str = "json") -> str:
        """Denetim raporunu dışa aktar."""
        logs = self.get_recent_logs(limit=1000)
        if format == "json":
            return json.dumps(logs, indent=2)
        elif format == "csv":
            import csv
            import io
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=["timestamp", "user", "action", "resource", "status"])
            writer.writeheader()
            writer.writerows(logs)
            return output.getvalue()
        return json.dumps(logs)
