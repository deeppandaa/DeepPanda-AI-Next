import os
import subprocess
import tkinter as tk
from tkinter import ttk

PROGRAM_ROOT = r"C:\Users\emre\Desktop\Programs"

TOOLS = [
    {"name": "7-Zip", "path": r"C:\Users\emre\Desktop\Programs\7-Zip\7zFM.exe", "description": "Arşiv açma, sıkıştırma ve çıkarma için kullanılır."},
    {"name": "Total Commander", "path": r"C:\Users\emre\Desktop\Programs\Total Commander\TOTALCMD64.EXE", "description": "Dosya yönetimi ve hızlı erişim için kullanılır."},
    {"name": "WinMerge", "path": r"C:\Users\emre\Desktop\Programs\WinMerge\WinMergeU.exe", "description": "İki dosya veya klasörün farklarını gösterir."},
    {"name": "Notepad++", "path": r"C:\Users\emre\Desktop\Programs\Notepad++.lnk", "description": "Metin ve kod düzenleme için kullanılır."},
    {"name": "VeraCrypt", "path": r"C:\Users\emre\Desktop\Programs\VeraCrypt\VeraCrypt.exe", "description": "Disk ve klasörleri şifrelemek için kullanılır."},
    {"name": "Rufus", "path": r"C:\Users\emre\Desktop\Programs\Rufus\rufus.exe", "description": "USB kurulum medyası hazırlamak için kullanılır."},
    {"name": "Crystal Disk Info", "path": r"C:\Users\emre\Desktop\Programs\Crystal Disk Info\DiskInfo64.exe", "description": "SSD/HDD sağlığını izlemek için kullanılır."},
    {"name": "TreeSize", "path": r"C:\Users\emre\Desktop\Programs\TreeSize\TreeSize.exe", "description": "Disk kullanımını gösterir ve büyük dosyaları bulur."},
    {"name": "Macrium Reflect", "path": r"C:\Users\emre\Desktop\Programs\Macrium Reflect\Reflect.exe", "description": "Yedekleme ve sistem kurtarma için kullanılır."},
    {"name": "AOMEI Backupper", "path": r"C:\Users\emre\Desktop\Programs\AOMEI Backupper\AOMEIBackupper.exe", "description": "Yedekleme ve geri yükleme için kullanılır."},
    {"name": "Recuva", "path": r"C:\Users\emre\Desktop\Programs\Recuva\Recuva.exe", "description": "Silinmiş dosyaları kurtarmak için kullanılır."},
    {"name": "TestDisk", "path": r"C:\Users\emre\Desktop\Programs\Testdisk.lnk", "description": "Disk kurtarma ve bölüm analizi için kullanılır."},
    {"name": "Putty", "path": r"C:\Users\emre\Desktop\Programs\Putty\putty.exe", "description": "SSH / Telnet bağlantıları için kullanılır."},
    {"name": "WinSCP", "path": r"C:\Users\emre\Desktop\Programs\WinSCP\WinSCP.exe", "description": "FTP/SFTP ile dosya transferi için kullanılır."},
    {"name": "VLC", "path": r"C:\Users\emre\Desktop\Programs\VLC Media Player\vlc.exe", "description": "Medya dosyalarını açmak için kullanılır."},
    {"name": "SumatraPDF", "path": r"C:\Users\emre\Desktop\Programs\SumatraPDF\SumatraPDF.exe", "description": "Hafif PDF okuyucudur."},
    {"name": "HxD", "path": r"C:\Users\emre\Desktop\Programs\HxD.lnk", "description": "Hex düzenleyici; düşük seviyeli dosya incelemesi için kullanılır."},
    {"name": "DiskGenius", "path": r"C:\Users\emre\Desktop\Programs\DiskGenius\DiskGenius.exe", "description": "Disk bölümleri ve kurtarma için kullanılır."},
    {"name": "EasyBCD", "path": r"C:\Users\emre\Desktop\Programs\EasyBCD\EasyBCD.exe", "description": "Önyükleme menüsü ve Windows başlatma ayarları için kullanılır."},
    {"name": "WinNTSetup", "path": r"C:\Users\emre\Desktop\Programs\WinNTSetup\WinNTSetup.exe", "description": "Windows kurulumu ve sistem dosyaları için kullanılır."},
    {"name": "HWInfo", "path": r"C:\Users\emre\Desktop\Programs\HWInfo\HWiNFO64.exe", "description": "Sistem donanım bilgileri ve sıcaklığı gösterir."},
    {"name": "CPU-Z", "path": r"C:\Users\emre\Desktop\Programs\CPU-Z\CPU-Z.exe", "description": "İşlemci ve sistem detaylarını gösterir."},
    {"name": "GPU-Z", "path": r"C:\Users\emre\Desktop\Programs\GPU-Z\GPU-Z.exe", "description": "Grafik kartı bilgilerini gösterir."},
    {"name": "Speccy", "path": r"C:\Users\emre\Desktop\Programs\Speccy\Speccy.exe", "description": "Sistem sıcaklığı ve donanım özelliklerini gösterir."},
    {"name": "Sysinternals Suite", "path": r"C:\Users\emre\Desktop\Programs\Sysinternals Suite\Autoruns.exe", "description": "Başlangıç ve sistem davranışlarını incelemek için kullanılır."},
    {"name": "RegShot", "path": r"C:\Users\emre\Desktop\Programs\Registry Backup\RegShot.exe", "description": "Kayıt defteri değişikliklerini karşılaştırır."},
    {"name": "7-Zip File Manager", "path": r"C:\Users\emre\Desktop\Programs\7-Zip\7zFM.exe", "description": "Arşiv dosyalarını görüntüleme ve düzenleme için kullanılır."},
]


def normalize_path(p):
    if not p:
        return ""
    p = p.strip().strip('"')
    if os.path.exists(p):
        return p
    if os.path.exists(os.path.join(PROGRAM_ROOT, p)):
        return os.path.join(PROGRAM_ROOT, p)
    return p


def load_tools():
    items = []
    seen = set()
    for item in TOOLS:
        path = normalize_path(item["path"])
        if path and path not in seen:
            items.append({**item, "path": path})
            seen.add(path)

    if os.path.isdir(PROGRAM_ROOT):
        for root, _, files in os.walk(PROGRAM_ROOT):
            for file in files:
                low = file.lower()
                if low.endswith((".exe", ".lnk", ".bat", ".cmd")):
                    full = os.path.join(root, file)
                    if full in seen:
                        continue
                    items.append({
                        "name": os.path.splitext(file)[0],
                        "path": full,
                        "description": "Program klasöründen otomatik eklenen araç."
                    })
                    seen.add(full)
    return items


def launch(path):
    if not path:
        return
    target = path.strip().strip('"')
    if target.lower().endswith(".lnk"):
        os.startfile(target)
        return
    if os.path.isdir(target):
        os.startfile(target)
        return
    if os.path.exists(target):
        subprocess.Popen([target], shell=False)
        return
    print(f"Not found: {target}")


class LauncherWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Programlar Listesi")
        self.root.geometry("980x620")
        self.root.minsize(900, 520)

        tk.Label(root, text="Yüklenen yardımcı programlar", font=("Segoe UI", 18, "bold")).pack(pady=(18, 10))

        search_frame = tk.Frame(root)
        search_frame.pack(fill="x", padx=18, pady=(0, 8))
        tk.Label(search_frame, text="Ara:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.search = tk.Entry(search_frame, font=("Segoe UI", 11))
        self.search.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.search.bind("<KeyRelease>", self.filter_rows)

        columns = ("name", "description")
        self.tree = ttk.Treeview(root, columns=columns, show="headings", height=25)
        self.tree.heading("name", text="Program")
        self.tree.heading("description", text="Ne işe yarar?")
        self.tree.column("name", width=230, anchor="w")
        self.tree.column("description", width=680, anchor="w")
        self.tree.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.tree.bind("<Double-1>", self.on_double_click)

        self.status = tk.Label(root, text="Çift tıklayarak çalıştırın.", font=("Segoe UI", 10))
        self.status.pack(pady=(0, 8))

        self.items = load_tools()
        self.populate_rows(self.items)

    def populate_rows(self, items):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for item in items:
            self.tree.insert("", "end", values=(item["name"], item["description"]))

    def filter_rows(self, event):
        q = self.search.get().strip().lower()
        if not q:
            self.populate_rows(self.items)
            return
        filtered = [item for item in self.items if q in f"{item['name']} {item['description']}".lower()]
        self.populate_rows(filtered)

    def on_double_click(self, event):
        selection = self.tree.selection()
        if not selection:
            return
        idx = self.tree.index(selection[0])
        item = self.items[idx]
        self.status.config(text=f"Çalıştırılıyor: {item['name']}")
        launch(item["path"])


def main():
    root = tk.Tk()
    LauncherWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
