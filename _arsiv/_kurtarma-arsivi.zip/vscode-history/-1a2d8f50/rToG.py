import os
import subprocess
import tkinter as tk
from tkinter import ttk

PROGRAM_ROOT = r"C:\Users\emre\Desktop\Programs"

KNOWN_PROGRAMS = {
    "7-Zip": "Arşivler için ZIP/7z/RAR benzeri sıkıştırma ve açma aracı.",
    "7-Zip File Manager": "7-Zip arşiv dosyalarını görüntüleme ve düzenleme aracı.",
    "Aero Admin": "Yönetici yetkisi gerektiren işlemler için yardımcı admin aracı.",
    "AnyDesk": "Uzaktan masaüstü erişimi ve destek için kullanılan program.",
    "AOMEI Backupper": "Sistem yedekleme ve geri yükleme için güvenli yedekleme aracı.",
    "AOMEI Partition Assistant": "Disk bölümü oluşturma, düzenleme ve taşıma aracı.",
    "AquaKeyTest": "Klavye ve tuş giriş testi için kullanılan küçük araç.",
    "AttributeChanger": "Dosya ve klasör özniteliklerini değiştiren yardımcı program.",
    "Bootice": "Boot medya ve boot menüsü düzenleme aracı.",
    "CDBurnerXP": "CD/DVD yazma ve ISO yakma aracı.",
    "Change Keyboard Layout": "Klavye düzenini değiştirmenizi sağlayan yardımcı araç.",
    "ChkDskGUI": "Disk kontrolü ve hatalı sektör taraması için grafik arayüz.",
    "CPU-Z": "İşlemci, bellek, anakart ve sistem bilgilerini gösterir.",
    "Crystal Disk Info": "SSD/HDD sağlığını, sıcaklığı ve hata durumunu izler.",
    "Defraggler": "Disk birleştirme ve optimizasyonu için kullanılan araç.",
    "Dependency Walker": "DLL bağımlılıklarını ve çalıştırma sorunlarını inceleme aracı.",
    "DiskGenius": "Disk kurtarma, bölümleme ve veri kurtarma için güçlü araç.",
    "DMDE": "Disk, bölüm ve veri kurtarma için düşük seviyeli bir araç.",
    "DriveSnapshot": "Canlı sistem görüntüsü ve yedekleme için kullanılır.",
    "EaseUS Partition Master": "Disk bölümlerini yönetmek ve büyütmek için yardımcı araç.",
    "EasyBCD": "Windows önyükleme menüsü ve boot ayarları için kullanılır.",
    "Eraser": "Güvenli dosya silme ve tekrar yazma için araç.",
    "ESET Online Scanner": "Çevrimiçi virüs ve zararlı yazılım taraması için araç.",
    "ExamDiff": "Dosya ve klasör farklarını karşılaştırma aracı.",
    "FSViewer": "Resim ve belge görüntüleyici / hızlı görsel inceleme yazılımı.",
    "GPU-Z": "Grafik kartı ve ekran kartı detaylarını gösterir.",
    "GSmartControl": "SATA/SSD disk sağlığı ve SMART verilerini izler.",
    "HDDLLF": "Disk hataları ve sağlık durumu için özel araç.",
    "HDDScan": "HDD/SSD testleri ve sağlık kontrolü için araç.",
    "HDTune": "Disk performansı ve sağlık bilgisi için analiz aracı.",
    "HWInfo": "Sistem donanımı, sıcaklık, fan ve voltaj bilgilerini gösterir.",
    "HxD": "Hex düzenleyici; düşük seviyeli dosya inceleme ve düzenleme aracı.",
    "ImageUSB": "USB belleğe boot edilebilir imaj yazma aracı.",
    "IrfanView": "Hızlı resim görüntüleme ve düzenleme programı.",
    "Lazesoft Recovery Suite": "Sistem kurtarma, parola kurtarma ve onarım aracı.",
    "Linux Reader": "Linux dosya sistemlerini Windows üzerinde okuyup erişme aracı.",
    "Macrium Reflect": "Sistem yedekleme, geri yükleme ve görüntü oluşturma aracı.",
    "Macrorit Partition Expert": "Bölüm ekleme ve düzenleme için kullanılır.",
    "Macrorit Partition Extender": "Disk bölümlerini genişletmek için yardımcı araç.",
    "McAfee Stinger": "Tehdit taraması ve hızlı zararlı yazılım kontrolü için araç.",
    "Notepad++": "Metin, kod ve log dosyaları için güçlü düzenleyici.",
    "NTPWedit": "Windows parola ve kullanıcı hesabı düzenleme aracı.",
    "NVDA": "Ekran okuyucu; görme engelli kullanıcılar için yardımcı program.",
    "Puran Data Recovery": "Silinmiş dosya ve klasör kurtarma aracı.",
    "Puran File Recovery": "Dosya kurtarma için hafif ve hızlı araç.",
    "Putty": "SSH, Telnet ve serial bağlantı için güvenli terminal istemcisi.",
    "ReclaiMe Free RAID Recovery": "RAID ve disk yapısı kurtarma için uzman aracı.",
    "Recuva": "Silinmiş dosyaları geri getirme aracı.",
    "Registry Backup": "Kayıt defteri yedeği ve geri yükleme aracı.",
    "RegShot": "Kayıt defteri değişikliklerini kaydeder ve karşılaştırır.",
    "Rufus": "USB belleğe boot edilebilir kurulum medyası hazırlama aracı.",
    "Runtime DriveImage XML": "Disk görüntüsü ve yedekleme için kullanılan araç.",
    "ShowKeyPlus": "Windows ürün anahtarını gösteren yardımcı aracı.",
    "SoftMaker FreeOffice": "Word, Excel ve belge düzenleme için ofis paketi.",
    "Speccy": "Sistem sıcaklığı ve donanım detaylarını gösteren araç.",
    "SumatraPDF": "Hızlı ve hafif PDF okuyucu.",
    "Sysinternals Suite": "Sistem ve başlangıç davranışlarını incelemek için araçlar paketi.",
    "Testdisk": "Disk bölümü ve veri kurtarma için güçlü açık kaynak aracı.",
    "Total Commander": "Dosya yönetimi, hızlı erişim ve çoklu iş akışı için güçlü araç.",
    "TreeSize": "Disk kullanımını gösterir ve en büyük dosyaları bulur.",
    "Unstoppable Copier": "Bozuk veya kırık dosya kopyalama işlemleri için araç.",
    "VeraCrypt": "Disk ve klasörleri şifrelemek ve gizlemek için güvenli araç.",
    "Victoria": "Disk sağlık testi ve düşük seviyeli HDD/SSD test aracı.",
    "VLC Media Player": "Video ve ses dosyalarını oynatmak için çok yönlü medya oynatıcı.",
    "WesternDigital": "Western Digital disk yönetimi ve sağlığı için araçlar.",
    "Windows Login Unlocker": "Yerel kullanıcı girişi ve hesap kilit açma işlemleri için araç.",
    "WinMerge": "İki dosya veya klasörün farklarını karşılaştırma ve birleştirme aracı.",
    "WinNTSetup": "Windows kurulum ve sistem dosyaları için hazırlık aracı.",
    "WinSCP": "FTP/SFTP ile dosya transferi için güvenli araç.",
    "WordPad": "Hafif metin ve belge düzenleme aracı.",
}

TOOLS = [{"name": key, "path": os.path.join(PROGRAM_ROOT, key), "description": value} for key, value in KNOWN_PROGRAMS.items()]


def normalize_path(p):
    if not p:
        return ""
    p = p.strip().strip('"')
    if os.path.exists(p):
        return p
    if os.path.exists(os.path.join(PROGRAM_ROOT, p)):
        return os.path.join(PROGRAM_ROOT, p)
    return p


def load_tools():
    items = []
    seen = set()

    for item in TOOLS:
        path = normalize_path(item["path"])
        if path and path not in seen:
            items.append({"name": item["name"], "path": path, "description": item["description"]})
            seen.add(path)

    if os.path.isdir(PROGRAM_ROOT):
        for root, _, files in os.walk(PROGRAM_ROOT):
            for file in files:
                low = file.lower()
                if low.endswith((".exe", ".lnk", ".bat", ".cmd")):
                    full = os.path.join(root, file)
                    if full in seen:
                        continue
                    name = os.path.splitext(file)[0]
                    description = KNOWN_PROGRAMS.get(name, KNOWN_PROGRAMS.get(os.path.basename(root), "Program klasöründen otomatik eklenen araç."))
                    items.append({
                        "name": name,
                        "path": full,
                        "description": description
                    })
                    seen.add(full)

    return sorted(items, key=lambda x: x["name"].lower())


def launch(path):
    if not path:
        return
    target = path.strip().strip('"')
    if target.lower().endswith(".lnk"):
        os.startfile(target)
        return
    if os.path.isdir(target):
        os.startfile(target)
        return
    if os.path.exists(target):
        subprocess.Popen([target], shell=False)
        return
    print(f"Not found: {target}")


class LauncherWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Programlar Listesi")
        self.root.geometry("980x620")
        self.root.minsize(900, 520)

        tk.Label(root, text="Yüklenen yardımcı programlar", font=("Segoe UI", 18, "bold")).pack(pady=(18, 10))

        search_frame = tk.Frame(root)
        search_frame.pack(fill="x", padx=18, pady=(0, 8))
        tk.Label(search_frame, text="Ara:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.search = tk.Entry(search_frame, font=("Segoe UI", 11))
        self.search.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.search.bind("<KeyRelease>", self.filter_rows)

        columns = ("name", "description")
        self.tree = ttk.Treeview(root, columns=columns, show="headings", height=25)
        self.tree.heading("name", text="Program")
        self.tree.heading("description", text="Ne işe yarar?")
        self.tree.column("name", width=230, anchor="w")
        self.tree.column("description", width=680, anchor="w")
        self.tree.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.tree.bind("<Double-1>", self.on_double_click)

        self.status = tk.Label(root, text="Seçili görev: Yok", font=("Segoe UI", 10))
        self.status.pack(pady=(0, 8))

        action_frame = tk.Frame(root)
        action_frame.pack(fill="x", padx=18, pady=(0, 10))

        self.run_button = tk.Button(action_frame, text="Seçili görevi çalıştır", command=self.run_selected, font=("Segoe UI", 10, "bold"), bg="#2d7ff9", fg="white")
        self.run_button.pack(side="left", padx=(0, 8))

        self.ai_button = tk.Button(action_frame, text="Ollama ile görev çöz", command=self.run_ai_task, font=("Segoe UI", 10, "bold"), bg="#888888", fg="white", state="disabled")
        self.ai_button.pack(side="left")

        task_frame = tk.Frame(root)
        task_frame.pack(fill="x", padx=18, pady=(0, 8))
        tk.Label(task_frame, text="Görev / soru:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.task_entry = tk.Entry(task_frame, font=("Segoe UI", 11))
        self.task_entry.pack(side="left", fill="x", expand=True, padx=(8, 0))

        self.items = load_tools()
        self.populate_rows(self.items)

    def populate_rows(self, items):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for item in items:
            self.tree.insert("", "end", values=(item["name"], item["description"]))

    def filter_rows(self, event):
        q = self.search.get().strip().lower()
        if not q:
            self.populate_rows(self.items)
            return
        filtered = [item for item in self.items if q in f"{item['name']} {item['description']}".lower()]
        self.populate_rows(filtered)

    def on_double_click(self, event):
        selection = self.tree.selection()
        if not selection:
            return
        idx = self.tree.index(selection[0])
        item = self.items[idx]
        self.status.config(text=f"Görev seçildi: {item['name']} | {item['description']}")
        launch(item["path"])

    def run_selected(self):
        selection = self.tree.selection()
        if not selection:
            self.status.config(text="Önce bir görev seçin.")
            return
        idx = self.tree.index(selection[0])
        item = self.items[idx]
        self.status.config(text=f"Görev çalıştırılıyor: {item['name']} | {item['description']}")
        launch(item["path"])

    def run_ai_task(self):
        self.status.config(text="Ollama kapalı; AI modunu daha sonra açabilirsiniz.")


def main():
    root = tk.Tk()
    LauncherWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
