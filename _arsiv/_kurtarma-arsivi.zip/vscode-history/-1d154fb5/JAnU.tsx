"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Building2, LockKeyhole, MessageSquareWarning, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [toast, setToast] = useState<{ kind: "ok" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<"login" | "register" | "issue">("login");

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ organization: form.get("organization"), email: form.get("email"), password: form.get("password") }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.message ?? "Giriş başarısız.");
      setToast({ kind: "error", text: data.message ?? "Giriş başarısız." });
      setBusy(false);
      return;
    }
    setToast({ kind: "ok", text: "Giriş başarılı. Yönlendiriliyor…" });
    router.replace("/dashboard");
    router.refresh();
  }

  async function submitPublic(event: FormEvent<HTMLFormElement>, endpoint: string) {
    event.preventDefault(); setBusy(true); setMessage("");
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try {
      const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message ?? "İşlem tamamlanamadı.");
      setMessage(data.reference ? `${data.message} Referans: ${data.reference}` : data.message);
      setToast({ kind: "ok", text: data.reference ? `${data.message} Referans: ${data.reference}` : data.message });
      event.currentTarget.reset();
    } catch (error) {
      const err = error as Error;
      setMessage(err.message);
      setToast({ kind: "error", text: err.message });
    }
    finally { setBusy(false); }
  }

  return (
    <main className="login-shell">
      {toast && <div className={`toast-bar ${toast.kind}`} aria-live="polite">{toast.text}</div>}
      <section className="login-context">
        <div className="brand-lockup"><ShieldCheck size={24} /> DEEPPANDA</div>
        <h1>Teknik operasyonlar için tek kontrol düzlemi.</h1>
        <p>Cihaz filoları, teknisyen yetkileri, lisanslar ve denetim kayıtları aynı organizasyon sınırları içinde yönetilir.</p>
        <dl className="security-facts">
          <div><dt>TLS</dt><dd>Agent iletişimi</dd></div>
          <div><dt>RBAC</dt><dd>Rol bazlı erişim</dd></div>
          <div><dt>Audit</dt><dd>İşlem izi</dd></div>
        </dl>
      </section>
      <section className="login-panel">
        <div className="login-tabs" role="tablist" aria-label="Giriş sekmeleri">
          <button type="button" aria-pressed={view === "login"} className={view === "login" ? "active" : ""} onClick={() => { setView("login"); setMessage(""); }}>Giriş</button>
          <button type="button" aria-pressed={view === "register"} className={view === "register" ? "active" : ""} onClick={() => { setView("register"); setMessage(""); }}>Şirket kaydı</button>
          <button type="button" aria-pressed={view === "issue"} className={view === "issue" ? "active" : ""} onClick={() => { setView("issue"); setMessage(""); }}>Sorun bildir</button>
        </div>
        {view === "login" && <form onSubmit={submit} className="login-form">
          <LockKeyhole size={28} /><div><h2>Yönetim paneli</h2><p>Kurumsal hesabınızla giriş yapın.</p></div>
          <label>Firma kodu<input name="organization" type="text" placeholder="ornek-servis" autoComplete="organization" required /></label>
          <label>E-posta<input name="email" type="email" autoComplete="username" required /></label>
          <label>Parola<input name="password" type="password" autoComplete="current-password" minLength={8} required /></label>
          {message && <p className="form-error">{message}</p>}
          <button type="submit" disabled={busy}>{busy ? "Kontrol ediliyor..." : "Giriş yap"}</button>
        </form>}
        {view === "register" && <form onSubmit={(event) => submitPublic(event, "/api/public/register")} className="login-form"><Building2 size={28} /><div><h2>Şirket kaydı</h2><p>İş takibi ve saha operasyonu için başvuru bırakın.</p></div><label>Şirket adı<input name="companyName" required /></label><label>Firma kodu<input name="slug" placeholder="ornek-servis" pattern="[a-z0-9-]+" required /></label><label>Yetkili adı<input name="contactName" required /></label><label>E-posta<input name="email" type="email" required /></label><label>Telefon<input name="phone" /></label><label>Plan<select name="plan" defaultValue="trial"><option value="trial">Deneme</option><option value="annual">Yıllık lisans</option><option value="unlimited">Sınırsız</option></select></label>{message && <p className="form-error">{message}</p>}<button type="submit" disabled={busy}>{busy ? "Gönderiliyor..." : "Kayıt başvurusu gönder"}</button></form>}
        {view === "issue" && <form onSubmit={(event) => submitPublic(event, "/api/public/issues")} className="login-form"><MessageSquareWarning size={28} /><div><h2>Sorun bildir</h2><p>Giriş yapmadan teknik veya hesap sorunu iletin.</p></div><label>Şirket adı<input name="companyName" /></label><label>Ad soyad<input name="contactName" required /></label><label>E-posta<input name="email" type="email" required /></label><label>Kategori<select name="category" defaultValue="technical"><option value="technical">Teknik sorun</option><option value="account">Hesap / giriş</option><option value="billing">Ödeme / lisans</option><option value="other">Diğer</option></select></label><label>Konu<input name="subject" required minLength={3} /></label><label>Açıklama<textarea name="description" rows={4} required minLength={10} /></label>{message && <p className="form-error">{message}</p>}<button type="submit" disabled={busy}>{busy ? "Gönderiliyor..." : "Bildirimi gönder"}</button></form>}
      </section>
    </main>
  );
}
