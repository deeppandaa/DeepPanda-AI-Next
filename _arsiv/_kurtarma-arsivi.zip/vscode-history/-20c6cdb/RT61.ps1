param(
    [string]$TargetPath = "D:\ProgramLauncher"
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$exeSource = Join-Path $scriptDir "dist\ProgramLauncher.exe"
$readmeSource = Join-Path $scriptDir "README.txt"

if (-not (Test-Path $exeSource)) {
    Write-Error "ProgramLauncher.exe bulunamadı: $exeSource"
    exit 1
}

New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null
Copy-Item $exeSource (Join-Path $TargetPath "ProgramLauncher.exe") -Force

if (Test-Path $readmeSource) {
    Copy-Item $readmeSource (Join-Path $TargetPath "README.txt") -Force
}

Write-Host "Kurulum tamamlandı." -ForegroundColor Green
Write-Host "Hedef: $TargetPath" -ForegroundColor Cyan
