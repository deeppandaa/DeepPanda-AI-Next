"""
Audit Log View - Denetim günlüğü ve işlem geçmişi.
"""

import customtkinter as ctk
from tkinter import ttk
from typing import Callable


class AuditLogView:
    """Sistem işlemlerinin denetim günlüğü."""

    def __init__(self, parent: ctk.CTkFrame, on_action: Callable = None):
        self.parent = parent
        self.on_action = on_action

        self.frame = ctk.CTkFrame(parent, fg_color="transparent")
        self.frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Başlık
        title_label = ctk.CTkLabel(
            self.frame, text="📋 Denetim Günlüğü", font=("Segoe UI", 20, "bold")
        )
        title_label.pack(pady=(0, 15))

        # Filtre
        self._create_filters()

        # Günlük tablosu
        self._create_log_table()

        # Butonlar
        self._create_action_buttons()

    def _create_filters(self):
        """Filtre seçenekleri."""
        filter_frame = ctk.CTkFrame(self.frame)
        filter_frame.pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(filter_frame, text="Filtrele:").pack(side="left", padx=(0, 10))

        ctk.CTkComboBox(filter_frame, values=["Tümü", "Sistem", "Kullanıcı", "Otomasyon"]).pack(
            side="left", padx=5
        )

        ctk.CTkButton(
            filter_frame,
            text="🔍 Ara",
            command=lambda: self.on_action("search") if self.on_action else None,
        ).pack(side="left", padx=5)

    def _create_log_table(self):
        """Günlük tablosu."""
        table_label = ctk.CTkLabel(self.frame, text="Son İşlemler", font=("Segoe UI", 12, "bold"))
        table_label.pack(anchor="w", pady=(10, 5))

        tree_frame = ctk.CTkFrame(self.frame)
        tree_frame.pack(fill="both", expand=True)

        columns = ("Tarih/Saat", "Kullanıcı", "İşlem", "Kaynağı", "Durum", "Detay")
        self.tree = ttk.Treeview(tree_frame, columns=columns, height=20)

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)

        self.tree.heading("#0", text="ID")
        self.tree.column("#0", width=30)

        self.tree.pack(fill="both", expand=True)

        # Örnek veriler
        sample_logs = [
            (1, "2026-08-29 14:30:22", "admin", "Sistem Taraması", "Disk", "✓ Başarılı", "200 dosya tarandı"),
            (2, "2026-08-29 14:15:10", "system", "Otomasyom Görevi", "CPU", "✓ Başarılı", "Görev yürütüldü"),
            (3, "2026-08-29 14:00:45", "operator", "Yedekleme", "Sistem", "✓ Başarılı", "5 GB yedeklendi"),
        ]

        for log in sample_logs:
            self.tree.insert("", "end", text=log[0], values=log[1:])

    def _create_action_buttons(self):
        """İşlem butonları."""
        btn_frame = ctk.CTkFrame(self.frame)
        btn_frame.pack(fill="x", pady=(15, 0))

        for label, cmd in [
            ("💾 JSON Dışa Aktar", "export_json"),
            ("📊 CSV Dışa Aktar", "export_csv"),
            ("🗑️ Eski Kayıtları Temizle", "cleanup"),
        ]:
            btn = ctk.CTkButton(
                btn_frame,
                text=label,
                command=lambda c=cmd: self.on_action(c) if self.on_action else None,
                width=150,
            )
            btn.pack(side="left", padx=5)
