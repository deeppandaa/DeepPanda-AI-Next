import base64
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

from PIL import Image

from core.lan_client import LANRemoteClient
from core.lan_remote import LANRemoteServer
from services.app_settings_service import AppSettingsService
from services.remote_auth_service import RemoteAuthService
from services.screen_remote_service import ScreenRemoteService


class LANScreenProtocolTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.original_settings = AppSettingsService.SETTINGS_PATH
        self.original_known_hosts = LANRemoteClient.KNOWN_HOSTS_PATH
        AppSettingsService.SETTINGS_PATH = self.root / "settings.json"
        LANRemoteClient.KNOWN_HOSTS_PATH = self.root / "known_hosts.json"
        RemoteAuthService().update_credentials("admin1", "StrongPassword123", "admin")

    def tearDown(self):
        AppSettingsService.SETTINGS_PATH = self.original_settings
        LANRemoteClient.KNOWN_HOSTS_PATH = self.original_known_hosts
        self.temp_dir.cleanup()

    def test_admin_screen_frame_mouse_and_keyboard_over_tls(self):
        input_controller = Mock()
        image = Image.new("RGB", (800, 600), color=(10, 20, 30))
        server = LANRemoteServer(host="127.0.0.1", port=0)
        server.screen_remote_service = ScreenRemoteService(
            capture_provider=lambda: image.copy(),
            input_controller=input_controller,
        )
        session = server.support_service.create_session_request(
            "LAN-001", "test", "screen", ttl_seconds=900
        )
        server.support_service.approve_session(session["session_id"], session["one_time_code"])
        server.start()
        port = server.server_socket.getsockname()[1]
        try:
            client = LANRemoteClient("127.0.0.1", port, timeout=10)
            login = client.login("admin1", "StrongPassword123")
            client.set_auth_token(login["auth_token"])
            requested = client.request(
                "screen_request",
                {
                    "session_id": session["session_id"],
                    "requester": "phone",
                    "allow_control": True,
                },
            )
            request_id = requested["request"]["request_id"]
            server.screen_remote_service.approve(request_id, allow_control=True)
            started = client.request(
                "screen_start",
                {
                    "request_id": request_id,
                    "session_id": session["session_id"],
                    "quality": "low",
                },
            )
            stream_id = started["stream"]["stream_id"]
            frame = client.request("screen_frame", {"stream_id": stream_id})
            decoded = Image.open(io.BytesIO(base64.b64decode(frame["frame_data"])))
            self.assertEqual("JPEG", decoded.format)

            clicked = client.request(
                "screen_mouse",
                {
                    "stream_id": stream_id,
                    "x_ratio": 0.5,
                    "y_ratio": 0.5,
                    "action": "click",
                    "button": "right",
                },
            )
            self.assertEqual("success", clicked["status"])
            input_controller.click.assert_called_once_with(400, 300, button="right")

            typed = client.request(
                "screen_keyboard",
                {"stream_id": stream_id, "text": "hello", "special_key": "enter"},
            )
            self.assertEqual("success", typed["status"])
            input_controller.write.assert_called_once_with("hello", interval=0.01)
            input_controller.press.assert_called_once_with("enter")
        finally:
            server.stop()


if __name__ == "__main__":
    unittest.main()
