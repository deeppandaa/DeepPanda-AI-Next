import hashlib
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from services.chkmate_service import CHKMateService


class CHKMateServiceTests(unittest.TestCase):
    def test_complete_distribution_is_verified_before_extraction(self):
        executable_data = b"chk-mate"
        license_data = b"freeware-license"
        hashes = {
            "CHK-Mate.exe": hashlib.sha256(executable_data).hexdigest().upper(),
            "license.rtf": hashlib.sha256(license_data).hexdigest().upper(),
        }
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            archive_path = root / "runtime.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("CHK-Mate.exe", executable_data)
                archive.writestr("license.rtf", license_data)
            with (
                patch.dict(os.environ, {**os.environ, "LOCALAPPDATA": str(root)}, clear=True),
                patch.object(CHKMateService, "_archive_path", return_value=archive_path),
                patch.object(CHKMateService, "FILE_HASHES", hashes),
            ):
                executable = CHKMateService.ensure_runtime()

            self.assertEqual(executable, root / "DeepPanda" / "tools" / "CHK-Mate" / "CHK-Mate.exe")
            self.assertEqual((executable.parent / "license.rtf").read_bytes(), license_data)

    def test_incomplete_distribution_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            archive_path = root / "runtime.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("CHK-Mate.exe", b"chk-mate")
            with (
                patch.dict(os.environ, {**os.environ, "LOCALAPPDATA": str(root)}, clear=True),
                patch.object(CHKMateService, "_archive_path", return_value=archive_path),
            ):
                self.assertIsNone(CHKMateService.ensure_runtime())


if __name__ == "__main__":
    unittest.main()