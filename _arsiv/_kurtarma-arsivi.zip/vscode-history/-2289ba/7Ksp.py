from __future__ import annotations

import os
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.plugins.contracts import PluginManifest


class MemoryWriteApprovalRequired(Exception):
    pass


class MemoryPlugin:
    manifest = PluginManifest(
        plugin_id="memory",
        display_name="Local Memory",
        description="Onaylı notları yerel SQLite veritabanında saklar ve arar.",
        actions=("remember", "search", "timeline"),
    )

    def __init__(self, database_path: str | Path | None = None) -> None:
        if database_path is None:
            data_root = Path(os.getenv("AI_DATA_DIR", "data")).expanduser()
            database_path = data_root / "memory.db"
        self.database_path = Path(database_path).expanduser().resolve()

    async def invoke(self, action: str, payload: dict[str, Any]) -> dict[str, Any]:
        if action == "remember":
            return self._remember(payload)
        if action == "search":
            return self._search(payload)
        if action == "timeline":
            return self._timeline(payload)
        raise ValueError(f"Unsupported memory action: {action}")

    def _connect(self) -> sqlite3.Connection:
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                project TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_project_created ON memories(project, created_at DESC)"
        )
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _remember(self, payload: dict[str, Any]) -> dict[str, Any]:
        if payload.get("approved") is not True:
            raise MemoryWriteApprovalRequired("Saving memory requires approved=true.")

        title = self._required_text(payload, "title", 200)
        content = self._required_text(payload, "content", 10_000)
        project = self._optional_text(payload, "project", 200)
        category = self._optional_text(payload, "category", 80) or "general"
        created_at = datetime.now(UTC).isoformat(timespec="seconds")

        with self._connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO memories (created_at, project, category, title, content)
                VALUES (?, ?, ?, ?, ?)
                """,
                (created_at, project, category, title, content),
            )
            memory_id = cursor.lastrowid
        return {"status": "saved", "id": memory_id, "created_at": created_at}

    def _search(self, payload: dict[str, Any]) -> dict[str, Any]:
        query = self._required_text(payload, "query", 500)
        project = self._optional_text(payload, "project", 200)
        limit = self._limit(payload.get("limit"), default=10, maximum=50)
        pattern = f"%{query}%"
        sql = "SELECT id, created_at, project, category, title, content FROM memories WHERE (title LIKE ? OR content LIKE ?)"
        parameters: list[Any] = [pattern, pattern]
        if project:
            sql += " AND project = ?"
            parameters.append(project)
        sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
        parameters.append(limit)
        with self._connection() as connection:
            rows = connection.execute(sql, parameters).fetchall()
        return {"memories": [dict(row) for row in rows]}

    def _timeline(self, payload: dict[str, Any]) -> dict[str, Any]:
        project = self._optional_text(payload, "project", 200)
        limit = self._limit(payload.get("limit"), default=20, maximum=100)
        sql = "SELECT id, created_at, project, category, title, content FROM memories"
        parameters: list[Any] = []
        if project:
            sql += " WHERE project = ?"
            parameters.append(project)
        sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
        parameters.append(limit)
        with self._connection() as connection:
            rows = connection.execute(sql, parameters).fetchall()
        return {"memories": [dict(row) for row in rows]}

    @staticmethod
    def _required_text(payload: dict[str, Any], key: str, max_length: int) -> str:
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > max_length:
            raise ValueError(f"{key} must be a non-empty string up to {max_length} characters.")
        return value.strip()

    @classmethod
    def _optional_text(cls, payload: dict[str, Any], key: str, max_length: int) -> str:
        value = payload.get(key, "")
        if value is None or value == "":
            return ""
        return cls._required_text(payload, key, max_length)

    @staticmethod
    def _limit(value: Any, default: int, maximum: int) -> int:
        if value is None:
            return default
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError("limit must be an integer.")
        return max(1, min(value, maximum))