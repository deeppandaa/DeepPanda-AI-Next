# AI-Next Capability Migration

This ledger tracks the capabilities documented in `DeepPanda/DeepPanda-AI/AGENT_CAPABILITIES.md` and the routes in its `app.py`. AI-Next remains the single AI product; every capability is reached through `PluginGateway`.

## Implemented

- Local Ollama chat, model catalog, and model selection.
- Docker Compose services for Ollama, FastAPI, and the web UI; persistent model and application-data volumes.
- Read-only bounded diagnostics: Python AST/Ruff and JSON/TOML/YAML syntax.
- Local SQLite memory with explicit approval for writes, plus search and timeline.
- Python AST code graph with build, symbol search, and static paths.
- Standard, plan, debug, review, audit, and minimal workflows.
- Loopback-only UI/API ports and read-only workspace mount for analyzers.

## Port Next

1. **Chat sessions:** persistent session CRUD, isolated message history, and bounded context retrieval.
2. **Approved coding tasks:** plan, diff preview, workspace containment, backups, execution allowlist, rollback, and audit history.
3. **Documents and assets:** bounded PDF/DOCX/PPTX/XLSX ingestion, source-linked retrieval, asset preview/download/delete approval.
4. **Media jobs:** local FFmpeg frame/audio extraction, optional Whisper, progress, cancellation, and safe artifacts.
5. **Research:** public web/GitHub source discovery and citations; private/local network targets remain blocked.
6. **Runtime routing:** health-aware Ollama model profiles now; separately evaluate a Windows/WSL KTransformers runtime without importing its source tree.
7. **Offline packaging:** portable Windows distribution, pinned dependencies, model payload choice, integrity checks, and restore path.
8. **Optional integrations:** OCR, image/video generation, VS Code bridge, and publishing remain opt-in and approval-gated.

## Compatibility Policy

- Superpowers/Ponytail concepts are represented by locally authored workflow modes; upstream skill text is not copied.
- Graphify's role is implemented by the local Python AST graph; current support is Python-only.
- Claude-Mem's role is implemented by the local SQLite memory plugin, not its Claude-specific hook/worker stack.
- Caveman-style local output compression is not implemented yet; hosted routing/telemetry are excluded from the offline baseline.
- Keep third-party additions separate, pinned, license-attributed, and replaceable behind the gateway.

## Acceptance Rules

- Run the existing suite after each capability slice; report skipped tests as unverified.
- Every write, install, export, delete, publication, and model pull needs an explicit approval boundary.
- Every analyzer has a workspace boundary, symlink policy, resource budget, and report-only default.
- Offline mode must not silently fall back to a hosted model, search provider, memory sync, or telemetry.