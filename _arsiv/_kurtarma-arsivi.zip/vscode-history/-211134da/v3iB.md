# AI-Next Capability Migration

This ledger tracks the capabilities documented in `DeepPanda/DeepPanda-AI/AGENT_CAPABILITIES.md` and the routes in its `app.py`. AI-Next remains the single AI product; every capability is reached through `PluginGateway`.

## Implemented

- Local Ollama chat, model catalog, and model selection.
- Docker Compose services for Ollama, FastAPI, and the web UI; persistent model and application-data volumes.
- Read-only bounded diagnostics: Python AST/Ruff and JSON/TOML/YAML syntax.
- Local SQLite memory with explicit approval for writes, plus search and timeline.
- Python AST code graph with build, symbol search, and static paths.
- Standard, plan, debug, review, audit, and minimal workflows.
- Persistent chat sessions with per-session message history, bounded model context, and approval-gated deletion.
- Workspace tools for bounded reads, write previews, approved writes with backups, rollback, and allowlisted shell-free commands.
- Coding task plans: persistent local plans, explicit plan approval, per-step approval, validated progress transitions, evidence, and audit history. Tasks do not execute code or write workspace files.
- Documents: explicit-consent ingestion (20 MB upload cap), bounded PDF/DOCX/PPTX/XLSX and text extraction, local chunk search, inventory, and indexed-ID source downloads.
- Loopback-only UI/API ports; analyzers are report-only while workspace writes remain explicitly approved.

## Port Next

1. **Coding task orchestration:** connect approved plan steps to workspace previews/writes/tests and add approval-gated rollback UI. Plans currently require user-entered steps and do not execute code.
2. **Documents and assets:** preview and approval-gated deletion are not implemented; source download is restricted to indexed document IDs.
3. **Media jobs:** local FFmpeg frame/audio extraction, optional Whisper, progress, cancellation, and safe artifacts.
4. **Research:** public web/GitHub source discovery and citations; private/local network targets remain blocked.
5. **Runtime routing:** health-aware Ollama model profiles now; separately evaluate a Windows/WSL KTransformers runtime without importing its source tree.
6. **Offline packaging:** portable Windows distribution, pinned dependencies, model payload choice, integrity checks, and restore path.
7. **Optional integrations:** OCR, image/video generation, VS Code bridge, and publishing remain opt-in and approval-gated.

## Compatibility Policy

- Superpowers/Ponytail concepts are represented by locally authored workflow modes; upstream skill text is not copied.
- Graphify's role is implemented by the local Python AST graph; current support is Python-only.
- Claude-Mem's role is implemented by the local SQLite memory plugin, not its Claude-specific hook/worker stack.
- Caveman-style local output compression is not implemented yet; hosted routing/telemetry are excluded from the offline baseline.
- Keep third-party additions separate, pinned, license-attributed, and replaceable behind the gateway.

## Acceptance Rules

- Run the existing suite after each capability slice; report skipped tests as unverified.
- Every write, install, export, delete, publication, and model pull needs an explicit approval boundary.
- Every analyzer has a workspace boundary, symlink policy, resource budget, and report-only default.
- Offline mode must not silently fall back to a hosted model, search provider, memory sync, or telemetry.