# AI-Next Capability Migration

This ledger tracks the capabilities documented in `DeepPanda/DeepPanda-AI/AGENT_CAPABILITIES.md` and the routes in its `app.py`. AI-Next remains the single AI product; every capability is reached through `PluginGateway`.

## Implemented

- Local Ollama chat, model catalog, and model selection.
- Docker Compose services for Ollama, FastAPI, and the web UI; persistent model and application-data volumes.
- Read-only bounded diagnostics: Python AST/Ruff and JSON/TOML/YAML syntax.
- Local SQLite memory with explicit approval for writes, plus search and timeline.
- Python AST code graph with build, symbol search, and static paths.
- Standard, plan, debug, review, audit, and minimal workflows.
- Persistent chat sessions with per-session message history, bounded model context, and approval-gated deletion.
- Workspace tools for bounded reads, write previews, approved writes with backups, rollback, and allowlisted shell-free commands.
- Coding task plans: editable local-model drafts, persistent local plans, explicit plan approval, per-step approval, validated progress transitions, evidence, audit history, task-linked workspace diff previews, separately approved writes, approval-gated rollback by recorded backup ID, and bounded allowlisted test runs with explicit confirmation and recorded output.
- Documents: explicit-consent ingestion (20 MB upload cap), bounded PDF/DOCX/PPTX/XLSX and text extraction, local chunk search, inventory, indexed-ID source downloads, 50 KB text-only preview, and explicit-confirmation deletion of files plus index entries.
- Loopback-only UI/API ports; analyzers are report-only while workspace writes remain explicitly approved.

## Port Next

1. **Documents and assets:** rich media preview is not implemented; text preview is bounded to 50 KB and source download is restricted to indexed document IDs.
2. **Media jobs:** local FFmpeg frame/audio extraction, optional Whisper, progress, cancellation, and safe artifacts.
3. **Research:** public web/GitHub source discovery and citations; private/local network targets remain blocked.
4. **Runtime routing:** health-aware Ollama model profiles now; separately evaluate a Windows/WSL KTransformers runtime without importing its source tree.
5. **Offline packaging:** portable Windows distribution, pinned dependencies, model payload choice, integrity checks, and restore path.
6. **Optional integrations:** OCR, image/video generation, VS Code bridge, and publishing remain opt-in and approval-gated.

## Compatibility Policy

- Superpowers/Ponytail concepts are represented by locally authored workflow modes; upstream skill text is not copied.
- Graphify's role is implemented by the local Python AST graph; current support is Python-only.
- Claude-Mem's role is implemented by the local SQLite memory plugin, not its Claude-specific hook/worker stack.
- Caveman-style local output compression is not implemented yet; hosted routing/telemetry are excluded from the offline baseline.
- Keep third-party additions separate, pinned, license-attributed, and replaceable behind the gateway.

## Acceptance Rules

- Run the existing suite after each capability slice; report skipped tests as unverified.
- Every write, install, export, delete, publication, and model pull needs an explicit approval boundary.
- Every analyzer has a workspace boundary, symlink policy, resource budget, and report-only default.
- Offline mode must not silently fall back to a hosted model, search provider, memory sync, or telemetry.