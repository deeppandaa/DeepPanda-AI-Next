import tempfile
import unittest
from pathlib import Path

from services.session_checklist_service import SessionChecklistService


class SessionChecklistServiceTests(unittest.TestCase):
    def test_build_checklist_has_required_shape(self):
        checklist = SessionChecklistService.build_checklist()
        self.assertIn("score", checklist)
        self.assertIn("health", checklist)
        self.assertIn("items", checklist)
        self.assertTrue(isinstance(checklist["items"], list))

    def test_export_checklist_report_writes_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            original_export_dir = SessionChecklistService.EXPORT_DIR
            SessionChecklistService.EXPORT_DIR = Path(temp_dir)
            try:
                checklist = {
                    "timestamp": "2026-08-12 12:00:00",
                    "score": 100,
                    "health": "READY",
                    "missing_count": 0,
                    "items": [
                        {"file": "PROJECT_CONTEXT.md", "status": "OK"},
                        {"file": "DECISION_LOG.md", "status": "OK"},
                    ],
                }
                out_path = SessionChecklistService.export_checklist_report(checklist)
                path = Path(out_path)
                self.assertTrue(path.exists())
                content = path.read_text(encoding="utf-8")
                self.assertIn("Session Startup Checklist", content)
                self.assertIn("Checklist Score", content)
                self.assertIn("PROJECT_CONTEXT.md", content)
            finally:
                SessionChecklistService.EXPORT_DIR = original_export_dir


if __name__ == "__main__":
    unittest.main()
