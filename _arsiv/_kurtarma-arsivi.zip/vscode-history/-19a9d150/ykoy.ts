import { createHash, randomBytes } from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import { auditEvent } from "@/lib/audit";

const schema = z.object({
  supportSessionId: z.string().uuid().optional(),
  title: z.string().trim().min(3).max(200),
  summary: z.string().trim().min(10).max(4000),
  riskLevel: z.enum(["low", "medium", "high"]),
  detail: z.record(z.string(), z.unknown()).optional(),
  expiresInMinutes: z.number().int().min(5).max(1440).default(60),
});

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  const result = await tenantQuery(session.organizationId,
    `SELECT id,title,risk_level,status,expires_at,decided_at,created_at
       FROM approval_requests WHERE organization_id=$1
      ORDER BY created_at DESC LIMIT 50`);
  return NextResponse.json({ approvals: result.rows });
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!["owner", "admin", "technician"].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Geçersiz onay isteği." }, { status: 400 });
  const token = randomBytes(32).toString("base64url");
  const tokenHash = createHash("sha256").update(token).digest("hex");
  const result = await tenantQuery<{ id: string }>(session.organizationId,
    `INSERT INTO approval_requests
      (organization_id,support_session_id,token_hash,title,summary,risk_level,detail,expires_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,now()+($8||' minutes')::interval) RETURNING id`,
    [parsed.data.supportSessionId ?? null, tokenHash, parsed.data.title, parsed.data.summary,
      parsed.data.riskLevel, JSON.stringify(parsed.data.detail ?? {}), parsed.data.expiresInMinutes]);
  await auditEvent({ organizationId: session.organizationId, actorUserId: session.userId,
    action: "approval.request.create", targetType: "approval_request", targetId: result.rows[0].id,
    detail: { riskLevel: parsed.data.riskLevel } });
  const baseUrl = process.env.PUBLIC_BASE_URL ?? new URL(request.url).origin;
  return NextResponse.json({ id: result.rows[0].id, url: `${baseUrl}/approve/${token}` }, { status: 201 });
}
