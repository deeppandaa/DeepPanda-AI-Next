$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pyExe = "C:/Users/emre/Desktop/DeepPanda-Proje/DeepPanda-App/tools/validation/python311-x64/python.exe"
$script = Join-Path $scriptDir "program_launcher.py"
$outputDir = Join-Path $scriptDir "dist"

New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

& $pyExe -m PyInstaller --noconsole --onefile --name ProgramLauncher --distpath $outputDir --workpath (Join-Path $scriptDir "build") --specpath $scriptDir $script

Write-Host "OK" -ForegroundColor Green
Write-Host "EXE path: $outputDir\ProgramLauncher.exe" -ForegroundColor Cyan
