"""
SystemCore v2 - Log Görünümü Paneli
Sistem loglarını, seviye filtrelemesini ve canlı olay geçmişini sunar.
"""

import customtkinter as ctk
from pathlib import Path
from services.log_service import LogService


class LogView(ctk.CTkFrame):
    """Sistem olay ve uyarı loglarını gösteren ekran."""

    CARD_BG = "#16213E"
    TEXT_PRIMARY = "#FFFFFF"
    TEXT_SECONDARY = "#A0AEC0"

    LEVEL_COLORS = {
        "INFO": "#1E90FF",
        "WARNING": "#F5A623",
        "ERROR": "#E63946",
        "CRITICAL": "#D62828",
    }

    def __init__(self, parent: ctk.CTkFrame):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_rowconfigure(2, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self._auto_refresh_ms = 1500
        self._last_log_count = -1

        self._build_header()
        self._build_table()
        self._schedule_auto_refresh()

    def _build_header(self):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=20, pady=(15, 10), sticky="ew")

        title = ctk.CTkLabel(
            header,
            text="📋 Sistem Logları",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=self.TEXT_PRIMARY,
        )
        title.pack(side="left")

        # Temizle Butonu
        clear_btn = ctk.CTkButton(
            header,
            text="🗑️ Logları Temizle",
            fg_color="#3A3D52",
            hover_color="#2D3042",
            width=120,
            command=self._clear_logs,
        )
        clear_btn.pack(side="right", padx=(5, 0))

        # Filtreleme Açılır Menüsü
        self.filter_option = ctk.CTkOptionMenu(
            header,
            values=["HEPSİ", "INFO", "WARNING", "ERROR"],
            command=lambda _: self.refresh_logs(),
            width=110,
        )
        self.filter_option.pack(side="right", padx=5)

        self.category_option = ctk.CTkOptionMenu(
            header,
            values=LogService.get_categories(),
            command=lambda _: self.refresh_logs(),
            width=130,
        )
        self.category_option.pack(side="right", padx=5)
        self.category_option.set("HEPSİ")

        self.search_entry = ctk.CTkEntry(
            header,
            placeholder_text="Mesaj/Kategori ara...",
            width=180,
        )
        self.search_entry.pack(side="right", padx=5)
        self.search_entry.bind("<Return>", lambda _: self.refresh_logs())

        export_json_btn = ctk.CTkButton(
            header,
            text="JSON Dışa Aktar",
            fg_color="#3A3D52",
            hover_color="#2D3042",
            width=120,
            command=self._export_json,
        )
        export_json_btn.pack(side="right", padx=(5, 0))

        export_csv_btn = ctk.CTkButton(
            header,
            text="CSV Dışa Aktar",
            fg_color="#3A3D52",
            hover_color="#2D3042",
            width=115,
            command=self._export_csv,
        )
        export_csv_btn.pack(side="right", padx=(5, 0))

        lbl_filter = ctk.CTkLabel(
            header,
            text="Filtrele:",
            font=ctk.CTkFont(size=13),
            text_color=self.TEXT_SECONDARY,
        )
        lbl_filter.pack(side="right", padx=(0, 5))

        self.result_label = ctk.CTkLabel(
            self,
            text="",
            text_color="#8FD19E",
            font=ctk.CTkFont(size=12),
        )
        self.result_label.grid(row=3, column=0, sticky="w", padx=20, pady=(0, 8))

    def _build_table(self):
        # Kolon Başlıkları
        cols = ctk.CTkFrame(self, fg_color=self.CARD_BG, height=35)
        cols.grid(row=1, column=0, padx=20, pady=(5, 0), sticky="ew")
        cols.grid_columnconfigure(0, weight=1)
        cols.grid_columnconfigure(1, weight=1)
        cols.grid_columnconfigure(2, weight=1)
        cols.grid_columnconfigure(3, weight=4)

        headers = ["Zaman", "Seviye", "Kategori", "Mesaj"]
        for idx, h_text in enumerate(headers):
            lbl = ctk.CTkLabel(
                cols,
                text=h_text,
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color=self.TEXT_SECONDARY,
            )
            lbl.grid(row=0, column=idx, padx=10, pady=5, sticky="w")

        # Kaydırılabilir İçerik Alanı
        self.scroll_frame = ctk.CTkScrollableFrame(self, fg_color=self.CARD_BG)
        self.scroll_frame.grid(row=2, column=0, padx=20, pady=(5, 20), sticky="nsew")
        self.scroll_frame.grid_columnconfigure(0, weight=1)
        self.scroll_frame.grid_columnconfigure(1, weight=1)
        self.scroll_frame.grid_columnconfigure(2, weight=1)
        self.scroll_frame.grid_columnconfigure(3, weight=4)

        self.refresh_logs()

    def refresh_logs(self):
        for widget in self.scroll_frame.winfo_children():
            widget.destroy()

        selected_filter = self.filter_option.get()
        selected_category = self.category_option.get()
        search_text = self.search_entry.get().strip()
        logs = LogService.query_logs(
            level_filter=selected_filter,
            category_filter=selected_category,
            search_text=search_text,
        )

        for row_idx, log in enumerate(logs):
            # Zaman
            time_lbl = ctk.CTkLabel(
                self.scroll_frame,
                text=log["timestamp"],
                text_color=self.TEXT_SECONDARY,
            )
            time_lbl.grid(row=row_idx, column=0, padx=10, pady=4, sticky="w")

            # Seviye (Renklendirilmiş)
            lvl_color = self.LEVEL_COLORS.get(log["level"], self.TEXT_PRIMARY)
            lvl_lbl = ctk.CTkLabel(
                self.scroll_frame,
                text=f"[{log['level']}]",
                text_color=lvl_color,
                font=ctk.CTkFont(weight="bold"),
            )
            lvl_lbl.grid(row=row_idx, column=1, padx=10, pady=4, sticky="w")

            # Kategori
            cat_lbl = ctk.CTkLabel(
                self.scroll_frame,
                text=log["category"],
                text_color=self.TEXT_PRIMARY,
            )
            cat_lbl.grid(row=row_idx, column=2, padx=10, pady=4, sticky="w")

            # Mesaj
            msg_lbl = ctk.CTkLabel(
                self.scroll_frame,
                text=log["message"],
                text_color=self.TEXT_PRIMARY,
                anchor="w",
            )
            msg_lbl.grid(row=row_idx, column=3, padx=10, pady=4, sticky="w")

        self.result_label.configure(text=f"Toplam {len(logs)} log gösteriliyor.")

    def _export_json(self):
        logs = LogService.query_logs(
            level_filter=self.filter_option.get(),
            category_filter=self.category_option.get(),
            search_text=self.search_entry.get().strip(),
        )
        path = Path("exports") / "system_logs.json"
        out = LogService.export_logs_json(str(path), logs=logs)
        self.result_label.configure(text=f"JSON kaydedildi: {out}")

    def _export_csv(self):
        logs = LogService.query_logs(
            level_filter=self.filter_option.get(),
            category_filter=self.category_option.get(),
            search_text=self.search_entry.get().strip(),
        )
        path = Path("exports") / "system_logs.csv"
        out = LogService.export_logs_csv(str(path), logs=logs)
        self.result_label.configure(text=f"CSV kaydedildi: {out}")

    def _clear_logs(self):
        LogService.clear_logs()
        self.category_option.configure(values=LogService.get_categories())
        self.category_option.set("HEPSİ")
        self.refresh_logs()

    def _schedule_auto_refresh(self):
        try:
            total = len(LogService.get_logs())
            if total != self._last_log_count:
                self._last_log_count = total
                self.category_option.configure(values=LogService.get_categories())
                self.refresh_logs()
        except Exception:
            pass
        self.after(self._auto_refresh_ms, self._schedule_auto_refresh)