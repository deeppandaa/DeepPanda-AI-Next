# DeepPanda Lab Otonom Sandbox

Bu mod, modelin urettiği PowerShell adimlarini onay sormadan otomatik calistirir. Islemler ana Windows yerine gecici Windows Sandbox icinde gerceklesir.

## Geri alma siniri

- Sandbox kapatildiginda `C:\LabWorkspace` ve Sandbox icindeki sistem degisiklikleri silinir.
- Ana bilgisayardaki DeepPanda kaynaklari, Ollama, model deposu ve Python klasorleri salt okunur baglanir.
- Ag, pano, yazici, mikrofon ve kamera erisimi kapatilir.
- Model en fazla sekiz otomatik adim uygular.
- Sanal makine/hipervizor aciklarina karsi mutlak garanti yoktur; normal hata ve yanlis komutlara karsi guclu bir geri alma siniri saglar.

## Gereksinim

Windows Sandbox ozelligi yonetici olarak etkinlestirilmelidir:

```powershell
Enable-WindowsOptionalFeature -Online -FeatureName Containers-DisposableClientVM -All
```

Komut yeniden baslatma isteyebilir. Ozellik etkinlestikten sonra `DeepPanda-Lab-Otonom-Sandbox.wsb` dosyasini acin.

## Kullanim

1. Sandbox penceresinin ve DeepPanda Lab terminalinin acilmasini bekleyin.
2. Gorevi yazin. Model komutlari Sandbox icinde otomatik uygular.
3. Sonucu alin.
4. Tum degisiklikleri geri almak icin Sandbox penceresini kapatin.

Bu mod bilerek internetsizdir. Yeni bilgi once ana Windows'taki `DeepPanda Lab Bilgi Guncelle` kisayoluyla yerel depoya alinmalidir.
