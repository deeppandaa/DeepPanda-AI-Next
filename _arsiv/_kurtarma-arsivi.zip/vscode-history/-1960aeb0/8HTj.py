import subprocess
import unittest
from unittest.mock import Mock, patch

from services.it_operations_service import ITOperationsService


class TailscaleIntegrationTests(unittest.TestCase):
    def test_login_url_is_opened_from_cli_output(self):
        completed = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout="To authenticate, visit:\nhttps://login.tailscale.com/a/example-key\n",
            stderr="",
        )
        with patch.object(ITOperationsService, "_tailscale_cli", return_value="tailscale.exe"), patch.object(
            ITOperationsService,
            "wan_readiness",
            return_value={"status": "warning", "ready": False},
        ), patch("services.it_operations_service.subprocess.run", return_value=completed), patch(
            "services.it_operations_service.webbrowser.open"
        ) as browser_open:
            result = ITOperationsService.start_tailscale_login()
        self.assertEqual("success", result["status"])
        browser_open.assert_called_once_with("https://login.tailscale.com/a/example-key")

    def test_bundled_service_configures_tailnet_tcp_serve(self):
        completed = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
        with patch.object(ITOperationsService, "_service_exists", return_value=True), patch(
            "services.it_operations_service.subprocess.run", return_value=completed
        ) as run:
            message = ITOperationsService._configure_bundled_tailscale_serve("tailscale.exe")
        self.assertIn("TCP 5000", message)
        command = run.call_args.args[0]
        self.assertEqual("serve", command[1])
        self.assertIn("--tcp", command)
        self.assertIn("tcp://127.0.0.1:5000", command)


if __name__ == "__main__":
    unittest.main()
