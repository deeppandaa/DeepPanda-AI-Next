# ARC Solver Roadmap

## Current baseline

- Deterministic geometric rules
- Color-map rules
- Background/object cropping
- Uniform block compression
- Connected-component largest/smallest extraction
- Optional local Ollama advisor
- Current measured coverage: 14/1000 training tasks

## Planned rule families

1. Color transformations
   - dominant/rare color selection
   - color replacement learned from training pairs
   - color-conditioned object selection
   - foreground/background inversion

2. Object geometry
   - connected components with 4/8-connectivity
   - object sorting by size, color, position
   - largest/smallest/unique object extraction
   - object centering and alignment

3. Movement and projection
   - move objects to center, border, or target color
   - connect points with horizontal, vertical, and diagonal lines
   - mirror objects around horizontal/vertical axes
   - extend rays and fill enclosed regions

4. Scaling and repetition
   - 2x/3x nearest-neighbor enlargement
   - tile repetition and periodic patterns
   - reduce repeated blocks to symbolic grids
   - expand symbolic grids into colored blocks

5. Grid and topology
   - crop to active region
   - split by separator rows/columns
   - merge or reorder panels
   - detect symmetry and complete missing cells

6. Counting and arithmetic
   - count objects or colored cells
   - map counts to output size, color, or repetition
   - compare object dimensions and differences

7. Model-assisted discovery
   - ask local Qwen3.5 for hypotheses
   - validate every hypothesis against all training pairs
   - never let unvalidated model output enter submission

## Delivery order

1. Color transformations
2. Object sorting and centering
3. Scaling and repetition
4. Lines, mirrors, and projections
5. Panel splitting and merging
6. Counting rules
7. Qwen-assisted candidate generation
8. Benchmark and submission review
