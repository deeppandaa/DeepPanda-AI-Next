# 🐼 DeepPanda - Master Proje Rehberi

**Tarih:** 2026-08-29  
**Versiyon:** 3.0  
**Dil:** Türkçe

---

## 📦 Proje Yapısı

```
DeepPanda-Proje/
│
├── DeepPanda-App/              # ANA UYGULAMA (Python 3.11.9)
│   ├── main.py                 # Entry point
│   ├── main_window.py          # GUI ana penceresi
│   ├── engine.py               # İşletim motoru
│   ├── config.py               # Yapılandırma
│   ├── version.py              # Versiyon bilgisi
│   │
│   ├── services/               # İŞ MANTIK SERVİSLERİ (25+)
│   │   ├── dashboard_analytics_service.py      (Analitik)
│   │   ├── automation_engine_service.py        (Otomasyon)
│   │   ├── rest_api_service.py                 (HTTP API + CLI)
│   │   ├── audit_log_service.py                (Denetim)
│   │   ├── plugin_manager_service.py           (Eklentiler)
│   │   ├── multi_user_service.py               (Kullanıcılar)
│   │   ├── backup_service.py                   (Yedekleme)
│   │   ├── integration_service.py              (Entegrasyonlar)
│   │   ├── carm_service.py                     (C-ARM)
│   │   ├── remote_auth_service.py              (Auth)
│   │   ├── remote_support_service.py           (Destek)
│   │   ├── transmission_service.py             (Dosya)
│   │   ├── repair_capsule_service.py           (Onarım)
│   │   ├── license_service.py                  (Lisans)
│   │   ├── app_settings_service.py             (Ayarlar)
│   │   ├── update_service.py                   (Güncelleme)
│   │   ├── system_status_service.py            (Sistem izleme)
│   │   ├── ai_routing_service.py               (AI routing)
│   │   ├── communication_session_service.py    (İletişim)
│   │   ├── i18n_service.py                     (Çoklu dil)
│   │   └── [15+ ek servis]
│   │
│   ├── gui/                    # ARAYÜZ KATMANI (22 View)
│   │   ├── dashboard.py                        (Ana kontrol paneli)
│   │   ├── advanced_system_view.py             (Gelişmiş sistem)
│   │   ├── analytics_view.py                   (Analitikler)
│   │   ├── automation_view.py                  (Otomasyon)
│   │   ├── audit_view.py                       (Denetim)
│   │   ├── backup_view.py                      (Yedekleme)
│   │   ├── carm_service_view.py                (C-ARM)
│   │   ├── driver_view.py                      (Sürücü)
│   │   ├── guided_support_view.py              (Destek)
│   │   ├── integration_view.py                 (Entegrasyon)
│   │   ├── it_operations_view.py               (BT Operasyonları)
│   │   ├── log_view.py                         (Günlükleri)
│   │   ├── multi_user_view.py                  (Kullanıcılar)
│   │   ├── programs_view.py                    (Programlar)
│   │   ├── remote_support_view.py              (Uzak Destek)
│   │   ├── repair_capsule_view.py              (Onarım)
│   │   ├── security_view.py                    (Güvenlik)
│   │   ├── serial_view.py                      (Seri)
│   │   ├── simplewall_view.py                  (Duvar)
│   │   ├── sound_view.py                       (Ses)
│   │   ├── tools_hub_view.py                   (Araçlar)
│   │   ├── transmission_view.py                (Dosya aktarımı)
│   │   └── ai_assistant_view.py                (AI Asistanı)
│   │
│   ├── core/                   # TEMEL KÜTÜPHANELERİ
│   │   ├── lan_client.py       (LAN istemcisi)
│   │   ├── lan_remote.py       (LAN sunucusu)
│   │   └── [protokoller]
│   │
│   ├── models/                 # VERİ MODELLERİ
│   │   ├── app_state.py        (Uygulama durumu)
│   │   ├── system_info.py      (Sistem bilgisi)
│   │   └── medical_telemetry.py (Medikal veriler)
│   │
│   ├── tests/                  # BİRİM VE ENTEGRASYON TESTLERİ (50+)
│   │   ├── test_*.py
│   │   └── pytest.ini
│   │
│   ├── schemas/                # API ŞEMALARI
│   │   ├── openapi.json
│   │   └── [diğer şemalar]
│   │
│   ├── tools/                  # YARDIMCI ARAÇLAR
│   │   ├── license_key_generator.py
│   │   ├── license_manager_gui.py
│   │   ├── update_manifest_generator.py
│   │   ├── update_publisher_gui.py
│   │   └── validation/         (Python 3.11.9)
│   │
│   ├── installer/              # INSTALLER YAPISI
│   │   └── [NSIS dosyaları]
│   │
│   ├── plugins/                # EKLENTI DİZİNİ
│   │   └── [üçüncü taraf eklentiler]
│   │
│   ├── legacy_agent/           # KALITSAL AGENT
│   │   └── app.py
│   │
│   ├── assets/                 # UI KAYNAKLARI
│   │   ├── images/
│   │   ├── icons/
│   │   └── themes/
│   │
│   ├── requirements.txt        # PYTHON DEĞERLENDİRMELERİ
│   ├── app_settings.json       # UYGULAMA AYARLARI
│   ├── PROJECT_MANIFEST.json   # PROJE MANIFESTU (MASTER)
│   ├── systemcore.db           # SQLite VERİTABANI
│   ├── config.json             # YAPILANDIRMA
│   ├── DeepPanda.spec          # PyInstaller spec
│   ├── DeepPanda.iss           # NSIS installer spec
│   └── [belgeler ve MD dosyaları]
│
├── DeepPanda-Data/             # VERİ DEPOSU
│   ├── app_settings.json
│   ├── carm_flc_profiles.json
│   ├── tls_known_hosts.json
│   ├── large_transfers.json
│   ├── policy_state.json
│   ├── repair_capsules.json
│   ├── trial_state.json
│   ├── dicom_inbox/
│   ├── pending_cleanup/
│   ├── tls/
│   └── [veri klasörleri]
│
├── DeepPanda-Lab/              # LAB VE DEV ORTAMI
│   ├── lab_assistant.py
│   ├── nim_toolkit.py
│   ├── sandbox_agent.py
│   ├── qwen_coder_ornegi.py
│   ├── Modelfile
│   ├── README.md
│   └── [test ve model dosyaları]
│
├── DeepPanda-License-Admin/    # LİSANS YÖNETİMİ
│   └── [lisans dosyaları]
│
├── DeepPanda-Panel/            # PANEL ARAYÜZÜ
│   ├── node/
│   ├── database/
│   └── [web interface]
│
├── ProgramLauncher/            # PROGRAM BAŞLATICI
│   ├── program_launcher.py     (318 program kataloğu)
│   ├── ollama_hybrid.py        (Model seçimi)
│   └── Programs/               (318 program)
│
├── GitHub-Public/              # GITHUB KÜTÜPHANELERİ
│   └── llama-cpp-windows-ollama-bridge/
│
├── vm-tests/                   # VM TEST ORTAMI
│
└── [konfigürasyon dosyaları]
   ├── PROJECT_MANIFEST.json    (✨ MASTER PROJE DÖK.)
   ├── FEATURES_UPDATE_2026_08_29.md
   ├── ARCHITECTURE_2026_08_29.md
   ├── PROJECT_CONTEXT.md
   ├── KULLANIM_KILAVUZU.md
   └── [diğer belgeler]

```

---

## 🗄️ Veritabanı Şeması

**Dosya:** `systemcore.db` (SQLite3)

### Temel Tablolar

| Tablo | Amaç | Kayıt |
|-------|------|-------|
| `analytics_metrics` | Sistem metrikleri (CPU, RAM, Disk) | 90 gün |
| `analytics_reports` | Üretilen raporlar | Sınırsız |
| `automation_tasks` | Zamanlı görevler | Sınırsız |
| `automation_history` | Görev yürütme geçmişi | Sınırsız |
| `audit_logs` | Tüm sistem işlemleri | 365 gün |
| `users` | Kullanıcı hesapları | Sınırsız |
| `user_permissions` | Kullanıcı izinleri | Sınırsız |
| `backups` | Yedek dosyaları | 30 gün |
| `carm_profiles` | C-ARM profilleri | Sınırsız |
| `large_transfers` | Dosya aktarımları | Sınırsız |

**Şema Oluşturma:** Servisler otomatik olarak tablo oluştururlar, manuel işlem gerekmez.

---

## ⚙️ Yapılandırma

**Dosya:** `app_settings.json`

### Ana Bölümler

```json
{
  "core": {
    "refresh_interval": 1.5,
    "notifications_enabled": true,
    "autostart_enabled": true,
    "ui_language": "tr"
  },
  "analytics": {
    "enabled": true,
    "retention_days": 90
  },
  "automation": {
    "enabled": true,
    "max_concurrent_tasks": 3
  },
  "api": {
    "enabled": true,
    "host": "127.0.0.1",
    "port": 8765
  },
  "audit": {
    "enabled": true,
    "log_retention_days": 365
  },
  "backup": {
    "enabled": true,
    "backup_retention_days": 30
  },
  "multi_user": {
    "enabled": false,
    "session_timeout_minutes": 30
  },
  "integrations": {
    "defender": true,
    "onedrive": false,
    "teams": false,
    "siem": false
  },
  "plugins": {
    "enabled": true,
    "auto_load": true
  }
}
```

---

## 🚀 Başlarken

### 1. Kurulum

```bash
cd DeepPanda-Proje
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r DeepPanda-App/requirements.txt
```

### 2. Çalıştırma

```bash
cd DeepPanda-App
python main.py
```

### 3. REST API

```bash
# API sunucusu otomatik başlar
curl http://127.0.0.1:8765/api/health
curl http://127.0.0.1:8765/api/metrics
```

### 4. CLI

```bash
python -m services.rest_api_service
deeppanda status
deeppanda metrics
deeppanda task list
```

---

## 🔑 Anahtar Özellikler

| Özellik | Durum | Açıklama |
|---------|-------|----------|
| **Sistem İzleme** | ✅ | Real-time CPU, RAM, Disk, Network |
| **Analitikler** | ✅ | Trend analizi, raporlama, PDF export |
| **Otomasyon** | ✅ | Zamanlı görevler, özel kurallar |
| **REST API** | ✅ | HTTP endpoint'leri, harici entegrasyon |
| **Denetim Günlüğü** | ✅ | Tüm işlemleri kaydet, 365 gün tutma |
| **Kullanıcı Yönetimi** | ✅ | RBAC, PBKDF2 şifreleme |
| **Yedekleme** | ✅ | Full/Quick backup, auto-restore |
| **Entegrasyon** | ✅ | Defender, OneDrive, Teams, SIEM |
| **Eklenti Sistemi** | ✅ | Plugin discovery, hook system |
| **Uzak Destek** | ✅ | Screen share, session management |
| **Lisans Yönetimi** | ✅ | Trial, Professional, Enterprise |
| **Çok Dil** | ✅ | Türkçe (tam), İngilizce (kısmi) |

---

## 📊 İstatistikler

| Metrik | Değer |
|--------|-------|
| **Python Dosyaları** | 150+ |
| **Toplam Servis** | 25+ |
| **GUI View'ları** | 22 |
| **Veritabanı Tabloları** | 10+ |
| **Kod Satırı** | 50.000+ |
| **Test Case'ler** | 50+ |
| **Bağımlılıklar** | 30+ |

---

## 🔒 Güvenlik

### Kimlik Doğrulama
- **PBKDF2-HMAC-SHA256** (100.000 iterasyon)
- Geriye dönük uyumluluk: SHA256 legacy algoritması

### Şifre Politikası
- Minimum 8 karakter
- Uppercase + Lowercase + Digit
- Hash + Salt ile saklanır

### Denetim
- Her işlem kaydedilir (user_id, action, resource, timestamp)
- 365 gün tutulur
- JSON/CSV dışa aktarma

### Token
- 12 saatlik TTL
- Oturum zaman aşımı: 30 dakika
- Reconnect token desteklenir

---

## 📦 Bağımlılıklar

Anahtarlar:
- **customtkinter** - Modern GUI
- **pyinstaller** - Exe paketleme
- **requests** - HTTP
- **cryptography** - Şifreleme
- **pillow** - Görüntü işleme
- **opencv-python** - Görüntü analizi
- **psutil** - Sistem monitoring
- **numpy, scipy, scikit-learn** - ML

Tam liste: [requirements.txt](DeepPanda-App/requirements.txt)

---

## 🧪 Test Etme

```bash
# Tüm testler
pytest

# Belirli servis
pytest tests/test_multi_user_service.py -v

# Coverage raporu
pytest --cov=services tests/
```

---

## 📝 Belgeler

| Dokument | İçerik |
|----------|--------|
| [PROJECT_MANIFEST.json](DeepPanda-App/PROJECT_MANIFEST.json) | Master proje verileri (JSON) |
| [FEATURES_UPDATE_2026_08_29.md](DeepPanda-App/FEATURES_UPDATE_2026_08_29.md) | Yeni özellikler rehberi |
| [ARCHITECTURE_2026_08_29.md](DeepPanda-App/ARCHITECTURE_2026_08_29.md) | Mimari şema ve tasarım |
| [PROJECT_CONTEXT.md](DeepPanda-App/PROJECT_CONTEXT.md) | Proje arka planı |
| [KULLANIM_KILAVUZU.md](DeepPanda-App/KULLANIM_KILAVUZU.md) | Kullanıcı talimatları |
| [SECURITY_AND_TECHDEBT_ACTION_PLAN.md](DeepPanda-App/SECURITY_AND_TECHDEBT_ACTION_PLAN.md) | Güvenlik ve teknik borç |

---

## 🎯 Sonraki Adımlar

1. **GUI Entegrasyonu** - Tüm view'ları main_window'a bağla
2. **Servis İnitiyalizasyonu** - Startup'ta veritabanları oluştur
3. **REST API** - Üretimde kimlik doğrulamayı etkinleştir
4. **Grafik Kütüphanesi** - matplotlib/plotly entegre et
5. **Performans Optimizasyonu** - Profil ve optimizasyon
6. **Dokümantasyon** - API ve kullanıcı docu tamamla

---

## 📞 İletişim

**Proje:** DeepPanda v3.0  
**Dil:** Türkçe  
**Tarih:** 2026-08-29  

Tüm bilgiler [PROJECT_MANIFEST.json](DeepPanda-App/PROJECT_MANIFEST.json) 'de merkezileştirilmiştir.

---

**✨ Proje hazır! Tüm bileşenler derli toplu haldedir. ✨**
