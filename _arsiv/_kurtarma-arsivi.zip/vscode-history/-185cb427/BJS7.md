# Vana Yardimci

`vana-yardimci`, yerel `qwen2.5:latest` modelinin Turkce teknik destek icin hazirlanmis Ollama uyarlamasidir.

## Kurulum

1. Ollama'nin kurulu oldugundan emin olun.
2. `Modeli-Kur.cmd` dosyasini calistirin. Temel `qwen2.5:latest` modeli yoksa otomatik indirilir.
3. Terminalde `ollama run vana-yardimci` komutunu kullanin.

## API kullanimi

Ollama varsayilan olarak su yerel adreste calisir:

```text
http://127.0.0.1:11434/api/chat
```

OpenAI uyumlu adres:

```text
http://127.0.0.1:11434/v1/chat/completions
```

Model adi:

```text
vana-yardimci
```

## Nasil ozellestirildi?

- Turkce oncelikli sistem talimati
- Dusuk sicaklikla daha tutarli teknik yanitlar
- Windows ve PowerShell odakli guvenli teshis akisi
- API anahtari ve geri alinmasi zor islemler icin guvenlik kurallari
- Ornek teknik destek diyaloglari

Bu paket sifirdan egitilmis yeni agirliklar veya LoRA adapteri icermez. Ollama Modelfile ile hizli davranis uyarlamasi yapar. `Egitim-Ornekleri.jsonl`, ileride gercek LoRA/SFT egitimi icin baslangic veri setidir.
