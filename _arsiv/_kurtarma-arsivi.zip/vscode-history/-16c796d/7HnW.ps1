param(
  [Parameter(Mandatory = $true)][string]$BackupZip,
  [string]$AppPath = "D:\Program Files\DeepPanda"
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $BackupZip -PathType Leaf)) { throw "Backup not found: $BackupZip" }
$panel = Join-Path $AppPath "DeepPanda-Panel"
$dbDir = Join-Path $panel "database"
$pgCtl = Join-Path $panel "runtime\node_modules\@embedded-postgres\windows-x64\native\bin\pg_ctl.exe"
if (Test-Path $pgCtl) { & $pgCtl stop -D $dbDir -m fast -w 2>$null | Out-Null }
$staging = Join-Path $env:TEMP "DeepPanda-restore-$([guid]::NewGuid().ToString('N'))"
New-Item $staging -ItemType Directory -Force | Out-Null
try {
  Expand-Archive -Path $BackupZip -DestinationPath $staging -Force
  Remove-Item $dbDir -Recurse -Force -ErrorAction SilentlyContinue
  Move-Item (Join-Path $staging "database") $dbDir
  Write-Output "Backup restored. Start DeepPanda Panel to use the restored database."
} finally { Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue }
