"""Support recovery service for approved technical sessions."""

from __future__ import annotations

import importlib.util
import subprocess
from typing import Dict, List, Sequence, Tuple


class SupportRecoveryService:
    """Runs missing package checks and driver/system scans for support workflows."""

    DEFAULT_MODULES: Sequence[Tuple[str, str]] = (
        ("customtkinter", "customtkinter"),
        ("matplotlib", "matplotlib"),
        ("psutil", "psutil"),
        ("httpx", "httpx"),
        ("openai", "openai"),
    )

    def scan_missing_modules(
        self,
        modules: Sequence[Tuple[str, str]] | None = None,
    ) -> List[Dict[str, str]]:
        module_pairs = modules or self.DEFAULT_MODULES
        missing: List[Dict[str, str]] = []
        for module_name, package_name in module_pairs:
            if importlib.util.find_spec(module_name) is None:
                missing.append({"module": module_name, "package": package_name})
        return missing

    def repair_missing_modules(
        self,
        python_executable: str,
        missing: Sequence[Dict[str, str]],
        dry_run: bool = False,
    ) -> Dict[str, object]:
        installed = 0
        failed = 0
        details: List[str] = []

        for item in missing:
            package = item.get("package", "")
            module = item.get("module", "")
            if not package:
                failed += 1
                details.append(f"Paket bilgisi eksik: {module}")
                continue

            if dry_run:
                installed += 1
                details.append(f"DRY-RUN install: {package} (module: {module})")
                continue

            try:
                proc = subprocess.run(
                    [python_executable, "-m", "pip", "install", package],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=180,
                )
                if proc.returncode == 0:
                    installed += 1
                    details.append(f"Kuruldu: {package}")
                else:
                    failed += 1
                    err = (proc.stderr or proc.stdout or "Bilinmeyen hata").strip()
                    details.append(f"Kurulum hatası ({package}): {err[:240]}")
            except Exception as exc:
                failed += 1
                details.append(f"Kurulum istisnası ({package}): {exc}")

        return {
            "installed": installed,
            "failed": failed,
            "details": details,
        }

    def scan_driver_health(self, dry_run: bool = False) -> Dict[str, object]:
        if dry_run:
            return {
                "ok": True,
                "issues": 0,
                "summary": "DRY-RUN: Driver sağlık taraması planlandı.",
                "raw": "",
            }

        command = (
            "$problems = @(); "
            "if (Get-Command Get-PnpDevice -ErrorAction SilentlyContinue) { "
            "$problems = Get-PnpDevice -PresentOnly | Where-Object { $_.Status -ne 'OK' } "
            "| Select-Object Class,FriendlyName,Status,Problem; }; "
            "$drivers = Get-CimInstance Win32_PnPSignedDriver | "
            "Select-Object -First 40 DeviceName,DriverVersion,Manufacturer; "
            "Write-Output '===DRIVER_PROBLEMS==='; $problems | Format-Table -AutoSize; "
            "Write-Output '===DRIVER_SAMPLE==='; $drivers | Format-Table -AutoSize"
        )
        try:
            proc = subprocess.run(
                ["powershell", "-Command", command],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            output = (proc.stdout or "").strip()
            issues = 0
            if "===DRIVER_PROBLEMS===" in output:
                chunk = output.split("===DRIVER_PROBLEMS===", 1)[1]
                chunk = chunk.split("===DRIVER_SAMPLE===", 1)[0]
                lines = [ln for ln in chunk.splitlines() if ln.strip() and "---" not in ln]
                issues = max(0, len(lines) - 1) if lines else 0

            if proc.returncode != 0:
                return {
                    "ok": False,
                    "issues": issues,
                    "summary": "Driver taraması hata verdi.",
                    "raw": ((proc.stderr or proc.stdout or "").strip())[:1200],
                }

            return {
                "ok": True,
                "issues": issues,
                "summary": f"Driver taraması tamamlandı. Potansiyel sorun: {issues}",
                "raw": output[:1200],
            }
        except Exception as exc:
            return {
                "ok": False,
                "issues": 0,
                "summary": f"Driver taraması istisnası: {exc}",
                "raw": "",
            }

    def run_recovery_cycle(
        self,
        python_executable: str,
        dry_run: bool = False,
    ) -> Dict[str, object]:
        missing = self.scan_missing_modules()
        repair = self.repair_missing_modules(python_executable, missing, dry_run=dry_run)
        drivers = self.scan_driver_health(dry_run=dry_run)

        return {
            "missing_modules": missing,
            "repair": repair,
            "drivers": drivers,
        }
