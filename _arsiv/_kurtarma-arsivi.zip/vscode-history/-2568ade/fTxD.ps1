param(
    [string]$PanelPath = "",
    [string]$FolderPath = ""
)

$ErrorActionPreference = "Stop"
$panelUrl = "http://localhost:3101/login"

if (-not $PanelPath) {
    if ($FolderPath -and (Test-Path (Join-Path $FolderPath "DeepPanda-Panel"))) {
        $PanelPath = Join-Path $FolderPath "DeepPanda-Panel"
    } elseif ($FolderPath -and (Test-Path (Join-Path $FolderPath "runtime\start-db.mjs"))) {
        $PanelPath = $FolderPath
    } else {
        $PanelPath = $PSScriptRoot
    }
}

if (-not $FolderPath) {
    $FolderPath = Split-Path $PanelPath -Parent
}

$databaseRuntime = Join-Path $PanelPath "runtime\start-db.mjs"
$webRuntime = Join-Path $PanelPath "web\server.js"
$node = Join-Path $PanelPath "node\node.exe"
$databaseDir = Join-Path $PanelPath "database"

if (-not (Test-Path $databaseRuntime) -or -not (Test-Path $webRuntime) -or -not (Test-Path $node)) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("DeepPanda-Panel bilesenleri bulunamadi: $PanelPath", "DeepPanda") | Out-Null
    exit 1
}

$env:PATH = "$(Split-Path $node);$env:PATH"
$env:DATABASE_URL = "postgresql://vana:vana-local-db-2026@127.0.0.1:5432/vana_control"
$env:AUTH_SECRET = "vana-local-auth-2026-8f70d2a9440e4a7fa245438e84859353"

$portableLauncher = Join-Path $PanelPath "DeepPanda_Panel.cmd"
$desktopShortcutPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "DeepPanda Panel.lnk"
if ((Test-Path $portableLauncher) -and -not (Test-Path $desktopShortcutPath)) {
    $shell = New-Object -ComObject WScript.Shell
    $desktopShortcut = $shell.CreateShortcut($desktopShortcutPath)
    $desktopShortcut.TargetPath = "powershell.exe"
    $desktopShortcut.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`" -PanelPath `"$PanelPath`""
    $desktopShortcut.WorkingDirectory = $PanelPath
    $appExe = Join-Path $FolderPath 'DeepPanda.exe'
    if (Test-Path $appExe) {
        $desktopShortcut.IconLocation = "$appExe,0"
    }
    $desktopShortcut.Description = "DeepPanda tasinabilir panel baslaticisi"
    $desktopShortcut.Save()
}

$databasePort = Get-NetTCPConnection -LocalPort 5432 -State Listen -ErrorAction SilentlyContinue
if (-not $databasePort) {
    $databaseLauncher = Start-Process -FilePath $node -ArgumentList "`"$databaseRuntime`"" -WorkingDirectory (Split-Path $databaseRuntime) -WindowStyle Hidden -PassThru
}

$panelPort = Get-NetTCPConnection -LocalPort 3101 -State Listen -ErrorAction SilentlyContinue
if (-not $panelPort) {
    $env:PORT = "3101"
    $env:HOSTNAME = "127.0.0.1"
    $webProcess = Start-Process -FilePath $node -ArgumentList "`"$webRuntime`"" -WorkingDirectory (Split-Path $webRuntime) -WindowStyle Hidden -PassThru
}

$deadline = (Get-Date).AddSeconds(30)
do {
    try {
        $response = Invoke-WebRequest -Uri $panelUrl -UseBasicParsing -TimeoutSec 2
        if ($response.StatusCode -eq 200) { break }
    } catch {
        if ((Get-Date) -ge $deadline) { throw "Kontrol paneli 30 saniye icinde baslatilamadi." }
        Start-Sleep -Milliseconds 500
    }
} while ((Get-Date) -lt $deadline)

$edge = (Get-ItemProperty "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction SilentlyContinue)."(default)"
if (-not $edge) {
    $edge = (Get-ItemProperty "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction SilentlyContinue)."(default)"
}

try {
    if ($edge -and (Test-Path $edge)) {
        $browserProfile = Join-Path $env:LOCALAPPDATA "DeepPanda\panel-browser-$PID"
        $browserProcess = Start-Process -FilePath $edge -ArgumentList @(
            "--app=$panelUrl",
            "--user-data-dir=$browserProfile",
            "--no-first-run",
            "--disable-extensions"
        ) -PassThru
        $browserProcess.WaitForExit()
    } else {
        Start-Process $panelUrl
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "Paneli tamamen kapatmak icin bu pencereye Tamam deyin.",
            "DeepPanda"
        ) | Out-Null
    }
} finally {
    $panelListeners = Get-NetTCPConnection -LocalPort 3101 -State Listen -ErrorAction SilentlyContinue
    foreach ($listener in $panelListeners) {
        $owner = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)" -ErrorAction SilentlyContinue
        if ($owner.ExecutablePath -eq $node) {
            Stop-Process -Id $owner.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }

    $pgCtl = Join-Path $PanelPath "runtime\node_modules\@embedded-postgres\windows-x64\native\bin\pg_ctl.exe"
    if (Test-Path $pgCtl) {
        & $pgCtl stop -D $databaseDir -m fast 2>$null | Out-Null
    }
    if ($databaseLauncher -and -not $databaseLauncher.HasExited) {
        Stop-Process -Id $databaseLauncher.Id -Force -ErrorAction SilentlyContinue
    }
    if ($browserProfile -and (Test-Path $browserProfile)) {
        Remove-Item $browserProfile -Recurse -Force -ErrorAction SilentlyContinue
    }
}
