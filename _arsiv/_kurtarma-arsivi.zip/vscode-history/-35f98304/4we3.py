from __future__ import annotations

import base64
import ctypes
import hashlib
import importlib.util
import io
import ipaddress
import json
import logging
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse
from urllib.request import Request, urlopen

from docx import Document
from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openpyxl import load_workbook
from PIL import Image
from pptx import Presentation
from pydantic import BaseModel
from pypdf import PdfReader, PdfWriter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from starlette.background import BackgroundTask

from agent_orchestrator import decide, plan_for, system_prompt
from agent_tools import AgentTools
from project_paths import (
    IMAGE_MODEL_PATH,
    MEMORY_DB,
    OLLAMA_EXECUTABLE,
    PIPER_MODEL_PATH,
    PLAYWRIGHT_BROWSERS_PATH,
    ROOT,
    VIDEO_MODEL_PATH,
    WORKSPACE_EXCLUDED_PATHS,
    WORKSPACE_ROOT,
)

LOGGER = logging.getLogger(__name__)

if OLLAMA_EXECUTABLE.is_file():
    os.environ["PATH"] = str(OLLAMA_EXECUTABLE.parent) + os.pathsep + os.environ.get("PATH", "")

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_CHAT_BASE_URL = os.getenv("OLLAMA_CHAT_BASE_URL", OLLAMA_BASE_URL).rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen3.6:latest")
OLLAMA_CODE_MODEL = os.getenv("OLLAMA_CODE_MODEL", "codellama:7b")
OLLAMA_EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
CONTINUE_MODEL = os.getenv("CONTINUE_MODEL", OLLAMA_CODE_MODEL)
OLLAMA_TIMEOUT_SECONDS = int(os.getenv("OLLAMA_TIMEOUT_SECONDS", "600"))
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "50")) * 1024 * 1024
INSTAGRAM_GRAPH_VERSION = os.getenv("INSTAGRAM_GRAPH_VERSION", "v23.0")
INSTAGRAM_ACCESS_TOKEN = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")
INSTAGRAM_USER_ID = os.getenv("INSTAGRAM_USER_ID", "")
AGENT_DEV_MODE = os.getenv("AGENT_DEV_MODE", "off").strip().lower()
CHAT_RETENTION_DAYS = int(os.getenv("CHAT_RETENTION_DAYS", "30"))
CHAT_MAX_SESSIONS = int(os.getenv("CHAT_MAX_SESSIONS", "200"))

app = FastAPI(title="LocalQwenAgent")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
AGENT_TOOLS = AgentTools(WORKSPACE_ROOT, WORKSPACE_EXCLUDED_PATHS)
RESEARCH_JOBS: dict[str, dict[str, Any]] = {}
RESEARCH_LOCK = threading.Lock()
BROWSER_SESSIONS: dict[str, dict[str, Any]] = {}
BROWSER_SESSION_LOCK = threading.Lock()
BROWSER_SESSION_TIMEOUT_SECONDS = int(os.getenv("BROWSER_SESSION_TIMEOUT_SECONDS", "900"))
MEDIA_JOBS: dict[str, dict[str, Any]] = {}
MEDIA_JOB_LOCK = threading.Lock()
IMAGE_PIPELINE: Any = None
IMAGE_PIPELINE_LOCK = threading.Lock()
VIDEO_PIPELINE: Any = None
VIDEO_PIPELINE_LOCK = threading.Lock()
PIPER_VOICE: Any = None
PIPER_VOICE_LOCK = threading.Lock()


class ChatRequest(BaseModel):
    message: str
    memory: bool = True
    approve_memory: bool = False
    session_id: str | None = None


class ChatSessionRequest(BaseModel):
    title: str = "Yeni sohbet"


class MemoryRequest(BaseModel):
    note: str
    category: str = "general"
    project: str = ""
    source: str = "user"


class ResearchRequest(BaseModel):
    question: str
    urls: list[str]


class GitHubResearchRequest(BaseModel):
    question: str
    repositories: list[str]


class GitHubTopicResearchRequest(BaseModel):
    topic_url: str
    question: str = "Bu depolarin derin ogrenme ve CNN acisindan onemli desenlerini ozetle."
    limit: int = 5
    download: bool = False
    approved: bool = False
    destination: str = "GitHub-Public"


class GitHubRepoDownloadRequest(BaseModel):
    repository: str
    destination: str
    approved: bool = False


class BrowserRequest(BaseModel):
    url: str


class BrowserActionRequest(BaseModel):
    url: str
    action: str
    selector: str = ""
    value: str = ""
    approved: bool = False


class BrowserSessionStartRequest(BaseModel):
    profile_dir: str = ""
    approved: bool = False


class BrowserSessionActionRequest(BaseModel):
    session_id: str
    url: str = ""
    action: str = "inspect"
    selector: str = ""
    value: str = ""
    approved: bool = False


class ToolRequest(BaseModel):
    command: list[str]
    approved: bool = False


class ShortcutRequest(BaseModel):
    action: str = "create"
    path: str
    target: str = ""
    arguments: str = ""
    working_directory: str = ""
    description: str = ""
    approved: bool = False


class FileWriteRequest(BaseModel):
    path: str
    content: str


class AgentPlanRequest(BaseModel):
    message: str
    approved: bool = False


class AgentExecuteRequest(BaseModel):
    command: list[str]
    approved: bool = False
    task_id: str | None = None


class AgentGenerateRequest(BaseModel):
    request: str
    project_path: str = ""
    role: str = "coding"


class AgentProjectRequest(BaseModel):
    request: str
    project_path: str = ""
    role: str = "coding"
    test_command: list[str] = []
    approved: bool = False
    task_id: str | None = None


class SelfRepairRequest(BaseModel):
    request: str = "Self-audit hatalarini duzelt"
    role: str = "coding"
    test_command: list[str] = []
    approved: bool = False
    task_id: str | None = None
    max_attempts: int = 2
    run_tests: bool = True


class RoleRequest(BaseModel):
    role: str


class AgentApplyRequest(BaseModel):
    files: list[dict[str, str]]
    approved: bool = False
    task_id: str | None = None


class AgentRollbackRequest(BaseModel):
    task_id: str


class FileWorkflowRequest(BaseModel):
    path: str
    action: str = "read"
    content: str = ""
    approved: bool = False


class AgentProfileExecuteRequest(BaseModel):
    profile: str
    action: str = "test"
    approved: bool = False


class SelfAuditRequest(BaseModel):
    run_tests: bool = True


class MediaRequest(BaseModel):
    filename: str
    transcribe: bool = True


class ImageGenerateRequest(BaseModel):
    prompt: str
    steps: int = 4
    width: int = 256
    height: int = 256


class VideoGenerateRequest(BaseModel):
    prompt: str
    duration_seconds: float = 3


class TTSRequest(BaseModel):
    text: str


class VideoEditRequest(BaseModel):
    start_seconds: float = 0
    duration_seconds: float = 10
    output_format: str = "mp4"


class InstagramImagePublishRequest(BaseModel):
    image_url: str
    caption: str = ""
    approved: bool = False


class InstagramVideoPublishRequest(BaseModel):
    video_url: str
    caption: str = ""
    approved: bool = False


class InstagramMessageRequest(BaseModel):
    recipient_id: str
    text: str
    approved: bool = False


class OpenAIChatRequest(BaseModel):
    model: str = "local-qwen"
    messages: list[dict[str, Any]]
    temperature: float | None = None
    max_tokens: int | None = None
    stream: bool = False


class ModelProfileRequest(BaseModel):
    profile: str


class EmbeddingInstallRequest(BaseModel):
    approved: bool = False


class SetupRequest(BaseModel):
    approved: bool = False


class EvaluationRequest(BaseModel):
    approved: bool = False


class ReportExportRequest(BaseModel):
    title: str = "LocalQwenAgent Raporu"
    sources: list[str] = []
    report: dict[str, Any]
    format: str = "md"


AGENT_ROLES: dict[str, dict[str, Any]] = {
    "coding": {"title": "Kodlama", "focus": "Minimal kod degisikligi, test ve API uyumlulugu."},
    "code_analyzer": {"title": "Kod Analisti", "focus": "Kontrol akisi, bagimliliklar ve kok neden analizi."},
    "test_reviewer": {"title": "Test Uzmani", "focus": "En ucuz ayirt edici test, regresyon ve hata toparlama."},
    "security_reviewer": {"title": "Guvenlik Uzmani", "focus": "Path, auth, secret, komut ve veri erisimi sinirlari."},
    "deep_learning": {"title": "Derin Ogrenme", "focus": "Dataset, model, egitim, inference, GPU ve metrikler."},
    "release_manager": {"title": "Release Yoneticisi", "focus": "Compile, paketleme, hash, yedekleme ve teslim kontrolu."},
}

AGENT_CAPABILITIES: list[dict[str, str]] = [
    {"id": "chat_sessions", "title": "Kalici sohbet oturumlari", "description": "SQLite sohbet gecmisi, oturum secme, devam ettirme ve onayli silme."},
    {"id": "engineering_playbook", "title": "Yerel yazilim muhendisligi playbook'u", "description": "Hedefli inceleme, falsifiye edilebilir hipotez, minimal yama, test ve izole dogrulama."},
    {"id": "workspace", "title": "DeepPanda workspace okuma ve guvenli dosya akisi", "description": "DeepPanda/ altindaki kardes proje kaynaklarini sorguya gore okur; DeepPanda-App WORKSPACE_EXCLUDED_DIRS ile simdilik disaridadir. Yazma acik onay, diff, backup ve rollback gerektirir."},
    {"id": "project_delivery", "title": "Offline proje uretimi ve teslimi", "description": "WORKSPACE_ROOT icinde klasor yapisi, kaynak, test, compile ve teslim manifesti; dosya yazimi acik onayla."},
    {"id": "self_repair", "title": "Sinirli self-repair", "description": "Audit, role odakli duzeltme, test ve en fazla uc deneme."},
    {"id": "github_learning", "title": "GitHub topic ve repo ogrenme", "description": "Public repo listeleme, shallow clone, commit ve kalici hafiza."},
    {"id": "deep_learning", "title": "Derin ogrenme pipeline", "description": "WSL CUDA, PyTorch, Transformers, PEFT, dataset ve metrik plani."},
    {"id": "media", "title": "Belge ve medya analizi/uretimi", "description": "PDF, ofis belgeleri, asset katalogu, gorsel, gerçek text-to-video, ses/video, OCR ve Whisper."},
    {"id": "research", "title": "Public web/GitHub arastirmasi", "description": "Kaynak URL takibi ve kaynakli ogrenme notlari."},
    {"id": "observability", "title": "Anlik durum ve provenance", "description": "UI durum paneli, journal, evaluation artifact ve kaynak hashleri."},
]


def db() -> sqlite3.Connection:
    MEMORY_DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(MEMORY_DB)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY, note TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general', project TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'user', created_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    columns = {row[1] for row in connection.execute("PRAGMA table_info(memories)").fetchall()}
    for name, definition in (("category", "TEXT NOT NULL DEFAULT 'general'"), ("project", "TEXT NOT NULL DEFAULT ''"), ("source", "TEXT NOT NULL DEFAULT 'user'")):
        if name not in columns:
            connection.execute(f"ALTER TABLE memories ADD COLUMN {name} {definition}")
    rows = connection.execute("SELECT id, note, category, project, source FROM memories ORDER BY id").fetchall()
    seen: set[tuple[str, str, str, str]] = set()
    duplicate_ids: list[int] = []
    for row_id, note, category, project, source in rows:
        key = (
            re.sub(r"\s+", " ", note or "").strip(),
            "general" if category in (None, "", "None") else str(category),
            "" if project in (None, "", "None") else str(project),
            "user" if source in (None, "", "None") else str(source),
        )
        if key in seen:
            duplicate_ids.append(row_id)
        else:
            seen.add(key)
    if duplicate_ids:
        connection.executemany("DELETE FROM memories WHERE id = ?", [(row_id,) for row_id in duplicate_ids])
    connection.execute(
        "CREATE TABLE IF NOT EXISTS operation_journal (id INTEGER PRIMARY KEY, operation TEXT NOT NULL, reasoning TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS task_records (task_id TEXT PRIMARY KEY, request TEXT NOT NULL, intent TEXT NOT NULL, plan TEXT NOT NULL, approved INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, commands TEXT NOT NULL DEFAULT '[]', changed_files TEXT NOT NULL DEFAULT '[]', tests TEXT NOT NULL DEFAULT '[]', result TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS job_records (job_id TEXT PRIMARY KEY, kind TEXT NOT NULL, question TEXT NOT NULL, urls TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL, artifact_dir TEXT NOT NULL, error TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS library_repositories (repository TEXT PRIMARY KEY, topic TEXT NOT NULL DEFAULT '', local_path TEXT NOT NULL DEFAULT '', commit_sha TEXT NOT NULL DEFAULT '', learned INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS assets (id INTEGER PRIMARY KEY, kind TEXT NOT NULL, path TEXT NOT NULL, relative_path TEXT NOT NULL DEFAULT '', sha256 TEXT NOT NULL DEFAULT '', mime_type TEXT NOT NULL DEFAULT '', project TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'local', metadata_json TEXT NOT NULL DEFAULT '{}', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS chat_sessions (session_id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT 'Yeni sohbet', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('user','assistant')), content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE)"
    )
    connection.execute("CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id, id)")
    return connection


def prune_chat_history(keep_session_id: str | None = None) -> int:
    session_ids: set[str] = set()
    with db() as connection:
        if CHAT_RETENTION_DAYS > 0:
            rows = connection.execute(
                "SELECT session_id FROM chat_sessions WHERE updated_at < datetime('now', ?)",
                (f"-{CHAT_RETENTION_DAYS} days",),
            ).fetchall()
            session_ids.update(row[0] for row in rows)
        if CHAT_MAX_SESSIONS > 0:
            rows = connection.execute(
                "SELECT session_id FROM chat_sessions WHERE session_id != ? ORDER BY updated_at DESC, created_at DESC LIMIT -1 OFFSET ?",
                (keep_session_id or "", max(0, CHAT_MAX_SESSIONS - bool(keep_session_id))),
            ).fetchall()
            session_ids.update(row[0] for row in rows)
        if not session_ids:
            return 0
        connection.executemany("DELETE FROM chat_messages WHERE session_id = ?", [(session_id,) for session_id in session_ids])
        connection.executemany("DELETE FROM chat_sessions WHERE session_id = ?", [(session_id,) for session_id in session_ids])
        connection.commit()
        connection.execute("VACUUM")
    return len(session_ids)


@app.on_event("startup")
def cleanup_expired_chat_history() -> None:
    deleted = prune_chat_history()
    if deleted:
        LOGGER.info("Pruned %s expired chat sessions", deleted)


def register_asset(path: Path, kind: str, mime_type: str = "", project: str = "", source: str = "local", metadata: dict[str, Any] | None = None) -> int:
    resolved = path.resolve()
    digest = hashlib.sha256(resolved.read_bytes()).hexdigest() if resolved.is_file() else ""
    try:
        relative = str(resolved.relative_to(WORKSPACE_ROOT))
    except ValueError:
        relative = str(resolved)
    with db() as connection:
        existing = connection.execute("SELECT id FROM assets WHERE path = ? AND sha256 = ?", (str(resolved), digest)).fetchone()
        if existing:
            return int(existing[0])
        cursor = connection.execute(
            "INSERT INTO assets(kind, path, relative_path, sha256, mime_type, project, source, metadata_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (kind, str(resolved), relative, digest, mime_type, project, source, json.dumps(metadata or {}, ensure_ascii=False)),
        )
        return int(cursor.lastrowid)


def memory_context() -> str:
    with db() as connection:
        rows = connection.execute(
            "SELECT note FROM memories ORDER BY id DESC LIMIT 20"
        ).fetchall()
    return "\n".join(f"- {row[0]}" for row in rows)


def retrieved_memory_context(query: str, limit: int = 8) -> str:
    terms = list(dict.fromkeys(
        term.lower()
        for term in re.findall(r"[\w-]{3,}", query)
        if term.lower() not in {"bir", "icin", "ile", "the", "and"}
    ))
    if not terms:
        return memory_context()
    clauses = " OR ".join("note LIKE ?" for _ in terms)
    relevance = " + ".join("CASE WHEN note LIKE ? THEN 1 ELSE 0 END" for _ in terms)
    with db() as connection:
        rows = connection.execute(
            f"SELECT note, category, project, source FROM memories WHERE {clauses} "
            f"ORDER BY ({relevance}) DESC, id DESC LIMIT ?",
            [*(f"%{term}%" for term in terms), *(f"%{term}%" for term in terms), limit],
        ).fetchall()
    return "\n".join(
        f"- [{category}/{project or 'genel'}/{source}] {note}"
        for note, category, project, source in rows
    ) or memory_context()


def ollama_embed(inputs: list[str]) -> list[list[float]]:
    request = Request(
        f"{OLLAMA_BASE_URL}/api/embed",
        data=json.dumps({"model": OLLAMA_EMBED_MODEL, "input": inputs}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=30) as response:
        result = json.loads(response.read().decode("utf-8"))
    embeddings = result.get("embeddings")
    if not isinstance(embeddings, list) or len(embeddings) != len(inputs):
        raise ValueError("Embedding modeli gecersiz yanit verdi.")
    return embeddings


def cosine_similarity(left: list[float], right: list[float]) -> float:
    dot = sum(a * b for a, b in zip(left, right))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    return dot / (left_norm * right_norm) if left_norm and right_norm else 0.0


def journal_operation(operation: str, reasoning: str, result: str) -> None:
    with db() as connection:
        connection.execute(
            "INSERT INTO operation_journal(operation, reasoning, result) VALUES (?, ?, ?)",
            (operation[:500], reasoning[:4000], result[:12000]),
        )


def update_task(task_id: str | None, **fields: Any) -> None:
    if not task_id or not fields:
        return
    allowed = {"approved", "status", "commands", "changed_files", "tests", "result"}
    updates = {key: value for key, value in fields.items() if key in allowed}
    if not updates:
        return
    assignments = ", ".join(f"{key} = ?" for key in updates) + ", updated_at = CURRENT_TIMESTAMP"
    with db() as connection:
        connection.execute(
            f"UPDATE task_records SET {assignments} WHERE task_id = ?",
            [*updates.values(), task_id],
        )


def operation_context() -> str:
    with db() as connection:
        rows = connection.execute(
            "SELECT operation, reasoning, result FROM operation_journal ORDER BY id DESC LIMIT 10"
        ).fetchall()
    return "\n".join(
        f"- {operation}: neden={reasoning}; sonuc={result}"
        for operation, reasoning, result in rows
    )


def workspace_context(query: str) -> str:
    terms = {word.lower() for word in query.split() if len(word) >= 3}
    if not terms or not WORKSPACE_ROOT.is_dir():
        return ""
    snippets: list[str] = []
    allowed = {".py", ".md", ".txt", ".json", ".ts", ".tsx", ".ps1"}
    ignored_dirs = {
        ".git", ".venv", ".venv-wsl", ".pytest_cache", ".ruff_cache",
        ".localqwen-backups", "__pycache__", "node_modules", ".next",
        "ai-runtimes", "ai-libraries", "github-public", "python311-x64",
        "site-packages", "build", "dist", "target",
    }

    def is_excluded(path: Path) -> bool:
        resolved = path.resolve()
        return any(resolved == excluded or excluded in resolved.parents for excluded in WORKSPACE_EXCLUDED_PATHS)

    scanned_files = 0
    max_scanned_files = 1500
    for current_root, directories, filenames in os.walk(WORKSPACE_ROOT):
        directories[:] = [
            name
            for name in directories
            if name.lower() not in ignored_dirs and not is_excluded(Path(current_root) / name)
        ]
        for filename in filenames:
            if len(snippets) >= 8 or scanned_files >= max_scanned_files:
                break
            path = Path(current_root) / filename
            if path.suffix.lower() not in allowed:
                continue
            scanned_files += 1
            try:
                if path.stat().st_size > 300_000:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            lowered = text.lower()
            if any(term in lowered for term in terms):
                lines = [line.strip() for line in text.splitlines() if line.strip()]
                matches = [line for line in lines if any(term in line.lower() for term in terms)]
                if matches:
                    snippets.append(f"[{path.relative_to(WORKSPACE_ROOT)}] " + " ".join(matches[:3]))
        if len(snippets) >= 8 or scanned_files >= max_scanned_files:
            break
    return "\n".join(snippets)


PROJECT_MAP_NOTE = ROOT / "AI-Libraries" / "decision-notes" / "deeppanda-workspace-map.md"
LOCAL_PROJECT_MARKERS = (
    "deeppanda",
    "localqwenagent",
    "kurulum",
    "programlauncher",
    "vm-tests",
)
PROJECT_OVERVIEW_MARKERS = ("proje", "projeleri", "projeler", "workspace", "kapsam", "harita", "siniflandir", "say")


def local_project_map_context(message: str) -> str:
    lowered = message.casefold()
    is_local_project_question = any(marker in lowered for marker in LOCAL_PROJECT_MARKERS)
    asks_about_scope = any(marker in lowered for marker in PROJECT_OVERVIEW_MARKERS)
    if not is_local_project_question or not asks_about_scope or not PROJECT_MAP_NOTE.is_file():
        return ""
    note = PROJECT_MAP_NOTE.read_text(encoding="utf-8", errors="replace")[:10_000]
    return (
        "CANONICAL LOCAL PROJECT MAP (authoritative for this workspace; do not replace with generic/public projects):\n"
        + note
    )


def call_ollama(
    messages: list[dict[str, Any]],
    json_format: bool = False,
    model: str | None = None,
    num_ctx: int | None = None,
    num_predict: int | None = None,
    timeout: int | None = None,
) -> str:
    payload = {
        "model": model or OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "think": False,
    }
    options: dict[str, int] = {}
    if num_ctx is not None:
        options["num_ctx"] = num_ctx
    if num_predict is not None:
        options["num_predict"] = num_predict
    if options:
        payload["options"] = options
    if json_format:
        payload["format"] = "json"
    request = Request(
        f"{OLLAMA_CHAT_BASE_URL}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout or OLLAMA_TIMEOUT_SECONDS) as response:
            result = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, OSError) as exc:
        raise HTTPException(503, f"Ollama baglantisi kurulamadi: {exc}") from exc
    try:
        message = result["message"]
        content = str(message.get("content", "") or "").strip()
        if content:
            return content
        thinking = str(message.get("thinking", "") or "").strip()
        if thinking:
            return thinking
        return "Model bos yanit dondurdu."
    except (KeyError, TypeError) as exc:
        raise HTTPException(502, "Ollama gecersiz yanit dondurdu.") from exc


def extract_json_object(text: str) -> dict[str, Any]:
    value = text.strip()
    if value.startswith("```"):
        value = re.sub(r"^```(?:json)?\s*|\s*```$", "", value, flags=re.IGNORECASE | re.DOTALL).strip()
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        try:
            from json_repair import repair_json
            parsed = json.loads(repair_json(value))
        except Exception:
            parsed = None
        if isinstance(parsed, dict):
            return parsed
        start, end = value.find("{"), value.rfind("}")
        if start < 0 or end <= start:
            code_blocks = re.findall(r"```(?:python|py)?\s*(.*?)```", value, flags=re.IGNORECASE | re.DOTALL)
            if code_blocks:
                return {"summary": "Model kod blogu uretti.", "files": [{"path": "main.py", "content": code_blocks[0].strip()}], "tests": []}
            raise HTTPException(502, "Model gecerli JSON dosya plani dondurmedi.")
        parsed = json.loads(value[start:end + 1])
    if not isinstance(parsed, dict):
        raise HTTPException(502, "Model dosya plani nesne olmali.")
    return parsed


class _PageTextParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in {"script", "style", "noscript", "svg"}:
            self.skip_depth += 1

    def handle_endtag(self, tag):
        if tag.lower() in {"script", "style", "noscript", "svg"} and self.skip_depth:
            self.skip_depth -= 1

    def handle_data(self, data):
        if not self.skip_depth:
            clean = re.sub(r"\s+", " ", data).strip()
            if clean:
                self.parts.append(clean)


def fetch_web_page(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Yalnizca http/https URL kullanilabilir.")
    host = parsed.hostname.lower()
    if host in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("Yerel adresler web arastirmasinda engellendi.")
    try:
        address = ipaddress.ip_address(host)
        if address.is_private or address.is_loopback or address.is_link_local:
            raise ValueError("Ozel ag adresleri engellendi.")
    except ValueError as exc:
        if "engellendi" in str(exc):
            raise
    request = Request(url, headers={"User-Agent": "LocalQwenAgent/0.1"})
    with urlopen(request, timeout=15) as response:
        raw = response.read(250_000)
    html = raw.decode("utf-8", errors="replace")
    try:
        import trafilatura
        extracted = trafilatura.extract(html, include_comments=False, include_tables=True)
        if extracted:
            return extracted[:40_000]
    except ImportError:
        pass
    parser = _PageTextParser()
    parser.feed(html)
    return " ".join(parser.parts)[:40_000]


def extract_document_text(data: bytes, suffix: str) -> str:
    if suffix == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix in {".docx"}:
        document = Document(io.BytesIO(data))
        return "\n".join(paragraph.text for paragraph in document.paragraphs)
    if suffix in {".pptx"}:
        presentation = Presentation(io.BytesIO(data))
        return "\n".join(
            shape.text for slide in presentation.slides for shape in slide.shapes if hasattr(shape, "text")
        )
    if suffix in {".xlsx", ".xlsm"}:
        workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        rows = []
        for sheet in workbook.worksheets:
            rows.append(f"[{sheet.title}]")
            rows.extend(" | ".join(str(cell.value or "") for cell in row) for row in sheet.iter_rows())
        return "\n".join(rows)
    if suffix in {".txt", ".md", ".py", ".json", ".ts", ".tsx"}:
        return data.decode("utf-8", errors="replace")
    return ""


def document_structure(data: bytes, suffix: str) -> str:
    """Return a compact structural description alongside extracted text."""
    if suffix == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        return f"PDF: sayfa_sayisi={len(reader.pages)}"
    if suffix == ".docx":
        document = Document(io.BytesIO(data))
        tables = sum(1 for _ in document.tables)
        return f"DOCX: paragraf_sayisi={len(document.paragraphs)}, tablo_sayisi={tables}"
    if suffix == ".pptx":
        presentation = Presentation(io.BytesIO(data))
        shapes = sum(len(slide.shapes) for slide in presentation.slides)
        return f"PPTX: slayt_sayisi={len(presentation.slides)}, nesne_sayisi={shapes}"
    if suffix in {".xlsx", ".xlsm"}:
        workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        sheets = [f"{sheet.title}:{sheet.max_row}x{sheet.max_column}" for sheet in workbook.worksheets]
        return "XLSX: sayfalar=" + ", ".join(sheets)
    if suffix in {".png", ".jpg", ".jpeg", ".webp"}:
        image = Image.open(io.BytesIO(data))
        return f"Gorsel: format={image.format}, boyut={image.width}x{image.height}, mod={image.mode}"
    return f"Metin dosyasi: uzanti={suffix}, byte={len(data)}"


def optional_ocr(data: bytes, suffix: str) -> dict[str, Any]:
    if suffix not in {".png", ".jpg", ".jpeg", ".webp", ".pdf"}:
        return {"available": False, "text": "", "reason": "OCR bu dosya turu icin desteklenmiyor."}
    try:
        import pytesseract
        tesseract_path = find_tesseract()
        if tesseract_path:
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        if suffix == ".pdf":
            return {"available": False, "text": "", "reason": "PDF OCR icin sayfa rasterlastirma gerekiyor."}
        image = Image.open(io.BytesIO(data))
        return {"available": True, "text": pytesseract.image_to_string(image, lang="eng")[:20_000], "reason": ""}
    except ImportError:
        return {"available": False, "text": "", "reason": "pytesseract veya Tesseract OCR kurulu degil."}
    except Exception as exc:
        return {"available": False, "text": "", "reason": f"OCR basarisiz: {exc}"}


def find_tesseract() -> str:
    candidates = [
        shutil.which("tesseract"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ]
    return next((path for path in candidates if path and Path(path).is_file()), "")


def report_markdown(title: str, report: dict[str, Any], sources: list[str]) -> str:
    lines = [f"# {title}", "", "## Kaynaklar"]
    lines.extend(f"- {source}" for source in sources or ["Belirtilmedi"])
    lines.extend(["", "## Rapor", "", "```json", json.dumps(report, ensure_ascii=False, indent=2), "```", ""])
    return "\n".join(lines)


def call_ollama_vision(data: bytes, prompt: str, suffix: str) -> str:
    encoded = base64.b64encode(data).decode("ascii")
    payload = {
        "model": OLLAMA_MODEL,
        "messages": [{"role": "user", "content": prompt, "images": [encoded]}],
        "stream": False,
    }
    request = Request(
        f"{OLLAMA_CHAT_BASE_URL}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=180) as response:
            result = json.loads(response.read().decode("utf-8"))
        message = result.get("message", {})
        return str(message.get("content") or message.get("thinking") or "Gorsel yaniti bos.")
    except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise HTTPException(503, f"Vision modeli yaniti alinamadi: {exc}") from exc


def github_sources(repository: str) -> list[str]:
    """Map a public GitHub repository URL to readable public HTTP sources."""
    value = repository.strip().rstrip("/")
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or parsed.hostname != "github.com":
        raise ValueError("Public GitHub repo URL gerekli.")
    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) < 2:
        raise ValueError("GitHub repo URL owner/repo icermeli.")
    owner, repo = parts[0], parts[1].removesuffix(".git")
    return [
        f"https://github.com/{owner}/{repo}",
        f"https://raw.githubusercontent.com/{owner}/{repo}/HEAD/README.md",
    ]


class GitHubTopicParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.repositories: set[str] = set()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "a":
            return
        href = dict(attrs).get("href") or ""
        match = re.fullmatch(r"/([^/]+)/([^/#?]+)", href)
        if match and match.group(1) not in {"topics", "collections", "orgs"}:
            self.repositories.add(f"https://github.com/{match.group(1)}/{match.group(2)}")


def github_topic_repositories(topic_url: str, limit: int = 5) -> list[str]:
    parsed = urlparse(topic_url.strip().rstrip("/"))
    if parsed.scheme not in {"http", "https"} or parsed.hostname != "github.com" or not parsed.path.startswith("/topics/"):
        raise ValueError("Public GitHub topic URL gerekli: https://github.com/topics/...")
    request = Request(topic_url, headers={"User-Agent": "DeepPanda-LocalQwenAgent/1.0"})
    with urlopen(request, timeout=30) as response:
        html = response.read().decode("utf-8", errors="replace")
    parser = GitHubTopicParser()
    parser.feed(html)
    return sorted(parser.repositories)[: max(1, min(limit, 20))]


def learn_repository(repository: str, topic: str, question: str, local_path: str = "") -> str:
    sources = []
    for source_url in github_sources(repository):
        text = fetch_web_page(source_url)
        if text.strip():
            sources.append(f"KAYNAK: {source_url}\n{text[:12000]}")
    if not sources:
        raise ValueError(f"GitHub kaynagi okunamadi: {repository}")
    answer = call_ollama([{"role": "user", "content": (
        "GitHub deposunu incele ve soruya kanita dayali cevap ver. "
        "Ogrenilen teknik desenleri, kurulumu, testleri ve DeepPanda'da uygulanabilecek noktalarini ayir. "
        "Kaynakta olmayan bilgiyi uydurma.\n\nSORU: " + question + "\n\n" + "\n\n".join(sources)
    )}])
    save_typed_memory(
        f"GitHub kutuphane ogrenimi\nRepo: {repository}\nTopic: {topic}\nLocal path: {local_path}\n\n{answer}",
        "research",
        str(WORKSPACE_ROOT),
        "github:" + repository,
    )
    commit_sha = ""
    if local_path:
        try:
            result = subprocess.run(["git", "-C", local_path, "rev-parse", "HEAD"], capture_output=True, text=True, timeout=30, check=False)
            commit_sha = result.stdout.strip()
        except (OSError, subprocess.SubprocessError):
            commit_sha = ""
    with db() as connection:
        connection.execute(
            "INSERT INTO library_repositories(repository, topic, local_path, commit_sha, learned, updated_at) VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP) ON CONFLICT(repository) DO UPDATE SET topic=excluded.topic, local_path=excluded.local_path, commit_sha=excluded.commit_sha, learned=1, updated_at=CURRENT_TIMESTAMP",
            (repository, topic, local_path, commit_sha),
        )
    return answer


def save_memory(note: str) -> None:
    with db() as connection:
        connection.execute("INSERT INTO memories(note) VALUES (?)", (note[:40_000],))


def save_typed_memory(note: str, category: str = "general", project: str = "", source: str = "agent") -> None:
    allowed = {"preference", "project_fact", "procedure", "research", "task_history", "library_knowledge", "agent_workflow", "general"}
    category = category if category in allowed else "general"
    note = re.sub(r"\s+", " ", note).strip()
    with db() as connection:
        candidates = connection.execute(
            "SELECT note FROM memories WHERE COALESCE(category, 'general') = ? AND COALESCE(project, '') = ? AND COALESCE(source, 'user') = ?",
            (category, project[:200], source[:200]),
        ).fetchall()
        if any(re.sub(r"\s+", " ", row[0]).strip() == note[:40_000] for row in candidates):
            return
        connection.execute(
            "INSERT INTO memories(note, category, project, source) VALUES (?, ?, ?, ?)",
            (note[:40_000], category, project[:200], source[:200]),
        )


def save_memory_entry(request: MemoryRequest) -> dict[str, Any]:
    note = re.sub(r"\s+", " ", str(request.note or "")).strip()
    if not note:
        raise HTTPException(400, "Not bos olmalidir.")
    category = str(request.category or "general").strip() or "general"
    project = str(request.project or "").strip()[:200]
    source = str(request.source or "agent").strip() or "agent"
    if category not in {"preference", "project_fact", "procedure", "research", "task_history", "library_knowledge", "agent_workflow", "general"}:
        category = "general"
    save_typed_memory(note, category, project, source)
    with db() as connection:
        row = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories WHERE note = ? AND category = ? AND project = ? AND source = ? ORDER BY id DESC LIMIT 1",
            (note[:40_000], category, project[:200], source[:200]),
        ).fetchone()
    if row is None:
        return {"status": "saved", "note": note, "category": category, "project": project, "source": source}
    fields = ("id", "note", "category", "project", "source", "created_at")
    payload = dict(zip(fields, row))
    payload["status"] = "saved"
    return payload


def memory_taxonomy_summary() -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT category, project, source, COUNT(*) FROM memories GROUP BY category, project, source ORDER BY category, project, source"
        ).fetchall()
    categories: dict[str, dict[str, Any]] = {}
    total = 0
    for category, project, source, count in rows:
        bucket = categories.setdefault(
            str(category or "general"),
            {"count": 0, "projects": set(), "sources": set()},
        )
        bucket["count"] += int(count)
        total += int(count)
        if project:
            bucket["projects"].add(project)
        if source:
            bucket["sources"].add(source)
    summary = {
        "total": total,
        "categories": {},
    }
    for name, bucket in categories.items():
        summary["categories"][name] = {
            "count": int(bucket["count"]),
            "projects": sorted(bucket["projects"]),
            "sources": sorted(bucket["sources"]),
        }
    return summary


def job_event(job_id: str, message: str, **extra: Any) -> None:
    with RESEARCH_LOCK:
        job = RESEARCH_JOBS.get(job_id)
        if job is not None:
            job.setdefault("events", []).append({"time": time.time(), "message": message})
            job.update(extra)


def start_research_job(question: str, urls: list[str]) -> str:
    job_id = uuid.uuid4().hex
    artifact_dir = ROOT / ".job-artifacts" / job_id
    artifact_dir.mkdir(parents=True, exist_ok=True)
    with RESEARCH_LOCK:
        RESEARCH_JOBS[job_id] = {"status": "running", "events": [], "content": "", "question": question, "urls": urls, "cancel_requested": False, "artifact_dir": str(artifact_dir)}
    with db() as connection:
        connection.execute(
            "INSERT INTO job_records(job_id, kind, question, urls, status, artifact_dir) VALUES (?, ?, ?, ?, ?, ?)",
            (job_id, "research", question, json.dumps(urls, ensure_ascii=False), "running", str(artifact_dir)),
        )

    def worker():
        try:
            sources = []
            errors = []
            for index, url in enumerate(urls[:5], 1):
                with RESEARCH_LOCK:
                    cancelled = RESEARCH_JOBS.get(job_id, {}).get("cancel_requested")
                if cancelled:
                    job_event(job_id, "Araştırma kullanıcı tarafından iptal edildi.", status="cancelled")
                    return
                job_event(job_id, f"Kaynak {index}/{len(urls[:5])} okunuyor: {url}")
                try:
                    text = fetch_web_page(url)
                    sources.append(f"KAYNAK: {url}\n{text}")
                    job_event(job_id, f"Kaynak hazır: {url}")
                except Exception as exc:
                    errors.append(f"{url}: {exc}")
                    job_event(job_id, f"Kaynak okunamadı: {url}")
            if not sources:
                raise RuntimeError("Web kaynaklari okunamadi.")
            job_event(job_id, "Qwen kaynakları analiz ediyor...")
            prompt = (
                "Asagidaki web kaynaklarini kullanarak soruyu yanitla. Kaynaklarda olmayan bilgiyi uydurma. "
                "Yanitta hangi URL'den yararlandigini belirt.\n\n"
                f"SORU: {question}\n\n" + "\n\n".join(sources)
            )
            answer = call_ollama([{"role": "user", "content": prompt}])
            job_event(job_id, "Yanıt hazırlandı; kalıcı hafızaya yazılıyor...")
            save_memory(f"Web arastirma notu\nSoru: {question}\nKaynaklar: {', '.join(urls)}\n{answer}")
            (artifact_dir / "result.md").write_text(answer, encoding="utf-8")
            if errors:
                answer += "\n\nOkunamayan kaynaklar:\n" + "\n".join(errors)
            job_event(job_id, "Araştırma tamamlandı ve hafızaya kaydedildi.", status="completed", content=answer)
            with db() as connection:
                connection.execute("UPDATE job_records SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("completed", job_id))
        except Exception as exc:
            (artifact_dir / "error.txt").write_text(str(exc), encoding="utf-8")
            job_event(job_id, f"Araştırma hatası: {exc}", status="failed", error=str(exc))
            with db() as connection:
                connection.execute("UPDATE job_records SET status = ?, error = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("failed", str(exc), job_id))

    threading.Thread(target=worker, daemon=True).start()
    return job_id


def read_upload(upload: UploadFile) -> bytes:
    data = upload.file.read(-1 if MAX_UPLOAD_BYTES <= 0 else MAX_UPLOAD_BYTES + 1)
    if MAX_UPLOAD_BYTES > 0 and len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Dosya boyutu siniri asildi.")
    return data


@app.get("/")
def index() -> FileResponse:
    return FileResponse(ROOT / "static" / "index.html")


def instagram_status() -> dict[str, Any]:
    token = (INSTAGRAM_ACCESS_TOKEN or "").strip()
    user_id = (INSTAGRAM_USER_ID or "").strip()
    if not token or not user_id:
        return {
            "status": "missing_credentials",
            "valid": False,
            "token_present": bool(token),
            "user_id_present": bool(user_id),
            "user_id": user_id,
            "scopes": [],
            "username": "",
            "account_type": "",
            "approval_required": True,
        }
    try:
        app_token_qs = quote(token, safe="")
        debug_request = Request(
            f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/debug_token?input_token={app_token_qs}&access_token={app_token_qs}",
            headers={"User-Agent": "LocalQwenAgent/0.1"},
            method="GET",
        )
        with urlopen(debug_request, timeout=15) as response:
            debug_payload = json.loads(response.read().decode("utf-8"))
        data = debug_payload.get("data") if isinstance(debug_payload, dict) else {}
        scopes = []
        if isinstance(data.get("scopes"), list):
            scopes = [str(item) for item in data.get("scopes", []) if str(item)]
        is_valid = bool(data.get("is_valid"))
        username = ""
        account_type = ""
        try:
            me_request = Request(
                f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/me?fields=id,username,account_type&access_token={app_token_qs}",
                headers={"User-Agent": "LocalQwenAgent/0.1"},
                method="GET",
            )
            with urlopen(me_request, timeout=15) as response:
                me_payload = json.loads(response.read().decode("utf-8"))
            if isinstance(me_payload, dict):
                me_data = me_payload.get("data") if isinstance(me_payload.get("data"), dict) else me_payload
                username = str(me_data.get("username") or "")
                account_type = str(me_data.get("account_type") or "")
        except (HTTPError, URLError, OSError, ValueError, json.JSONDecodeError):
            pass
        ok = is_valid and bool(data.get("user_id") or user_id)
        return {
            "status": "valid" if ok else "invalid_credentials",
            "valid": ok,
            "token_present": True,
            "user_id_present": True,
            "user_id": str(data.get("user_id") or user_id),
            "username": username,
            "account_type": account_type,
            "scopes": scopes,
            "approval_required": not ok,
        }
    except (HTTPError, URLError, ValueError, OSError, json.JSONDecodeError):
        return {
            "status": "invalid_credentials",
            "valid": False,
            "token_present": True,
            "user_id_present": True,
            "user_id": user_id,
            "scopes": [],
            "username": "",
            "account_type": "",
            "approval_required": True,
        }


@app.get("/api/status")
def status() -> dict[str, Any]:
    runtime = runtime_status()
    return {
        "model": OLLAMA_MODEL,
        "ollama": OLLAMA_BASE_URL,
        "workspace": str(WORKSPACE_ROOT),
        "memory_db": str(MEMORY_DB),
        "backup_root": str(AGENT_TOOLS.backup_root),
        "runtime": runtime,
    }


@app.get("/api/instagram/status")
def instagram_api_status() -> dict[str, Any]:
    return instagram_status()


def runtime_status() -> dict[str, Any]:
    gpu_available = False
    gpu_name = ""
    try:
        import torch
        gpu_available = bool(torch.cuda.is_available())
        gpu_name = torch.cuda.get_device_name(0) if gpu_available else ""
    except ImportError:
        pass
    return {
        "offline_ready": True,
        "mode": "offline-first",
        "local": {
            "chat": True,
            "tts": True,
            "neural_tts": PIPER_MODEL_PATH.is_file(),
            "workspace": True,
            "image_generation": IMAGE_MODEL_PATH.is_dir(),
            "video_generation": IMAGE_MODEL_PATH.is_dir() and shutil.which("ffmpeg") is not None,
            "real_video_generation": VIDEO_MODEL_PATH.is_dir(),
            "gpu": {"available": gpu_available, "name": gpu_name},
        },
        "online": {
            "web_browsing": True,
            "github": True,
            "instagram_api": instagram_status()["valid"],
        },
        "approval_required": ["file_write", "command_execution", "browser_action", "instagram_publish"],
    }


@app.get("/api/runtime/status")
def runtime() -> dict[str, Any]:
    return runtime_status()


def hardware_info() -> dict[str, Any]:
    total_ram = 0
    available_ram = 0
    if sys.platform == "win32":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [("length", ctypes.c_ulong), ("memory_load", ctypes.c_ulong), ("total", ctypes.c_ulonglong), ("available", ctypes.c_ulonglong), ("total_page", ctypes.c_ulonglong), ("available_page", ctypes.c_ulonglong), ("total_virtual", ctypes.c_ulonglong), ("available_virtual", ctypes.c_ulonglong), ("available_extended", ctypes.c_ulonglong)]
        memory = MemoryStatus()
        memory.length = ctypes.sizeof(MemoryStatus)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
            total_ram = memory.total
            available_ram = memory.available
    gpu = {"available": False, "name": "", "memory_mb": 0}
    nvidia = shutil.which("nvidia-smi")
    if nvidia:
        try:
            output = subprocess.check_output([nvidia, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"], text=True, timeout=5).splitlines()[0]
            name, memory_mb = [part.strip() for part in output.split(",", 1)]
            gpu = {"available": True, "name": name, "memory_mb": int(memory_mb)}
        except (OSError, subprocess.SubprocessError, ValueError, IndexError):
            pass
    return {"ram_total_mb": total_ram // (1024 * 1024), "ram_available_mb": available_ram // (1024 * 1024), "gpu": gpu}


@app.get("/api/hardware")
def hardware() -> dict[str, Any]:
    return hardware_info()


def backend_health(name: str, url: str) -> dict[str, Any]:
    try:
        with urlopen(url, timeout=2) as response:
            return {"name": name, "available": 200 <= response.status < 500, "url": url}
    except (OSError, HTTPError, URLError):
        return {"name": name, "available": False, "url": url}


@app.get("/api/backends")
def backend_status() -> dict[str, Any]:
    backends = [
        backend_health("ollama", f"{OLLAMA_BASE_URL}/api/tags"),
        backend_health("local-agent-bridge", "http://127.0.0.1:8787/v1/models"),
        backend_health("ktransformers", "http://127.0.0.1:30000/health"),
    ]
    active = next((item["name"] for item in backends if item["available"]), "none")
    return {"order": ["ollama", "local-agent-bridge", "ktransformers"], "active": active, "backends": backends}


@app.get("/api/model-profiles")
def model_profiles() -> dict[str, Any]:
    hardware_state = hardware_info()
    fast_model = OLLAMA_CODE_MODEL
    if hardware_state["ram_available_mb"] and hardware_state["ram_available_mb"] < 4096:
        fast_model = "llama3.1:8b"
    safe_context = 4096
    if hardware_state["ram_available_mb"] >= 32768:
        safe_context = 16384
    elif hardware_state["ram_available_mb"] >= 8192:
        safe_context = 8192
    llama_root = ROOT / "AI-Runtimes" / "llama.cpp"
    llama_candidates = list(llama_root.rglob("llama-server.exe")) if llama_root.is_dir() else []
    llama_model_root = ROOT / "AI-Runtimes" / "models"
    llama_models = [
        path for path in llama_model_root.rglob("*.gguf")
        if path.is_file() and path.stat().st_size >= 100 * 1024 * 1024
    ] if llama_model_root.is_dir() else []
    profiles = {
        "fast": {"backend": "ollama", "model": fast_model, "purpose": "Kisa chat ve kod"},
        "reasoning": {"backend": "ollama", "model": OLLAMA_MODEL, "num_ctx": safe_context, "purpose": "Planlama ve uzun analiz"},
        "vision": {"backend": "ollama", "model": OLLAMA_MODEL, "num_ctx": safe_context, "purpose": "Gorsel analiz"},
        "llama_cpp": {"backend": "llama_cpp", "available": bool(llama_candidates and llama_models), "binary": str(llama_candidates[0]) if llama_candidates else "", "models": [str(path) for path in llama_models]},
    }
    ollama_models: list[str] = []
    try:
        tags = json.loads(urlopen(f"{OLLAMA_BASE_URL}/api/tags", timeout=3).read().decode("utf-8"))
        ollama_models = [str(item.get("name", "")) for item in tags.get("models", [])]
        ollama_available = bool(ollama_models)
    except (OSError, ValueError, HTTPError, URLError):
        ollama_available = False
    embedding_available = any(name == OLLAMA_EMBED_MODEL or name.split(":", 1)[0] == OLLAMA_EMBED_MODEL for name in ollama_models)
    return {"active_model": OLLAMA_MODEL, "hardware": hardware_state, "ollama_available": ollama_available, "ollama_models": ollama_models, "embedding_model": OLLAMA_EMBED_MODEL, "embedding_available": embedding_available, "profiles": profiles}


@app.get("/api/embedding/status")
def embedding_status() -> dict[str, Any]:
    profiles = model_profiles()
    available = profiles["embedding_available"]
    return {"model": OLLAMA_EMBED_MODEL, "available": available, "action": None if available else "ollama pull " + OLLAMA_EMBED_MODEL, "approval_required": not available}


@app.get("/api/ocr/status")
def ocr_status() -> dict[str, Any]:
    tesseract = find_tesseract()
    pytesseract_available = importlib.util.find_spec("pytesseract") is not None
    available = bool(tesseract and pytesseract_available)
    return {
        "available": available,
        "tesseract": tesseract or "",
        "pytesseract": pytesseract_available,
        "approval_required": not available,
        "actions": [] if available else ["python -m pip install pytesseract", "winget install --id UB-Mannheim.TesseractOCR -e"],
    }


@app.post("/api/ocr/prepare")
def prepare_ocr(request: EmbeddingInstallRequest) -> dict[str, Any]:
    status = ocr_status()
    if status["available"]:
        return {"status": "already_available", **status}
    if not request.approved:
        return {"status": "approval_required", **status}
    result = AGENT_TOOLS.run_approved([sys.executable, "-m", "pip", "install", "pytesseract"], approved=True)
    return {"status": "python_binding_installed", **status, "result": result}


@app.get("/api/setup/status")
def setup_status() -> dict[str, Any]:
    profiles = model_profiles()
    ocr = ocr_status()
    llama_model_root = ROOT / "AI-Runtimes" / "models"
    llama_model_ready = any(path.is_file() and path.stat().st_size >= 100 * 1024 * 1024 for path in llama_model_root.glob("*.gguf")) if llama_model_root.is_dir() else False
    dependency_check = subprocess.run(
        [sys.executable, "-m", "pip", "check"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    dependencies_ready = dependency_check.returncode == 0
    chromium_ready = PLAYWRIGHT_BROWSERS_PATH.exists()
    commands = [
        {"name": "python_dependencies", "command": [sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")], "needed": not dependencies_ready},
        {"name": "playwright_chromium", "command": [sys.executable, "-m", "playwright", "install", "chromium"], "needed": True},
        {"name": "qwen_model", "command": ["ollama", "pull", OLLAMA_MODEL], "needed": OLLAMA_MODEL not in profiles["ollama_models"]},
        {"name": "embedding_model", "command": ["ollama", "pull", OLLAMA_EMBED_MODEL], "needed": not profiles["embedding_available"]},
        {"name": "llama_cpp_model", "command": [sys.executable, str(ROOT / "download_llama_model.py")], "needed": not llama_model_ready},
        {"name": "ocr_python", "command": [sys.executable, "-m", "pip", "install", "pytesseract"], "needed": not ocr["pytesseract"]},
        {"name": "ocr_engine", "command": ["winget", "install", "--id", "UB-Mannheim.TesseractOCR", "-e"], "needed": not bool(ocr["tesseract"])},
    ]
    commands[1]["needed"] = not chromium_ready
    return {"ready": not any(item["needed"] for item in commands), "approval_required": True, "commands": commands, "dependency_check": dependencies_ready}


@app.post("/api/setup/prepare")
def prepare_setup(request: SetupRequest) -> dict[str, Any]:
    plan = setup_status()
    if not request.approved:
        return {"status": "approval_required", **plan}
    results = []
    for item in plan["commands"]:
        if not item["needed"]:
            continue
        result = AGENT_TOOLS.run_approved(item["command"], approved=True)
        results.append({"name": item["name"], **result})
        if not result.get("passed"):
            return {"status": "failed", "failed_step": item["name"], "results": results}
    return {"status": "completed", "results": results, "remaining": setup_status()["commands"]}


@app.post("/api/embedding/prepare")
def prepare_embedding(request: EmbeddingInstallRequest) -> dict[str, Any]:
    status = embedding_status()
    if status["available"]:
        return {"status": "already_available", **status}
    if not request.approved:
        return {"status": "approval_required", **status}
    result = AGENT_TOOLS.run_approved(["ollama", "pull", OLLAMA_EMBED_MODEL], approved=True)
    return {"status": "completed", **status, "result": result}


@app.post("/api/model-profiles/select")
def select_model_profile(request: ModelProfileRequest) -> dict[str, Any]:
    profiles = model_profiles()["profiles"]
    profile = profiles.get(request.profile)
    if profile is None:
        raise HTTPException(404, "Model profili bulunamadi.")
    if profile.get("backend") == "llama_cpp" and not profile.get("available"):
        raise HTTPException(503, "llama.cpp runtime bulunamadi; Ollama profilleri kullanilabilir.")
    return {"status": "available", "profile": request.profile, **profile}


@app.get("/api/memory/export")
def export_memory() -> dict[str, Any]:
    with db() as connection:
        memories = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories ORDER BY id"
        ).fetchall()
        operations = connection.execute(
            "SELECT id, operation, reasoning, result, created_at FROM operation_journal ORDER BY id"
        ).fetchall()
    unique_memories = []
    seen_memories: set[tuple[str, str, str, str]] = set()
    for row in memories:
        item = dict(zip(("id", "note", "category", "project", "source", "created_at"), row))
        key = (
            re.sub(r"\s+", " ", item["note"]).strip(),
            item.get("category") or "general",
            item.get("project") or "",
            item.get("source") or "user",
        )
        if key not in seen_memories:
            seen_memories.add(key)
            item["note"] = key[0]
            unique_memories.append(item)
    return {
        "format": "localqwen-memory-v1",
        "exported_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "memories": unique_memories,
        "operations": [dict(zip(("id", "operation", "reasoning", "result", "created_at"), row)) for row in operations],
    }


class MemoryImportRequest(BaseModel):
    payload: dict[str, Any]


@app.post("/api/memory/import")
def import_memory(request: MemoryImportRequest) -> dict[str, int]:
    memories = request.payload.get("memories", [])
    operations = request.payload.get("operations", [])
    imported_memories = 0
    imported_operations = 0
    with db() as connection:
        for item in memories:
            if not isinstance(item, dict) or not str(item.get("note", "")).strip():
                continue
            note = re.sub(r"\s+", " ", str(item["note"])).strip()[:40_000]
            category = str(item.get("category") or "general")
            project = str(item.get("project") or "")[:200]
            source = str(item.get("source") or "user")[:200]
            candidates = connection.execute(
                "SELECT note, category, project, source FROM memories"
            ).fetchall()
            duplicate = any(
                (
                    re.sub(r"\s+", " ", row[0]).strip(),
                    "general" if row[1] in (None, "", "None") else str(row[1]),
                    "" if row[2] in (None, "", "None") else str(row[2]),
                    "user" if row[3] in (None, "", "None") else str(row[3]),
                ) == (note, category, project, source)
                for row in candidates
            )
            if not duplicate:
                connection.execute(
                    "INSERT INTO memories(note, category, project, source) VALUES (?, ?, ?, ?)",
                    (note, category, project, source),
                )
                imported_memories += 1
        for item in operations:
            if not isinstance(item, dict) or not str(item.get("operation", "")).strip():
                continue
            operation = str(item.get("operation", ""))[:500]
            reasoning = str(item.get("reasoning", ""))[:4000]
            result = str(item.get("result", ""))[:12000]
            duplicate = connection.execute(
                "SELECT 1 FROM operation_journal WHERE operation = ? AND reasoning = ? AND result = ? LIMIT 1",
                (operation, reasoning, result),
            ).fetchone()
            if not duplicate:
                connection.execute(
                    "INSERT INTO operation_journal(operation, reasoning, result) VALUES (?, ?, ?)",
                    (operation, reasoning, result),
                )
                imported_operations += 1
    return {"imported_memories": imported_memories, "imported_operations": imported_operations}


def memory_source_preview(source: str) -> dict[str, Any]:
    source = source.strip()
    with db() as connection:
        rows = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories WHERE source = ? ORDER BY id",
            (source,),
        ).fetchall()
        preview = [dict(zip(("id", "note", "category", "project", "source", "created_at"), row)) for row in rows]
    return {"status": "confirmation_required", "source": source, "count": len(preview), "memories": preview[:20]}


@app.get("/api/memory/source")
def preview_memory_by_source(source: str = Query(..., min_length=1, max_length=200)) -> dict[str, Any]:
    return memory_source_preview(source)


@app.delete("/api/memory/source")
def delete_memory_by_source(
    source: str = Query(..., min_length=1, max_length=200),
    confirm: bool = Query(False),
) -> dict[str, Any]:
    source = source.strip()
    if not confirm:
        return memory_source_preview(source)
    with db() as connection:
        rows = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories WHERE source = ? ORDER BY id",
            (source,),
        ).fetchall()
        preview = [dict(zip(("id", "note", "category", "project", "source", "created_at"), row)) for row in rows]
        backup = MEMORY_DB.parent / "backups" / f"deleted-source-{int(time.time())}-{uuid.uuid4().hex}.json"
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_text(json.dumps(preview, ensure_ascii=False, indent=2), encoding="utf-8")
        connection.execute("DELETE FROM memories WHERE source = ?", (source,))
    journal_operation("memory_delete", "Kullanici kaynak bazli hafiza silmeyi onayladi.", json.dumps({"source": source, "count": len(preview), "backup": str(backup)}, ensure_ascii=False))
    return {"status": "deleted", "source": source, "count": len(preview), "backup": str(backup)}


@app.post("/api/memory")
def create_memory(request: MemoryRequest) -> dict[str, Any]:
    return save_memory_entry(request)


@app.get("/api/memory")
def list_memory() -> dict[str, Any]:
    with db() as connection:
        memories = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories ORDER BY id DESC LIMIT 100"
        ).fetchall()
        operations = connection.execute(
            "SELECT id, operation, reasoning, result, created_at FROM operation_journal ORDER BY id DESC LIMIT 100"
        ).fetchall()
    return {
        "memory_db": str(MEMORY_DB),
        "memories": [dict(zip(("id", "note", "category", "project", "source", "created_at"), row)) for row in memories],
        "operations": [
            dict(zip(("id", "operation", "reasoning", "result", "created_at"), row))
            for row in operations
        ],
        "taxonomy": memory_taxonomy_summary(),
    }


@app.get("/api/memory/taxonomy")
def taxonomy_memory() -> dict[str, Any]:
    return memory_taxonomy_summary()


@app.get("/api/memory/search")
def search_memory(
    q: str = Query("", max_length=500),
    project: str = Query("", max_length=200),
    source: str = Query("", max_length=200),
    category: str = Query("", max_length=50),
    since: str = Query("", max_length=32),
    until: str = Query("", max_length=32),
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, Any]:
    clauses = []
    values: list[Any] = []
    if q.strip():
        clauses.append("note LIKE ?")
        values.append(f"%{q.strip()}%")
    if project.strip():
        clauses.append("project LIKE ?")
        values.append(f"%{project.strip()}%")
    if source.strip():
        clauses.append("source LIKE ?")
        values.append(f"%{source.strip()}%")
    if category.strip():
        clauses.append("category = ?")
        values.append(category.strip())
    if since.strip():
        clauses.append("created_at >= ?")
        values.append(since.strip())
    if until.strip():
        clauses.append("created_at <= ?")
        values.append(until.strip())
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with db() as connection:
        rows = connection.execute(
            f"SELECT id, note, category, project, source, created_at FROM memories{where} ORDER BY id DESC LIMIT ?",
            [*values, limit],
        ).fetchall()
    return {
        "query": {"q": q, "project": project, "source": source, "category": category, "since": since, "until": until},
        "count": len(rows),
        "memories": [dict(zip(("id", "note", "category", "project", "source", "created_at"), row)) for row in rows],
    }


@app.get("/api/memory/rag-context")
def memory_rag_context(q: str = Query(..., min_length=1, max_length=500), limit: int = Query(8, ge=1, le=30)) -> dict[str, Any]:
    context = retrieved_memory_context(q, limit)
    return {"query": q, "retrieval": "sqlite-keyword", "context": context, "count": len(context.splitlines()) if context else 0}


@app.get("/api/memory/semantic-search")
def semantic_memory_search(q: str = Query(..., min_length=1, max_length=500), limit: int = Query(8, ge=1, le=30)) -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT id, note, category, project, source, created_at FROM memories ORDER BY id DESC LIMIT 200"
        ).fetchall()
    if not rows:
        return {"query": q, "retrieval": "embedding", "count": 0, "memories": []}
    try:
        vectors = ollama_embed([q] + [row[1] for row in rows])
    except (HTTPError, URLError, OSError, TimeoutError, ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(503, f"Embedding modeli kullanilamiyor ({OLLAMA_EMBED_MODEL}). Kurulum icin onay bekleniyor: ollama pull {OLLAMA_EMBED_MODEL}") from exc
    query_vector = vectors[0]
    scored = sorted(
        ((cosine_similarity(query_vector, vector), row) for vector, row in zip(vectors[1:], rows)),
        key=lambda item: item[0], reverse=True,
    )[:limit]
    fields = ("id", "note", "category", "project", "source", "created_at")
    return {"query": q, "retrieval": "embedding", "embedding_model": OLLAMA_EMBED_MODEL, "count": len(scored), "memories": [{**dict(zip(fields, row)), "score": score} for score, row in scored]}


def asset_preview(asset_id: int) -> dict[str, Any]:
    with db() as connection:
        row = connection.execute(
            "SELECT id, kind, path, relative_path, sha256, mime_type, project, source, metadata_json, created_at, updated_at FROM assets WHERE id = ?",
            (asset_id,),
        ).fetchone()
    if not row:
        raise HTTPException(404, "Asset bulunamadi.")
    fields = ("id", "kind", "path", "relative_path", "sha256", "mime_type", "project", "source", "metadata_json", "created_at", "updated_at")
    asset = dict(zip(fields, row))
    asset["download_url"] = f"/api/assets/{asset_id}/download"
    asset["preview_url"] = f"/api/assets/{asset_id}/download"
    return asset


@app.get("/api/assets")
def list_assets(
    kind: str = Query("", max_length=30),
    q: str = Query("", max_length=500),
    limit: int = Query(100, ge=1, le=500),
) -> dict[str, Any]:
    kind = kind if isinstance(kind, str) else ""
    q = q if isinstance(q, str) else ""
    clauses: list[str] = []
    values: list[Any] = []
    if kind.strip():
        clauses.append("kind = ?")
        values.append(kind.strip())
    if q.strip():
        clauses.append("(path LIKE ? OR relative_path LIKE ? OR metadata_json LIKE ?)")
        values.extend([f"%{q.strip()}%"] * 3)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with db() as connection:
        rows = connection.execute(
            f"SELECT id, kind, path, relative_path, sha256, mime_type, project, source, metadata_json, created_at, updated_at FROM assets{where} ORDER BY updated_at DESC LIMIT ?",
            [*values, limit],
        ).fetchall()
    fields = ("id", "kind", "path", "relative_path", "sha256", "mime_type", "project", "source", "metadata_json", "created_at", "updated_at")
    assets = [dict(zip(fields, row)) for row in rows]
    for asset in assets:
        asset_id = int(asset["id"])
        asset["download_url"] = f"/api/assets/{asset_id}/download"
        asset["preview_url"] = f"/api/assets/{asset_id}/download"
    return {"count": len(rows), "assets": assets}


@app.get("/api/assets/{asset_id}/preview")
def preview_asset(asset_id: int) -> dict[str, Any]:
    return asset_preview(asset_id)


@app.get("/api/assets/{asset_id}/download")
def download_asset(asset_id: int) -> FileResponse:
    with db() as connection:
        row = connection.execute("SELECT path, mime_type FROM assets WHERE id = ?", (asset_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Asset bulunamadi.")
    path = Path(row[0]).resolve()
    if not path.is_file():
        raise HTTPException(410, "Asset dosyasi artik mevcut degil.")
    return FileResponse(path, media_type=row[1] or None, filename=path.name)


@app.delete("/api/assets/{asset_id}")
def delete_asset(asset_id: int, approved: bool = Query(False)) -> dict[str, Any]:
    with db() as connection:
        row = connection.execute("SELECT path, kind FROM assets WHERE id = ?", (asset_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Asset bulunamadi.")
    candidate = Path(row[0])
    asset_root = (ROOT / ".asset-store").resolve()
    if candidate.is_symlink():
        raise HTTPException(403, "Sembolik baglanti olan asset silinemez.")
    path = candidate.resolve()
    if asset_root not in path.parents:
        raise HTTPException(403, "Yalniz .asset-store altindaki yonetilen asset dosyalari silinebilir.")
    if not approved:
        return {"status": "approval_required", "asset_id": asset_id, "kind": row[1], "filename": path.name}
    file_removed = False
    try:
        if path.is_file():
            path.unlink()
            file_removed = True
    except OSError as exc:
        raise HTTPException(500, f"Asset dosyasi silinemedi: {exc}") from exc
    with db() as connection:
        connection.execute("DELETE FROM assets WHERE id = ?", (asset_id,))
    journal_operation(
        "asset_delete",
        "Kullanici asset kalici silme islemini onayladi.",
        json.dumps({"asset_id": asset_id, "kind": row[1], "file_removed": file_removed}, ensure_ascii=False),
    )
    return {"status": "deleted", "asset_id": asset_id, "file_removed": file_removed}


@app.post("/api/tts")
def synthesize_tts(request: TTSRequest) -> FileResponse:
    """Synthesize Turkish speech locally with the configured Piper voice."""
    global PIPER_VOICE
    text = request.text.strip()
    if not text or len(text) > 20_000:
        raise HTTPException(400, "TTS metni 1-20000 karakter olmali.")
    if not PIPER_MODEL_PATH.is_file():
        raise HTTPException(503, f"Piper ses modeli bulunamadi: {PIPER_MODEL_PATH}")
    try:
        import wave

        from piper import PiperVoice

        voice_key = hashlib.sha256(f"{text}\n{PIPER_MODEL_PATH.resolve()!s}".encode()).hexdigest()[:32]
        output_dir = ROOT / ".asset-store" / "generated"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = output_dir / f"localqwen_tts_{voice_key}.wav"
        if output.exists() and output.stat().st_size > 0:
            register_asset(output, "audio", "audio/wav", source="generated", metadata={"text_length": len(text), "voice": PIPER_MODEL_PATH.stem, "cache_key": voice_key})
            return FileResponse(output, media_type="audio/wav", filename="localqwen_tts.wav")

        with PIPER_VOICE_LOCK:
            if PIPER_VOICE is None:
                PIPER_VOICE = PiperVoice.load(str(PIPER_MODEL_PATH))
            with wave.open(str(output), "wb") as wav_file:
                PIPER_VOICE.synthesize_wav(text, wav_file)
        register_asset(output, "audio", "audio/wav", source="generated", metadata={"text_length": len(text), "voice": PIPER_MODEL_PATH.stem, "cache_key": voice_key})
        return FileResponse(output, media_type="audio/wav", filename="localqwen_tts.wav")
    except Exception as exc:
        raise HTTPException(503, f"Yerel TTS basarisiz: {exc}") from exc


@app.get("/v1/models")
def openai_models() -> dict[str, Any]:
    return {
        "object": "list",
        "data": [{"id": "local-qwen", "object": "model", "owned_by": "LocalQwenAgent"}],
    }


@app.post("/v1/chat/completions")
def openai_chat(request: OpenAIChatRequest) -> dict[str, Any]:
    messages = [
        {"role": item.get("role", "user"), "content": str(item.get("content", ""))}
        for item in request.messages
        if item.get("role") in {"system", "user", "assistant"}
        and str(item.get("content", "")).strip()
    ]
    if not messages:
        raise HTTPException(400, "En az bir gecerli mesaj gerekli.")
    content = call_ollama(messages, model=CONTINUE_MODEL, num_predict=request.max_tokens)
    user_message = next(
        (item["content"] for item in reversed(messages) if item["role"] == "user"),
        "",
    )
    journal_operation(
        "v1_chat",
        "VS Code uyumlu yerel kopru istegi Ollama'ya yonlendirildi.",
        json.dumps(
            {"model": request.model, "message_length": len(user_message), "status": "completed"},
            ensure_ascii=False,
        ),
    )
    created = int(time.time())
    return {
        "id": f"chatcmpl-local-{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": created,
        "model": request.model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
    }


@app.post("/api/agent/plan")
def agent_plan(request: AgentPlanRequest) -> dict[str, Any]:
    decision = decide(request.message)
    task_id = uuid.uuid4().hex
    steps = plan_for(request.message)
    result = {
        "task_id": task_id,
        "intent": decision.intent,
        "steps": steps,
        "approval_required": decision.needs_tool_approval,
        "approved": request.approved,
        "status": "ready_to_execute" if request.approved else "plan_only",
    }
    with db() as connection:
        connection.execute(
            "INSERT INTO task_records(task_id, request, intent, plan, approved, status) VALUES (?, ?, ?, ?, ?, ?)",
            (task_id, request.message, decision.intent, json.dumps(steps, ensure_ascii=False), int(request.approved), result["status"]),
        )
    journal_operation("plan", decision.instructions, json.dumps(result, ensure_ascii=False))
    return result


@app.get("/api/agent/tasks")
def agent_tasks() -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT task_id, request, intent, plan, approved, status, commands, changed_files, tests, result, created_at, updated_at FROM task_records ORDER BY created_at DESC LIMIT 100"
        ).fetchall()
    fields = ("task_id", "request", "intent", "plan", "approved", "status", "commands", "changed_files", "tests", "result", "created_at", "updated_at")
    return {"tasks": [dict(zip(fields, row)) for row in rows]}


@app.post("/api/agent/file")
def agent_file_workflow(request: FileWorkflowRequest) -> dict[str, Any]:
    if request.action == "read":
        return {"status": "read", **AGENT_TOOLS.read_file(request.path)}
    if request.action != "write":
        raise HTTPException(400, "Dosya islemi read veya write olmali.")
    preview = AGENT_TOOLS.preview_write(request.path, request.content)
    if not request.approved:
        return {"status": "approval_required", "preview": preview}
    result = AGENT_TOOLS.write_file(request.path, request.content)
    verified = AGENT_TOOLS.read_file(request.path)
    journal_operation("file_workflow", "Kullanici dosya yazma islemini onayladi.", json.dumps({"path": request.path, "verified": verified["content"] == request.content}, ensure_ascii=False))
    return {"status": "written", "result": result, "verified": verified["content"] == request.content}


@app.get("/api/agent/profiles")
def agent_profiles() -> dict[str, Any]:
    profiles: list[dict[str, Any]] = []
    requirements = ROOT / "requirements.txt"
    if requirements.exists():
        profiles.append({
            "name": "dependencies",
            "detected": True,
            "actions": {
                "check": [sys.executable, "-m", "pip", "check"],
                "install": [sys.executable, "-m", "pip", "install", "-r", str(requirements)],
            },
        })
    if (WORKSPACE_ROOT / "pyproject.toml").exists() or list(WORKSPACE_ROOT.glob("*.py")):
        agent_test = WORKSPACE_ROOT / "test_agent.py"
        if not agent_test.exists():
            agent_test = ROOT / "test_agent.py"
        test_command = [sys.executable, "-m", "pytest", "-q"]
        if agent_test.exists():
            test_command.append(str(agent_test.relative_to(WORKSPACE_ROOT)))
        else:
            test_command.extend(["--ignore=AI-Runtimes", "--ignore=DeepPanda/DeepPanda-App/tools"])
        profiles.append({
            "name": "python",
            "detected": True,
            "actions": {
                "test": test_command,
                "compile": [sys.executable, "-m", "compileall", "-q", str(ROOT)],
                "lint": ["ruff", "check", str(ROOT)],
            },
        })
    if (WORKSPACE_ROOT / "package.json").exists():
        profiles.append({
            "name": "node",
            "detected": True,
            "actions": {
                "test": ["npm", "test"],
                "build": ["npm", "run", "build"],
                "lint": ["npm", "run", "lint"],
            },
        })
    if (WORKSPACE_ROOT / "DeepPanda").exists() or WORKSPACE_ROOT.name.lower().startswith("deeppanda"):
        profiles.append({
            "name": "deeppanda",
            "detected": True,
            "actions": {
                "test": [sys.executable, "-m", "pytest", "-q", "--ignore=AI-Runtimes", "--ignore=DeepPanda/DeepPanda-App/tools"],
                "compile": [sys.executable, "-m", "compileall", "DeepPanda"],
            },
        })
    return {"workspace": str(WORKSPACE_ROOT), "profiles": profiles}


@app.get("/api/agent/roles")
def agent_roles() -> dict[str, Any]:
    return {"roles": [{"name": name, **details} for name, details in AGENT_ROLES.items()]}


@app.get("/api/capabilities")
def capabilities() -> dict[str, Any]:
    return {"capabilities": AGENT_CAPABILITIES, "roles": agent_roles()["roles"]}


@app.post("/api/agent/profile/execute")
def agent_profile_execute(request: AgentProfileExecuteRequest) -> dict[str, Any]:
    profiles = agent_profiles()["profiles"]
    profile = next((item for item in profiles if item["name"] == request.profile), None)
    if profile is None or request.action not in profile["actions"]:
        raise HTTPException(404, "Profil veya profil islemi bulunamadi.")
    command = profile["actions"][request.action]
    if not request.approved:
        return {"status": "approval_required", "profile": request.profile, "action": request.action, "command": command}
    result = AGENT_TOOLS.run_approved(command, approved=True)
    journal_operation("profile_command", f"Profil={request.profile}, islem={request.action}", json.dumps(result, ensure_ascii=False))
    return {"profile": request.profile, "action": request.action, "command": command, **result}


@app.post("/api/evaluation/run")
def run_evaluation(request: EvaluationRequest) -> dict[str, Any]:
    command = [sys.executable, str(ROOT / "run_evaluation.py")]
    if not request.approved:
        return {
            "status": "approval_required",
            "suite": "offline-coding-agent-hard",
            "checks": ["intent classification", "plan quality", "source-aware research intent", "persistent learning intent"],
            "command": command,
        }
    started = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=180, check=False)
    payload = {
        "status": "completed",
        "passed": result.returncode == 0,
        "returncode": result.returncode,
        "duration_seconds": round(time.perf_counter() - started, 3),
        "suite": "offline-coding-agent-hard",
        "stdout": result.stdout[-12000:],
        "stderr": result.stderr[-12000:],
    }
    journal_operation("evaluation", "Kullanici zor offline agent testini onayladi.", json.dumps(payload, ensure_ascii=False))
    return payload


@app.post("/api/agent/execute")
def agent_execute(request: AgentExecuteRequest) -> dict[str, Any]:
    if not request.approved:
        update_task(request.task_id, status="approval_required", commands=json.dumps(request.command, ensure_ascii=False))
        return {"status": "approval_required", "command": request.command}
    result = AGENT_TOOLS.run_approved(request.command, approved=True)
    update_task(
        request.task_id,
        approved=1,
        status=result.get("status", "completed"),
        commands=json.dumps(request.command, ensure_ascii=False),
        result=json.dumps(result, ensure_ascii=False),
    )
    journal_operation("command", "Kullanici acik onay verdi.", json.dumps(result, ensure_ascii=False))
    save_memory(f"Agent komut sonucu\nKomut: {' '.join(request.command)}\nDurum: {result.get('status')}\nKod: {result.get('returncode')}")
    return result


@app.post("/api/agent/generate")
def agent_generate(request: AgentGenerateRequest) -> dict[str, Any]:
    role = request.role if request.role in AGENT_ROLES else "coding"
    role_focus = AGENT_ROLES[role]["focus"]
    context = workspace_context(request.request)
    prompt = (
        f"Sen {AGENT_ROLES[role]['title']} rolundeki yazilim agentsin. Odak: {role_focus} "
        "Kullanici istegi icin dosya plani ve kod uret. "
        "Yalnizca JSON don: {\"summary\": string, \"files\": [{\"path\": string, \"content\": string}], \"tests\": [string]}. "
        "Dosya yollari secili proje kokune goreli olsun. Secili hedef proje yolu WORKSPACE_ROOT icinde veya "
        "ALLOW_EXTERNAL_PATHS ile izin verilen korumasiz bir konumda olabilir. Hedef kokun disina cikma; "
        "Windows/Program Files/ProgramData korumali yollarina dosya uretme. "
        "Mevcut baglami koru ve test edilebilir kod yaz.\n\n"
        f"ISTEK: {request.request}\nPROJE YOLU: {request.project_path}\nMEVCUT BAGLAM:\n{context or 'Yok'}"
    )
    generated = extract_json_object(
        call_ollama(
            [{"role": "user", "content": prompt}],
            json_format=True,
            model=OLLAMA_CODE_MODEL,
            num_ctx=8192,
            num_predict=4096,
            timeout=300,
        )
    )
    files = generated.get("files", [])
    if not isinstance(files, list) or any(
        not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("content"), str)
        for item in files
    ):
        raise HTTPException(502, "Model dosya planinda path/content eksik.")
    wants_project = any(word in request.request.lower() for word in ("proje", "oyun", "uygulama", "program", "kütüphane", "kutuphane"))
    has_python = any(isinstance(item, dict) and str(item.get("path", "")).lower().endswith(".py") for item in files)
    has_test_file = any(
        isinstance(item, dict)
        and Path(str(item.get("path", ""))).name.lower().startswith("test_")
        and str(item.get("path", "")).lower().endswith(".py")
        for item in files
    )
    if wants_project and (len(files) < 2 or (has_python and not has_test_file)):
        repair_prompt = (
            "Onceki kod uretimi eksik kaldi. Ana kaynak dosyalarini koru ve eksikleri tamamla. "
            "Yalnizca JSON don: {\"summary\": string, \"files\": [{\"path\": string, \"content\": string}], \"tests\": [string]}. "
            "Python projesiyse calistirilabilir unittest veya pytest kullanan tests/test_*.py dosyasi uret. "
            "README ozellikleri gercek kodla eslesmeli; TODO/pass iskeletini tamamlanmis proje gibi sunma. "
            f"\nISTEK: {request.request}\nONCEKI DOSYALAR: {json.dumps(files, ensure_ascii=False)}"
        )
        repaired = extract_json_object(
            call_ollama(
                [{"role": "user", "content": repair_prompt}],
                json_format=True,
                model=OLLAMA_CODE_MODEL,
                num_ctx=8192,
                num_predict=4096,
                timeout=300,
            )
        )
        repaired_files = repaired.get("files", [])
        if isinstance(repaired_files, list) and repaired_files:
            merged = {item["path"]: item for item in files if isinstance(item, dict) and isinstance(item.get("path"), str)}
            merged.update({item["path"]: item for item in repaired_files if isinstance(item, dict) and isinstance(item.get("path"), str) and isinstance(item.get("content"), str)})
            generated = {**generated, **repaired, "files": list(merged.values())}
    return generated


def project_delivery_status(test_result: dict[str, Any]) -> str:
    if test_result.get("status") == "test_skipped" or test_result.get("passed") is None:
        return "delivered_unverified"
    return "delivered" if test_result.get("passed") else "delivered_with_test_failure"


@app.post("/api/agent/project")
def agent_project(request: AgentProjectRequest) -> dict[str, Any]:
    if not request.request.strip():
        raise HTTPException(400, "Proje istegi bos olamaz.")
    role = request.role if request.role in AGENT_ROLES else "coding"
    try:
        project_root = AGENT_TOOLS.safe_path(request.project_path or ".")
    except ValueError as exc:
        raise HTTPException(403, str(exc)) from exc
    if not request.approved:
        return {
            "status": "approval_required",
            "role": role,
            "project_path": str(project_root),
            "test_command": request.test_command,
            "plan": [
                "Proje gereksinimlerini ve mevcut workspace yapisini incele",
                "Kaynak, test, README ve konfigurasyon dosyalarini planla",
                "Dosya diff'lerini ve olusturulacak klasorleri goster",
                "Onay sonrasi dosyalari backup ile yaz",
                "Test/compile calistir ve teslim manifesti olustur",
            ],
        }
    generated = agent_generate(AgentGenerateRequest(request=request.request, project_path=request.project_path, role=role))
    files = generated.get("files", [])
    if not isinstance(files, list) or not files:
        raise HTTPException(502, "Proje modeli dosya uretmedi.")
    validated_files: list[dict[str, str]] = []
    for item in files:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("content"), str):
            raise HTTPException(502, "Proje dosya planinda path/content eksik.")
        supplied_path = Path(item["path"])
        candidate = supplied_path if supplied_path.is_absolute() else project_root / supplied_path
        try:
            target = AGENT_TOOLS.safe_path(str(candidate))
        except ValueError as exc:
            raise HTTPException(403, f"Uretilen dosya yolu reddedildi: {item['path']}") from exc
        if target != project_root and project_root not in target.parents:
            raise HTTPException(403, f"Dosya secilen proje kokunun disina cikiyor: {item['path']}")
        validated_files.append({"path": str(target), "content": item["content"]})
    results = [AGENT_TOOLS.write_file(item["path"], item["content"]) for item in validated_files]
    test_command = request.test_command
    if not test_command:
        python_files = [item["path"] for item in validated_files if item["path"].endswith(".py")]
        test_files = [item["path"] for item in validated_files if Path(item["path"]).name.startswith("test_")]
        if test_files:
            test_command = [sys.executable, "-m", "pytest", "-q", *test_files]
        elif python_files:
            test_command = [sys.executable, "-m", "py_compile", *python_files]
    test_result = AGENT_TOOLS.run_approved(test_command, approved=True) if test_command else {"status": "test_skipped", "passed": True}
    manifest = {
        "status": project_delivery_status(test_result),
        "role": role,
        "project_path": str(project_root),
        "summary": generated.get("summary", ""),
        "files": [{"path": item["path"], "backup": result.get("backup", "")} for item, result in zip(validated_files, results)],
        "tests": test_result,
        "requested_tests": generated.get("tests", []),
    }
    artifact_dir = ROOT / ".job-artifacts"
    artifact_dir.mkdir(exist_ok=True)
    artifact_path = artifact_dir / f"project-delivery-{uuid.uuid4().hex}.json"
    artifact_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    update_task(request.task_id, approved=1, status=manifest["status"], changed_files=json.dumps([item["path"] for item in validated_files], ensure_ascii=False), tests=json.dumps(test_result, ensure_ascii=False), result=json.dumps(manifest, ensure_ascii=False))
    journal_operation("project_delivery", f"Role={role}", json.dumps(manifest, ensure_ascii=False))
    save_memory(f"Proje teslimi: {manifest['status']}, dosya sayisi={len(validated_files)}, artifact={artifact_path}")
    return {**manifest, "artifact": str(artifact_path)}


@app.post("/api/agent/apply")
def agent_apply(request: AgentApplyRequest) -> dict[str, Any]:
    if not request.files:
        raise HTTPException(400, "Uygulanacak dosya bulunamadi.")
    if not request.approved:
        previews = [
            AGENT_TOOLS.preview_write(item["path"], item["content"])
            for item in request.files
        ]
        return {"status": "approval_required", "previews": previews}
    results = []
    for item in request.files:
        results.append(AGENT_TOOLS.write_file(item["path"], item["content"]))
    update_task(
        request.task_id,
        approved=1,
        status="completed",
        changed_files=json.dumps([item["path"] for item in results], ensure_ascii=False),
        result=json.dumps(results, ensure_ascii=False),
    )
    journal_operation("file_apply", "Kullanici acik onay verdi; workspace backup uygulandi.", f"{len(results)} dosya")
    save_memory(f"Agent dosya uygulama sonucu: {len(results)} dosya yazildi.")
    return {"status": "applied", "files": results}


@app.post("/api/agent/self-repair")
def agent_self_repair(request: SelfRepairRequest) -> dict[str, Any]:
    if not request.request.strip():
        raise HTTPException(400, "Self-repair istegi bos olamaz.")
    role = request.role if request.role in AGENT_ROLES else "coding"
    attempts = max(1, min(request.max_attempts, 3))
    if not request.approved:
        return {
            "status": "approval_required",
            "role": role,
            "attempts": attempts,
            "test_command": request.test_command,
            "plan": [
                "Workspace ve ilgili dosyalari incele",
                "Role odakli minimal degisikligi uret ve diff hazirla",
                "Onay sonrasi backup ile uygula",
                "Testi calistir; basarisizsa ayni slice icinde sinirli tekrar dene",
                "Sonucu, testleri ve rollback bilgisini kaydet",
            ],
        }
    if request.test_command and request.test_command[0].lower() not in {"python", "py", "pytest", "ruff", "npm", "node"}:
        raise HTTPException(400, "Self-repair test komutu izinli bir Python/Node araci ile baslamali.")
    all_results: list[dict[str, object]] = []
    test_result: dict[str, object] | None = None
    generation_request = request.request
    for attempt in range(1, attempts + 1):
        generated = agent_generate(AgentGenerateRequest(request=generation_request, role=role))
        files = generated.get("files", [])
        if not isinstance(files, list) or not files:
            raise HTTPException(502, "Self-repair modeli uygulanabilir dosya uretmedi.")
        for item in files:
            if not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("content"), str):
                raise HTTPException(502, "Self-repair dosya planinda path/content eksik.")
        for item in files:
            all_results.append(AGENT_TOOLS.write_file(item["path"], item["content"]))
        if not request.test_command:
            test_result = {"passed": True, "status": "test_skipped", "reason": "Test komutu verilmedi."}
            break
        test_result = AGENT_TOOLS.run_approved(request.test_command, approved=True)
        if test_result.get("passed"):
            break
        generation_request = (
            f"{request.request}\n\nSelf-repair attempt {attempt} failed validation. "
            f"Test output:\n{test_result.get('stdout', '')}\n{test_result.get('stderr', '')}\n"
            "Inspect the same slice, correct the failure, and return only the complete replacement files."
        )
    if test_result and test_result.get("status") == "test_skipped":
        status = "unverified"
    else:
        status = "completed" if test_result and test_result.get("passed") else "failed_validation"
    payload = {"status": status, "role": role, "attempts_used": attempt, "files": all_results, "test": test_result}
    update_task(
        request.task_id,
        approved=1,
        status=status,
        changed_files=json.dumps([item.get("path") for item in all_results], ensure_ascii=False),
        tests=json.dumps(test_result or {}, ensure_ascii=False),
        result=json.dumps(all_results, ensure_ascii=False),
    )
    journal_operation("self_repair", f"Role={role}, attempts={attempt}", json.dumps(payload, ensure_ascii=False))
    save_memory(f"Self-repair sonucu: role={role}, status={status}, attempts={attempt}")
    return payload


@app.post("/api/agent/rollback")
def agent_rollback(request: AgentRollbackRequest) -> dict[str, Any]:
    with db() as connection:
        row = connection.execute(
            "SELECT result, status FROM task_records WHERE task_id = ?",
            (request.task_id,),
        ).fetchone()
    if row is None:
        raise HTTPException(404, "Task bulunamadi.")
    result_text, status = row
    if status != "completed":
        raise HTTPException(409, "Yalnizca tamamlanmis task geri alinabilir.")
    try:
        results = json.loads(result_text)
    except json.JSONDecodeError as exc:
        raise HTTPException(500, "Task sonucu gecersiz.") from exc
    if not isinstance(results, list) or not results:
        raise HTTPException(409, "Task geri alinabilir dosya sonucu icermiyor.")
    rolled_back = [AGENT_TOOLS.rollback_write(item) for item in results]
    update_task(request.task_id, status="rolled_back", result=json.dumps(rolled_back, ensure_ascii=False))
    journal_operation("rollback", "Kullanici task geri alma istedi.", json.dumps(rolled_back, ensure_ascii=False))
    return {"status": "rolled_back", "files": rolled_back}


@app.post("/api/agent/self-audit")
def agent_self_audit(request: SelfAuditRequest) -> dict[str, Any]:
    python_files = sorted(
        path for path in ROOT.glob("*.py") if path.name != "memory.db"
    )
    compile_result = subprocess.run(
        [sys.executable, "-m", "py_compile", *(str(path) for path in python_files)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )
    test_result: subprocess.CompletedProcess[str] | None = None
    if request.run_tests:
        test_result = subprocess.run(
            [sys.executable, "-m", "pytest", "test_agent.py", "-q"],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
    result = {
        "status": "passed" if compile_result.returncode == 0 and (test_result is None or test_result.returncode == 0) else "failed",
        "python_files": [path.name for path in python_files],
        "compile_returncode": compile_result.returncode,
        "compile_output": (compile_result.stdout + compile_result.stderr)[-4000:],
        "tests_returncode": None if test_result is None else test_result.returncode,
        "tests_output": None if test_result is None else (test_result.stdout + test_result.stderr)[-4000:],
    }
    learning = (
        "Self-audit yerel olarak tamamlandi: "
        f"{len(python_files)} Python dosyasi derlendi; "
        f"compile={compile_result.returncode}; "
        f"tests={None if test_result is None else test_result.returncode}."
    )
    journal_operation("self_audit", "Agent kendi workspace kodunu ve testlerini kontrol etti.", json.dumps(result, ensure_ascii=False))
    save_memory(learning)
    return result


@app.get("/api/chat/sessions")
def list_chat_sessions() -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT s.session_id, s.title, s.created_at, s.updated_at, COUNT(m.id) FROM chat_sessions s LEFT JOIN chat_messages m ON m.session_id = s.session_id GROUP BY s.session_id ORDER BY s.updated_at DESC"
        ).fetchall()
    fields = ("session_id", "title", "created_at", "updated_at", "message_count")
    return {"sessions": [dict(zip(fields, row)) for row in rows]}


@app.post("/api/chat/sessions")
def create_chat_session(request: ChatSessionRequest) -> dict[str, str]:
    session_id = uuid.uuid4().hex
    title = request.title.strip()[:100] or "Yeni sohbet"
    with db() as connection:
        connection.execute("INSERT INTO chat_sessions(session_id, title) VALUES (?, ?)", (session_id, title))
    prune_chat_history(session_id)
    return {"session_id": session_id, "title": title}


@app.get("/api/chat/sessions/{session_id}/messages")
def get_chat_messages(session_id: str) -> dict[str, Any]:
    with db() as connection:
        exists = connection.execute("SELECT 1 FROM chat_sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not exists:
            raise HTTPException(404, "Sohbet oturumu bulunamadi.")
        rows = connection.execute(
            "SELECT id, role, content, created_at FROM chat_messages WHERE session_id = ? ORDER BY id",
            (session_id,),
        ).fetchall()
    fields = ("id", "role", "content", "created_at")
    return {"session_id": session_id, "messages": [dict(zip(fields, row)) for row in rows]}


@app.delete("/api/chat/sessions/{session_id}")
def delete_chat_session(session_id: str) -> dict[str, str]:
    with db() as connection:
        exists = connection.execute("SELECT 1 FROM chat_sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not exists:
            raise HTTPException(404, "Sohbet oturumu bulunamadi.")
        connection.execute("DELETE FROM chat_messages WHERE session_id = ?", (session_id,))
        connection.execute("DELETE FROM chat_sessions WHERE session_id = ?", (session_id,))
    return {"status": "deleted", "session_id": session_id}


@app.post("/api/chat")
def chat(request: ChatRequest) -> dict[str, str]:
    message = request.message.strip()
    if not message:
        raise HTTPException(400, "Mesaj bos olamaz.")
    session_id = request.session_id
    with db() as connection:
        if session_id:
            exists = connection.execute("SELECT 1 FROM chat_sessions WHERE session_id = ?", (session_id,)).fetchone()
            if not exists:
                raise HTTPException(404, "Sohbet oturumu bulunamadi.")
        else:
            session_id = uuid.uuid4().hex
            connection.execute("INSERT INTO chat_sessions(session_id) VALUES (?)", (session_id,))
        history = connection.execute(
            "SELECT id, role, content FROM chat_messages WHERE session_id = ? ORDER BY id DESC LIMIT 20",
            (session_id,),
        ).fetchall()
        recent_floor = min((row[0] for row in history), default=0)
        history_terms = list(dict.fromkeys(term.lower() for term in re.findall(r"[\w-]{4,}", message)))[:8]
        relevant_history = []
        if history_terms:
            match_clause = " OR ".join("content LIKE ?" for _ in history_terms)
            relevant_history = connection.execute(
                f"SELECT id, role, content FROM chat_messages WHERE session_id = ? AND id < ? AND ({match_clause}) ORDER BY id DESC LIMIT 8",
                [session_id, recent_floor, *(f"%{term}%" for term in history_terms)],
            ).fetchall()
        connection.execute("INSERT INTO chat_messages(session_id, role, content) VALUES (?, 'user', ?)", (session_id, message))
        connection.execute(
            "UPDATE chat_sessions SET title = CASE WHEN title = 'Yeni sohbet' THEN ? ELSE title END, updated_at = CURRENT_TIMESTAMP WHERE session_id = ?",
            (message[:80], session_id),
        )

    context_by_id = {row_id: {"role": role, "content": content} for row_id, role, content in [*relevant_history, *history]}
    prior_messages = [context_by_id[row_id] for row_id in sorted(context_by_id)]

    def finish(content: str, intent: str, **extra: str) -> dict[str, str]:
        with db() as connection:
            connection.execute("INSERT INTO chat_messages(session_id, role, content) VALUES (?, 'assistant', ?)", (session_id, content))
            connection.execute("UPDATE chat_sessions SET updated_at = CURRENT_TIMESTAMP WHERE session_id = ?", (session_id,))
        prune_chat_history(session_id)
        return {"content": content, "intent": intent, "session_id": session_id, **extra}

    if re.fullmatch(r"(?:merhaba|merhabalar|selam|selamlar|hey|hi|hello)[!. ]*", message, re.IGNORECASE):
        return finish("Merhaba! Nasıl yardımcı olabilirim?", "greeting")
    if any(marker in message.lower() for marker in ("nereye kayıt", "nereye kayit", "hafıza nerede", "hafiza nerede")):
        return finish(
            (
                f"Kalıcı notlar: {MEMORY_DB}\n"
                f"İşlem günlüğü: {MEMORY_DB} içindeki operation_journal tablosu\n"
                f"Dosya yedekleri: {AGENT_TOOLS.backup_root}\n"
                f"Taşımak için {MEMORY_DB.parent} klasörünü ve dosya yedekleri için gerekirse {AGENT_TOOLS.backup_root} klasörünü kopyalayabilirsin."
            ),
            "memory_location",
        )
    lower_message = message.lower()
    asks_to_create = bool(re.search(
        r"(?<!\w)(?:oluştur(?:mak|abilir)?|olustur(?:mak|abilir)?|kur(?:mak)?)(?!\w)",
        lower_message,
    ))
    names_project = any(word in lower_message for word in ("proje", "oyun", "klasör", "klasor", "dosya", "uygulama", "site"))
    target_match = re.search(r"[A-Za-z]:\\(?:[^\s\\/:*?\"<>|]+\\)*[^\s\\/:*?\"<>|]+", message)
    if asks_to_create and names_project:
        target_path = target_match.group(0).rstrip(".,;:!?)]}") if target_match else ""
        target_text = f" Hedef klasör: {target_path}." if target_path else " Hedef klasörü formda belirtebilirsin."
        return finish(
            "Evet, bunu oluşturabilirim." + target_text + " İsteğini Offline Proje Teslimi formuna aktardım. "
            "Planı kontrol et; dosyaları yalnızca açık onayından sonra yazar, yedekler ve test ederim.",
            "action_request",
            project_request=message,
            project_path=target_path,
        )
    if any(marker in message.lower() for marker in (
        "neler yapabilirsin",
        "neler yapabilir",
        "ne yapabilirsin",
        "yeteneklerin",
        "what can you do",
        "what are your capabilities",
        "what can you help with",
        "what can you do with deeppanda",
        "what can you do with deep panda",
    )):
        return finish(
            (
                "Ben DeepPanda icindeki yerel LocalQwenAgent'im.\n\n"
                "Yapabildiklerim:\n"
                "- WORKSPACE_ROOT=DeepPanda/ altindaki kardes proje alanlarindan ilgili kaynak ve belgeleri sorguya gore okuyabilirim. DeepPanda-App, WORKSPACE_EXCLUDED_DIRS nedeniyle henuz kapsama dahil degil.\n"
                "- Onayindan sonra dosya olusturabilir veya degistirebilirim; mevcut dosyalari once yedeklerim.\n"
                "- Python, test, compile ve izinli yerel komutlari calistirabilirim; sonucu operation_journal'a kaydederim.\n"
                "- Notlari, arastirma sonuclarini ve islemleri memory.db icindeki kalici hafizaya kaydedebilirim.\n"
                "- PDF, metin, gorsel, ses/video ve public web/GitHub kaynaklarini analiz edebilirim.\n"
                "- Proje plani, kod, test ve dosya degisikligi uretebilirim.\n\n"
                "- Yeni proje/oyun klasoru olusturabilirim: Offline proje tesliminde WORKSPACE_ROOT icinde hedef sec; once plan/diff sunulur, acik onaydan sonra dosyalar backup ve test akisiyla yazilir.\n"
                "- GitHub topic'lerinden public repository listesi cikarabilir, onayli shallow clone yapabilir, README/kod kaynaklarini Qwen ile ogrenip memory.db'ye kaydedebilirim.\n"
                "- Anlik durum paneliyle sohbet, arastirma, dosya, GitHub, media, test ve kurulum islemlerinin durumunu gosterebilirim.\n"
                "- Self-audit, test sonucu, provenance artifact, backup ve rollback akislariyla kontrollu duzeltme yapabilirim.\n\n"
                "Sinirlarim: Okuma ve onayli yazma ALLOW_EXTERNAL_PATHS politikasina tabidir; Windows, Program Files ve ProgramData korumali klasorlerdir. "
                "Dosya yazma, silme, paket kurma ve komut calistirma acik onay ister. Public web/GitHub icin internet gerekir; private/login sayfalarda sifre, MFA, cookie veya token istemem. "
                "Gizli ic dusunme taslagimi gostermem."
            ),
            "capabilities",
        )
    decision = decide(message)
    context_parts = []
    project_map_context = local_project_map_context(message)
    if project_map_context:
        context_parts.append(project_map_context)
    elif request.memory:
        context_parts.append("Retrieved kalici hafiza:\n" + (retrieved_memory_context(message) or "Yok"))
        context_parts.append("Onceki operasyonlar:\n" + (operation_context() or "Yok"))
    workspace_markers = (
        "workspace", "proje", "projede", "dosya", "kod", "hata", "uygulama",
        "test", "localqwenagent", "deeppanda", "script", "klasor",
    )
    excluded_project_requested = any(path.name.casefold() in message.casefold() for path in WORKSPACE_EXCLUDED_PATHS)
    if not project_map_context and not excluded_project_requested and (
        decision.intent == "action_request" or any(marker in message.lower() for marker in workspace_markers)
    ):
        context_parts.append("Workspace baglami:\n" + (workspace_context(message) or "Yok"))
    if project_map_context:
        system = (
            "Sen kullanicinin yerel DeepPanda workspace envanter asistanisin. Kullanici hangi dilde yazdiysa ayni dilde yanit ver. "
            "Asagidaki CANONICAL LOCAL PROJECT MAP bu workspace hakkinda dogrulanmis birincil kaynaktir; ayni isimli public projelerle karistirma, "
            "genel bilgiyle celistirme ve yerel baglami goremedigini soyleme. Sorulan proje alanlarini haritadaki rollerine gore siniflandir; "
            "Envanter sorusunda haritadaki tum proje alanlarini tek tek listele, listeden oge atlama ve durum/tamamlanma tahmini uretme. "
            "haritada olmayan durum/entegrasyon/aktiflik iddialarini uydurma. DeepPanda-App WORKSPACE_EXCLUDED_DIRS nedeniyle simdilik baglam ve dosya araclarina kapali; "
            "envanter cevabinin sonunda 'DeepPanda-App su an Qwen kapsam disinda; entegrasyonu sonraki asamaya birakildi.' diye net belirt. "
            "Dosya degisikligi veya komut istenirse mevcut acik onay kurallari gecerlidir.\n\n"
            + project_map_context
        )
    else:
        system = system_prompt(decision, "\n\n".join(context_parts))
    if any(marker in message.lower() for marker in ("ayrıntı", "ayrinti", "detay", "adım adım", "adim adim", "nedenini")):
        system += "\nKullanici ayrinti istedi: sonucu, gerekceleri, varsayimlari ve uygulanabilir adimlari ayrintili anlat; gizli ic dusunme taslagini yazma."
    conversation = [{"role": "system", "content": system}, *prior_messages, {"role": "user", "content": message}]
    try:
        answer = call_ollama(conversation, num_predict=1200 if project_map_context else 768)
    except HTTPException as exc:
        finish(f"Yerel model yanıt üretemedi: {exc.detail}", "model_error")
        raise
    wants_learning = any(
        marker in message.lower()
        for marker in ("öğren", "ogren", "hafızaya", "hafizaya", "kalıcı", "kalici", "kaydet")
    )
    result = finish(answer, decision.intent)
    if wants_learning:
        learning_note = f"Kullanici tarafindan kaydedilen ogrenme notu\nSoru: {message}\nYanıt: {answer}"
        if not request.approve_memory:
            result["memory_pending"] = learning_note
            result["memory"] = "Öğrenme notu hazır; kalıcı hafızaya kaydetmek için onay gerekli."
        else:
            save_typed_memory(learning_note, "research", str(WORKSPACE_ROOT), "chat")
            result["memory"] = "Öğrenilen bilgi kalıcı hafızaya kaydedildi."
    return result


@app.post("/api/research")
def research(request: ResearchRequest) -> dict[str, str]:
    question = request.question.strip()
    urls = [url.strip() for url in request.urls if url.strip()][:5]
    if not question or not urls:
        raise HTTPException(400, "Soru ve en az bir URL gerekli.")
    sources = []
    errors = []
    for url in urls:
        try:
            text = fetch_web_page(url)
            sources.append(f"KAYNAK: {url}\n{text}")
        except Exception as exc:
            errors.append(f"{url}: {exc}")
    if not sources:
        raise HTTPException(502, "Web kaynaklari okunamadi: " + "; ".join(errors))
    prompt = (
        "Asagidaki web kaynaklarini kullanarak soruyu yanitla. Kaynaklarda olmayan bilgiyi uydurma. "
        "Yanitta hangi URL'den yararlandigini belirt.\n\n"
        f"SORU: {question}\n\n" + "\n\n".join(sources)
    )
    answer = call_ollama([{"role": "user", "content": prompt}])
    save_memory(f"Web arastirma notu\nSoru: {question}\nKaynaklar: {', '.join(urls)}\n{answer}")
    if errors:
        answer += "\n\nOkunamayan kaynaklar:\n" + "\n".join(errors)
    return {"content": answer}


@app.post("/api/research/start")
def research_start(request: ResearchRequest) -> dict[str, str]:
    question = request.question.strip()
    urls = [url.strip() for url in request.urls if url.strip()]
    if not question or not urls:
        raise HTTPException(400, "Soru ve en az bir URL gerekli.")
    return {"job_id": start_research_job(question, urls)}


@app.get("/api/research/jobs/{job_id}")
def research_job(job_id: str) -> dict[str, Any]:
    with RESEARCH_LOCK:
        job = RESEARCH_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Araştırma işi bulunamadı.")
        return {**job, "events": list(job.get("events", []))}


def list_jobs(limit: int = 100) -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT job_id, kind, question, urls, status, artifact_dir, error, created_at, updated_at FROM job_records ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    jobs = []
    for row in rows:
        job = dict(zip(("job_id", "kind", "question", "urls", "status", "artifact_dir", "error", "created_at", "updated_at"), row))
        job.setdefault("progress", 0)
        job.setdefault("events", [])
        jobs.append(job)

    with MEDIA_JOB_LOCK:
        for job_id, job in MEDIA_JOBS.items():
            candidate = next((item for item in jobs if item.get("job_id") == job_id), None)
            if candidate is not None:
                candidate["kind"] = "media"
                candidate["question"] = str(job.get("prompt") or candidate.get("question") or "video_generation")
                candidate["status"] = str(job.get("status") or candidate.get("status") or "queued")
                candidate["progress"] = int(job.get("progress", candidate.get("progress", 0)))
                candidate["events"] = list(job.get("events", candidate.get("events", [])))
                candidate["urls"] = candidate.get("urls") if isinstance(candidate.get("urls"), list) else []
                candidate["artifact_dir"] = str(job.get("artifact_dir") or candidate.get("artifact_dir") or "")
                candidate["error"] = str(job.get("error") or candidate.get("error") or "")
                continue
            jobs.append({
                "job_id": job_id,
                "kind": "media",
                "question": str(job.get("prompt") or job.get("question") or "video_generation"),
                "urls": [],
                "status": str(job.get("status") or "queued"),
                "progress": int(job.get("progress", 0)),
                "events": list(job.get("events", [])),
                "artifact_dir": str(job.get("artifact_dir") or ""),
                "error": str(job.get("error") or ""),
                "created_at": str(job.get("created_at") or datetime.now(UTC).isoformat(timespec="seconds")),
                "updated_at": str(job.get("updated_at") or datetime.now(UTC).isoformat(timespec="seconds")),
            })
    jobs.sort(key=lambda item: item.get("updated_at") or item.get("created_at") or "", reverse=True)
    return {"jobs": jobs[:limit]}


@app.get("/api/jobs")
def jobs_index() -> dict[str, Any]:
    return list_jobs()


@app.get("/api/research/jobs")
def research_jobs() -> dict[str, Any]:
    return list_jobs()


@app.post("/api/research/jobs/{job_id}/cancel")
def cancel_research_job(job_id: str) -> dict[str, str]:
    with RESEARCH_LOCK:
        job = RESEARCH_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Araştırma işi bulunamadı.")
        if job.get("status") not in {"running"}:
            return {"status": str(job.get("status"))}
        job["cancel_requested"] = True
        job.setdefault("events", []).append({"time": time.time(), "message": "İptal istendi."})
    with db() as connection:
        connection.execute("UPDATE job_records SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("cancel_requested", job_id))
    return {"status": "cancel_requested"}


@app.post("/api/research/jobs/{job_id}/retry")
def retry_research_job(job_id: str) -> dict[str, str]:
    with RESEARCH_LOCK:
        job = RESEARCH_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Araştırma işi bulunamadı.")
        if job.get("status") not in {"failed", "cancelled"}:
            raise HTTPException(409, "Yalnızca başarısız veya iptal edilmiş işler tekrarlanabilir.")
        question = str(job.get("question", ""))
        urls = list(job.get("urls", []))
    return {"job_id": start_research_job(question, urls)}


@app.post("/api/browser/snapshot")
async def browser_snapshot(request: BrowserRequest) -> dict[str, str]:
    """Render a public page with Chromium without executing local actions."""
    parsed = urlparse(request.url.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(400, "Yalnizca public http/https URL kullanilabilir.")
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(request.url, wait_until="domcontentloaded", timeout=30_000)
            title = await page.title()
            text = (await page.locator("body").inner_text())[:40_000]
            await browser.close()
        return {"title": title, "content": text}
    except ImportError as exc:
        raise HTTPException(503, "Playwright kurulu degil.") from exc
    except Exception as exc:
        raise HTTPException(502, f"Browser sayfasi okunamadi: {exc}") from exc


@app.post("/api/browser/action")
async def browser_action(request: BrowserActionRequest) -> dict[str, Any]:
    """Perform one approved, non-scripted action in a fresh public browser session."""
    parsed = urlparse(request.url.strip())
    allowed_actions = {"goto", "click", "fill", "select"}
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(400, "Yalnızca public http/https URL kullanılabilir.")
    if request.action not in allowed_actions:
        raise HTTPException(400, f"action şunlardan biri olmalı: {', '.join(sorted(allowed_actions))}.")
    if request.action != "goto" and not request.approved:
        return {"status": "approval_required", "action": request.action, "selector": request.selector}
    if request.action in {"click", "fill", "select"} and not request.selector:
        raise HTTPException(400, "Bu action için selector gerekli.")
    if request.action in {"fill", "select"} and len(request.value) > 2_000:
        raise HTTPException(400, "Form değeri çok uzun.")
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(request.url, wait_until="domcontentloaded", timeout=30_000)
            if request.action == "click":
                await page.locator(request.selector).first.click(timeout=10_000)
                await page.wait_for_load_state("domcontentloaded", timeout=10_000)
            elif request.action == "fill":
                await page.locator(request.selector).first.fill(request.value)
            elif request.action == "select":
                await page.locator(request.selector).first.select_option(request.value)
            title = await page.title()
            content = (await page.locator("body").inner_text())[:40_000]
            result_url = page.url
            await browser.close()
        journal_operation("browser_action", f"Onaylı browser action: {request.action}", json.dumps({"url": result_url, "selector": request.selector}, ensure_ascii=False))
        return {"status": "completed", "action": request.action, "url": result_url, "title": title, "content": content}
    except ImportError as exc:
        raise HTTPException(503, "Playwright kurulu değil.") from exc
    except Exception as exc:
        raise HTTPException(502, f"Browser action başarısız: {exc}") from exc


async def _close_browser_session(session_id: str, session: dict[str, Any] | None = None) -> None:
    session = session if session is not None else BROWSER_SESSIONS.get(session_id)
    if not session:
        return
    try:
        context = session.get("context")
        if context is not None and hasattr(context, "close"):
            await context.close()
    except Exception:
        LOGGER.debug("Browser context cleanup failed for session %s", session_id, exc_info=True)
    try:
        playwright = session.get("playwright")
        if playwright is not None and hasattr(playwright, "stop"):
            await playwright.stop()
    except Exception:
        LOGGER.debug("Playwright cleanup failed for session %s", session_id, exc_info=True)
    with BROWSER_SESSION_LOCK:
        BROWSER_SESSIONS.pop(session_id, None)


async def _prune_expired_browser_sessions() -> None:
    now = time.time()
    expired: list[tuple[str, dict[str, Any]]] = []
    with BROWSER_SESSION_LOCK:
        for session_id, session in list(BROWSER_SESSIONS.items()):
            last_seen = float(session.get("last_seen", session.get("created_at", now)))
            if now - last_seen > BROWSER_SESSION_TIMEOUT_SECONDS:
                expired.append((session_id, session))
                BROWSER_SESSIONS.pop(session_id, None)
    for session_id, session in expired:
        await _close_browser_session(session_id, session)


@app.post("/api/browser/session/start")
async def browser_session_start(request: BrowserSessionStartRequest) -> dict[str, Any]:
    """Open a user-approved persistent browser profile without exposing cookies."""
    if not request.approved:
        return {"status": "approval_required", "profile_dir": request.profile_dir or "user-profile-browser"}
    await _prune_expired_browser_sessions()
    try:
        from playwright.async_api import async_playwright
        profile = Path(request.profile_dir or (Path.home() / ".localqwen-browser-profile")).expanduser().resolve()
        user_root = Path(os.environ.get("USERPROFILE", str(Path.home()))).resolve()
        if user_root not in profile.parents and WORKSPACE_ROOT not in profile.parents:
            raise HTTPException(400, "Browser profili kullanici profili veya workspace altinda olmali.")
        playwright = await async_playwright().start()
        context = await playwright.chromium.launch_persistent_context(str(profile), headless=False)
        page = context.pages[0] if context.pages else await context.new_page()
        session_id = uuid.uuid4().hex
        created_at = time.time()
        with BROWSER_SESSION_LOCK:
            BROWSER_SESSIONS[session_id] = {"playwright": playwright, "context": context, "page": page, "profile": str(profile), "created_at": created_at, "last_seen": created_at}
        return {"status": "started", "session_id": session_id, "profile": str(profile), "message": "Tarayici acildi; girisi kullanici kendi penceresinde yapabilir."}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(503, f"Kalici browser oturumu baslatilamadi: {exc}") from exc


@app.post("/api/browser/session/action")
async def browser_session_action(request: BrowserSessionActionRequest) -> dict[str, Any]:
    with BROWSER_SESSION_LOCK:
        session = BROWSER_SESSIONS.get(request.session_id)
    if not session:
        await _prune_expired_browser_sessions()
        with BROWSER_SESSION_LOCK:
            session = BROWSER_SESSIONS.get(request.session_id)
        if not session:
            raise HTTPException(404, "Browser oturumu bulunamadi.")
    last_seen = float(session.get("last_seen", session.get("created_at", time.time())))
    if time.time() - last_seen > BROWSER_SESSION_TIMEOUT_SECONDS:
        await _close_browser_session(request.session_id, session)
        raise HTTPException(408, "Browser oturumu zaman asimina ugradi; yeni oturum baslatilmalidir.")
    if request.action in {"click", "fill", "select"} and not request.approved:
        return {"status": "approval_required", "action": request.action, "selector": request.selector}
    if request.action not in {"inspect", "goto", "click", "fill", "select"}:
        raise HTTPException(400, "Gecersiz browser session action.")
    try:
        page = session["page"]
        if request.url:
            parsed = urlparse(request.url)
            if parsed.scheme not in {"http", "https"}:
                raise HTTPException(400, "Yalnizca http/https URL kullanilabilir.")
            await page.goto(request.url, wait_until="domcontentloaded", timeout=30_000)
        if request.action == "click":
            await page.locator(request.selector).first.click(timeout=10_000)
        elif request.action == "fill":
            await page.locator(request.selector).first.fill(request.value)
        elif request.action == "select":
            await page.locator(request.selector).first.select_option(request.value)
        with BROWSER_SESSION_LOCK:
            if request.session_id in BROWSER_SESSIONS:
                BROWSER_SESSIONS[request.session_id]["last_seen"] = time.time()
        return {"status": "completed", "url": page.url, "title": await page.title(), "content": (await page.locator("body").inner_text())[:40_000]}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(502, f"Kalici browser action basarisiz: {exc}") from exc


@app.post("/api/browser/session/close")
async def browser_session_close(request: BrowserSessionActionRequest) -> dict[str, str]:
    await _close_browser_session(request.session_id)
    return {"status": "closed"}


@app.post("/api/github/research")
def github_research(request: GitHubResearchRequest) -> dict[str, str]:
    question = request.question.strip()
    repositories = [item.strip() for item in request.repositories if item.strip()][:3]
    if not question or not repositories:
        raise HTTPException(400, "Soru ve en az bir GitHub repository URL'si gerekli.")

    sources: list[str] = []
    errors: list[str] = []
    for repository in repositories:
        try:
            for source_url in github_sources(repository):
                try:
                    text = fetch_web_page(source_url)
                    if text.strip():
                        sources.append(f"KAYNAK: {source_url}\n{text}")
                except Exception as exc:
                    errors.append(f"{source_url}: {exc}")
        except Exception as exc:
            errors.append(f"{repository}: {exc}")
    if not sources:
        raise HTTPException(502, "GitHub kaynaklari okunamadi: " + "; ".join(errors))

    prompt = (
        "GitHub kaynaklarini incele ve soruya cevap ver. Ardindan 'OGRENME NOTU' basligi altinda "
        "projenin mimarisini, kurulumunu, onemli kurallarini ve gelecekte hatirlanmasi gerekenleri "
        "kisa maddelerle yaz. Kaynaklarda olmayan detaylari uydurma. Kaynak URL'lerini belirt.\n\n"
        f"SORU: {question}\n\n" + "\n\n".join(sources)
    )
    answer = call_ollama([{"role": "user", "content": prompt}])
    note = f"GitHub ogrenme notu\nSoru: {question}\nKaynaklar: {', '.join(repositories)}\n{answer}"
    save_memory(note)
    if errors:
        answer += "\n\nOkunamayan kaynaklar:\n" + "\n".join(errors)
    return {"content": answer, "memory": "GitHub ogrenme notu kalici hafizaya kaydedildi."}


@app.post("/api/github/topic/research")
def github_topic_research(request: GitHubTopicResearchRequest) -> dict[str, Any]:
    try:
        repositories = github_topic_repositories(request.topic_url, request.limit)
    except (HTTPError, URLError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc
    if not repositories:
        raise HTTPException(404, "Topic icinde public repository bulunamadi.")
    if request.download and not request.approved:
        return {"status": "approval_required", "repositories": repositories, "destination": request.destination}
    learned: list[dict[str, str]] = []
    for repository in repositories:
        local_path = ""
        if request.download:
            repo_name = repository.rstrip("/").split("/")[-1]
            local_path = str(AGENT_TOOLS.safe_path(str(Path(request.destination) / repo_name)))
            if Path(local_path).exists():
                raise HTTPException(409, f"Hedef zaten var: {local_path}")
            result = AGENT_TOOLS.run_approved(["git", "clone", "--depth", "1", repository, local_path], approved=True)
            if not result.get("passed"):
                raise HTTPException(502, f"Repo indirilemedi: {repository}\n{result.get('stderr', '')}")
        try:
            answer = learn_repository(repository, request.topic_url, request.question, local_path)
        except Exception as exc:
            raise HTTPException(502, f"Repo ogrenilemedi: {repository}: {exc}") from exc
        learned.append({"repository": repository, "local_path": local_path, "summary": answer[:2000]})
    return {"status": "completed", "topic": request.topic_url, "repositories": learned, "memory": "Kaynaklar kalici hafizaya kaydedildi."}


@app.get("/api/github/repositories")
def github_repositories() -> dict[str, Any]:
    with db() as connection:
        rows = connection.execute(
            "SELECT repository, topic, local_path, commit_sha, learned, created_at, updated_at FROM library_repositories ORDER BY updated_at DESC"
        ).fetchall()
    fields = ("repository", "topic", "local_path", "commit_sha", "learned", "created_at", "updated_at")
    return {"repositories": [dict(zip(fields, row)) for row in rows]}


@app.post("/api/tools/run")
def run_tool(request: ToolRequest) -> dict[str, object]:
    """Run only an approved, workspace-scoped tool command."""
    try:
        return AGENT_TOOLS.run_approved(request.command, request.approved)
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(408, "Arac islemi zaman asimina ugradi.") from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/tools/shortcut")
def manage_shortcut(request: ShortcutRequest) -> dict[str, Any]:
    """Create, update, or run an approved user-profile Windows shortcut."""
    if not request.approved:
        return {"status": "approval_required", "action": request.action, "path": request.path}
    if sys.platform != "win32":
        raise HTTPException(400, "Windows .lnk islemleri yalnizca Windows'ta desteklenir.")
    if request.action not in {"create", "run"}:
        raise HTTPException(400, "action create veya run olmali.")
    shortcut_path = Path(request.path).expanduser().resolve()
    user_root = Path(os.environ.get("USERPROFILE", str(Path.home()))).resolve()
    if shortcut_path.suffix.lower() != ".lnk" or (user_root not in shortcut_path.parents and WORKSPACE_ROOT not in shortcut_path.parents):
        raise HTTPException(400, "Kisayol yolu kullanici profili veya workspace altinda bir .lnk olmali.")
    if AGENT_TOOLS._is_protected_path(shortcut_path):
        raise HTTPException(403, "Korunan Windows klasorlerinde kisayol islemi engellendi.")
    if request.action == "create" and not request.target.strip():
        raise HTTPException(400, "Kisayol hedefi gerekli.")
    payload = json.dumps({
        "action": request.action,
        "path": str(shortcut_path),
        "target": request.target,
        "arguments": request.arguments,
        "working_directory": request.working_directory,
        "description": request.description,
    }, ensure_ascii=False).encode("utf-8")
    encoded = base64.b64encode(payload).decode("ascii")
    script = (
        "$json=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "'))|ConvertFrom-Json; "
        "$shell=New-Object -ComObject WScript.Shell; "
        "if($json.action -eq 'create'){ $shortcut=$shell.CreateShortcut($json.path); "
        "$shortcut.TargetPath=$json.target; $shortcut.Arguments=$json.arguments; "
        "$shortcut.WorkingDirectory=$json.working_directory; $shortcut.Description=$json.description; "
        "$shortcut.Save(); Write-Output 'created' } else { Start-Process -FilePath $json.path; Write-Output 'started' }"
    )
    try:
        result = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(500, f"Kisayol islemi basarisiz: {exc}") from exc
    if result.returncode:
        raise HTTPException(422, f"Kisayol islemi basarisiz: {result.stderr[-2000:]}")
    journal_operation("shortcut", "Kullanici kisayol islemini acikca onayladi.", json.dumps({"action": request.action, "path": str(shortcut_path)}, ensure_ascii=False))
    return {"status": request.action + "d", "path": str(shortcut_path), "output": result.stdout.strip()}


@app.get("/api/tools/file")
def read_tool_file(path: str) -> dict[str, str]:
    if AGENT_DEV_MODE != "workspace":
        raise HTTPException(403, "Workspace gelistirme modu kapali.")
    try:
        target = AGENT_TOOLS.safe_path(path)
        if not target.is_file() or target.stat().st_size > 2_000_000:
            raise ValueError("Dosya yok veya boyutu cok buyuk.")
        return {"path": str(target), "content": target.read_text(encoding="utf-8", errors="replace")}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/tools/file")
def write_tool_file(request: FileWriteRequest) -> dict[str, str]:
    if AGENT_DEV_MODE != "workspace":
        raise HTTPException(403, "Workspace gelistirme modu kapali.")
    try:
        return AGENT_TOOLS.write_file(request.path, request.content)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/media/analyze")
async def analyze_media(file: UploadFile = File(...), transcribe: bool = Form(True)) -> dict[str, Any]:
    """Extract bounded media evidence; transcription is optional and local."""
    data = read_upload(file)
    suffix = Path(file.filename or "media").suffix.lower()
    if suffix not in {".mp4", ".mov", ".mkv", ".avi", ".wav", ".mp3", ".m4a", ".webm"}:
        raise HTTPException(400, "Video veya ses dosyasi gerekli.")
    media_dir = ROOT / ".media-work" / uuid.uuid4().hex
    media_dir.mkdir(parents=True, exist_ok=True)
    source = media_dir / f"input{suffix}"
    source.write_bytes(data)
    asset_id = register_asset(source, "video" if suffix in {".mp4", ".mov", ".mkv", ".avi", ".webm"} else "audio", file.content_type or "", source="upload", metadata={"filename": file.filename or "media"})
    audio = media_dir / "audio.wav"
    frames = media_dir / "frame-%03d.jpg"
    result: dict[str, Any] = {"filename": file.filename, "frames": [], "transcript": ""}
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(source), "-vn", "-ac", "1", "-ar", "16000", str(audio)],
            check=True, capture_output=True, text=True, timeout=300,
        )
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(source), "-vf", "fps=1/10", "-frames:v", "12", "-c:v", "mjpeg", "-strict", "-2", str(frames)],
            check=True, capture_output=True, text=True, timeout=300,
        )
        frame_paths = sorted(media_dir.glob("frame-*.jpg"))
        if not frame_paths:
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(source), "-frames:v", "1", "-c:v", "mjpeg", "-strict", "-2", str(frames)],
                check=True, capture_output=True, text=True, timeout=300,
            )
            frame_paths = sorted(media_dir.glob("frame-*.jpg"))
        result["frames"] = [
            {"path": str(path), "timestamp_seconds": index * 10}
            for index, path in enumerate(frame_paths)
        ]
        result["vision_observations"] = []
        if transcribe:
            try:
                from faster_whisper import WhisperModel
                model = WhisperModel("small", device="cpu", compute_type="int8")
                segments, _info = model.transcribe(str(audio))
                result["transcript"] = " ".join(segment.text.strip() for segment in segments)
            except ImportError:
                result["transcript"] = "faster-whisper kurulu degil; transkripsiyon atlandi."
        for frame in frame_paths[:3]:
            try:
                observation = call_ollama_vision(
                    frame.read_bytes(),
                    "Bu video karesini kanita dayali ve kisa analiz et. Gorunen nesneleri, metni, ekran durumunu ve belirsizlikleri belirt.",
                    ".jpg",
                )
                result["vision_observations"].append({"timestamp_seconds": frame_paths.index(frame) * 10, "content": observation})
            except HTTPException as exc:
                result["vision_observations"].append({"timestamp_seconds": frame_paths.index(frame) * 10, "error": str(exc.detail)})
        result["report"] = {
            "filename": file.filename,
            "transcript": result["transcript"],
            "frame_count": len(frame_paths),
            "vision_observations": result["vision_observations"],
        }
        save_memory(
            f"Media analiz notu: {file.filename}\nKare sayisi: {len(result['frames'])}\n"
            f"Transkript: {result['transcript'][:12000]}\nRapor: {json.dumps(result['report'], ensure_ascii=False)[:20000]}"
        )
        result["asset_id"] = asset_id
        return result
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(422, f"Media analizi basarisiz: {exc}") from exc


@app.post("/api/media/image")
def generate_image(request: ImageGenerateRequest) -> FileResponse:
    """Generate one local image from the configured diffusion model."""
    global IMAGE_PIPELINE
    prompt = request.prompt.strip()
    if not prompt or len(prompt) > 2_000:
        raise HTTPException(400, "Gorsel promptu 1-2000 karakter olmali.")
    if not IMAGE_MODEL_PATH.is_dir():
        raise HTTPException(503, f"Gorsel modeli bulunamadi: {IMAGE_MODEL_PATH}")
    steps = max(1, min(request.steps, 20))
    width = max(128, min(request.width, 768)) // 8 * 8
    height = max(128, min(request.height, 768)) // 8 * 8
    try:
        import torch
        from diffusers import StableDiffusionPipeline

        device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float16 if device == "cuda" else torch.float32
        with IMAGE_PIPELINE_LOCK:
            if IMAGE_PIPELINE is None:
                IMAGE_PIPELINE = StableDiffusionPipeline.from_pretrained(
                    str(IMAGE_MODEL_PATH), local_files_only=True, dtype=dtype, safety_checker=None,
                ).to(device)
            image = IMAGE_PIPELINE(
                prompt, num_inference_steps=steps, guidance_scale=0.0,
                width=width, height=height,
            ).images[0]
    except Exception as exc:
        raise HTTPException(503, f"Gorsel uretimi basarisiz: {exc}") from exc
    output_dir = ROOT / ".asset-store" / "generated"
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"localqwen_image_{uuid.uuid4().hex}.png"
    image.save(output, format="PNG")
    register_asset(output, "image", "image/png", source="generated", metadata={"prompt": prompt, "steps": steps, "width": width, "height": height})
    return FileResponse(output, media_type="image/png", filename="localqwen_generated.png")


def _encode_video_1080p(source: Path, output: Path, duration_seconds: float) -> None:
    filter_graph = (
        f"[0:v]tpad=stop_mode=clone:stop_duration={duration_seconds},"
        "minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:vsbmc=1,split=2[background][foreground];"
        "[background]scale=1920:1080:force_original_aspect_ratio=increase:flags=lanczos,"
        "crop=1920:1080,boxblur=20:10,eq=brightness=-0.18[blurred];"
        "[foreground]scale=1080:1080:force_original_aspect_ratio=decrease:flags=lanczos[subject];"
        "[blurred][subject]overlay=(W-w)/2:(H-h)/2,format=yuv420p[video]"
    )
    subprocess.run(
        [
            "ffmpeg", "-y", "-i", str(source), "-filter_complex", filter_graph,
            "-map", "[video]", "-an", "-c:v", "libx264", "-preset", "fast",
            "-crf", "20", "-r", "24", "-t", str(duration_seconds),
            "-movflags", "+faststart", str(output),
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=600,
    )


@app.post("/api/media/video")
def generate_video(request: VideoGenerateRequest) -> FileResponse:
    """Create a real local video when available, with an image-motion fallback."""
    global IMAGE_PIPELINE
    prompt = request.prompt.strip()
    if not prompt or len(prompt) > 2_000:
        raise HTTPException(400, "Video promptu 1-2000 karakter olmali.")
    duration = max(1, min(request.duration_seconds, 10))
    if not IMAGE_MODEL_PATH.is_dir():
        raise HTTPException(503, f"Gorsel modeli bulunamadi: {IMAGE_MODEL_PATH}")
    backend = os.getenv("VIDEO_BACKEND", "auto").strip().lower()
    if backend in {"auto", "real"} and VIDEO_MODEL_PATH.is_dir():
        try:
            import imageio.v2 as imageio
            import torch
            from diffusers import TextToVideoSDPipeline

            global VIDEO_PIPELINE
            device = "cuda" if torch.cuda.is_available() else "cpu"
            dtype = torch.float16 if device == "cuda" else torch.float32
            with VIDEO_PIPELINE_LOCK:
                if VIDEO_PIPELINE is None:
                    VIDEO_PIPELINE = TextToVideoSDPipeline.from_pretrained(str(VIDEO_MODEL_PATH), local_files_only=True, dtype=dtype)
                    if device == "cuda":
                        VIDEO_PIPELINE.enable_model_cpu_offload()
                    else:
                        VIDEO_PIPELINE.to(device)
                frame_count = max(8, min(16, round(duration * 8)))
                frames = VIDEO_PIPELINE(
                    prompt,
                    height=512,
                    width=512,
                    num_frames=frame_count,
                    num_inference_steps=20,
                ).frames[0]
            output_dir = ROOT / ".asset-store" / "generated"
            output_dir.mkdir(parents=True, exist_ok=True)
            output = output_dir / f"localqwen_real_video_{uuid.uuid4().hex}.mp4"
            with tempfile.TemporaryDirectory(prefix="localqwen_video_source_") as temp_dir:
                source = Path(temp_dir) / "source.mp4"
                imageio.mimsave(source, frames, fps=8, codec="libx264")
                _encode_video_1080p(source, output, duration)
            register_asset(output, "video", "video/mp4", source="generated", metadata={"prompt": prompt, "duration_seconds": duration, "backend": "text-to-video-ms-1.7b", "source_resolution": "512x512", "output_resolution": "1920x1080", "fps": 24, "inference_steps": 20, "upscaled": True})
            return FileResponse(output, media_type="video/mp4", filename="localqwen_generated.mp4")
        except Exception as exc:
            if backend == "real":
                raise HTTPException(503, f"Gercek video modeli basarisiz: {exc}") from exc
    directory = Path(tempfile.mkdtemp(prefix="localqwen_video_gen_"))
    image_path = directory / "frame.png"
    output = directory / "generated.mp4"
    try:
        import torch
        from diffusers import StableDiffusionPipeline

        device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float16 if device == "cuda" else torch.float32
        with IMAGE_PIPELINE_LOCK:
            if IMAGE_PIPELINE is None:
                IMAGE_PIPELINE = StableDiffusionPipeline.from_pretrained(
                    str(IMAGE_MODEL_PATH), local_files_only=True, dtype=dtype, safety_checker=None,
                ).to(device)
            IMAGE_PIPELINE(prompt, num_inference_steps=4, guidance_scale=0.0, width=256, height=256).images[0].save(image_path)
        frames = round(duration * 24)
        subprocess.run(
            ["ffmpeg", "-y", "-loop", "1", "-i", str(image_path), "-vf", f"zoompan=z='min(zoom+0.0015,1.12)':d={frames}:s=256x256:fps=24", "-t", str(duration), "-c:v", "libx264", "-pix_fmt", "yuv420p", str(output)],
            check=True, capture_output=True, text=True, timeout=300,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        shutil.rmtree(directory, ignore_errors=True)
        raise HTTPException(422, f"Video kodlama basarisiz: {exc}") from exc
    except Exception as exc:
        shutil.rmtree(directory, ignore_errors=True)
        raise HTTPException(503, f"Video uretimi basarisiz: {exc}") from exc
    output_dir = ROOT / ".asset-store" / "generated"
    output_dir.mkdir(parents=True, exist_ok=True)
    persistent_output = output_dir / f"localqwen_video_{uuid.uuid4().hex}.mp4"
    _encode_video_1080p(output, persistent_output, duration)
    register_asset(persistent_output, "video", "video/mp4", source="generated", metadata={"prompt": prompt, "duration_seconds": duration, "backend": "image-motion-ffmpeg", "output_resolution": "1920x1080", "fps": 24, "upscaled": True})
    return FileResponse(persistent_output, media_type="video/mp4", filename="localqwen_generated.mp4", background=BackgroundTask(shutil.rmtree, directory, ignore_errors=True))


@app.post("/api/media/video/start")
def start_video_job(request: VideoGenerateRequest) -> dict[str, str]:
    job_id = uuid.uuid4().hex
    now = datetime.now(UTC).isoformat(timespec="seconds")
    with MEDIA_JOB_LOCK:
        MEDIA_JOBS[job_id] = {
            "status": "queued",
            "progress": 0,
            "events": [{"message": "Video işi kuyruğa alındı."}],
            "cancel_requested": False,
            "prompt": request.prompt,
            "created_at": now,
            "updated_at": now,
        }
    with db() as connection:
        connection.execute(
            "INSERT INTO job_records(job_id, kind, question, urls, status, artifact_dir, error, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (job_id, "media", request.prompt, "[]", "queued", "", "", now, now),
        )

    def worker() -> None:
        with MEDIA_JOB_LOCK:
            MEDIA_JOBS[job_id].update(status="running", progress=10, events=[{"message": "Video modeli hazırlanıyor."}], updated_at=datetime.now(UTC).isoformat(timespec="seconds"))
        with db() as connection:
            connection.execute("UPDATE job_records SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("running", job_id))
        try:
            with MEDIA_JOB_LOCK:
                if MEDIA_JOBS[job_id]["cancel_requested"]:
                    MEDIA_JOBS[job_id].update(status="cancelled", progress=0, updated_at=datetime.now(UTC).isoformat(timespec="seconds"))
                    with db() as connection:
                        connection.execute("UPDATE job_records SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("cancelled", job_id))
                    return
                MEDIA_JOBS[job_id]["progress"] = 25
                MEDIA_JOBS[job_id]["events"].append({"message": "Prompt işleniyor ve kareler üretiliyor."})
                MEDIA_JOBS[job_id]["updated_at"] = datetime.now(UTC).isoformat(timespec="seconds")
            response = generate_video(request)
            path = Path(response.path)
            with db() as connection:
                row = connection.execute("SELECT id FROM assets WHERE path = ? ORDER BY id DESC LIMIT 1", (str(path.resolve()),)).fetchone()
            with MEDIA_JOB_LOCK:
                cancelled = MEDIA_JOBS[job_id]["cancel_requested"]
                MEDIA_JOBS[job_id].update(status="cancelled" if cancelled else "completed", progress=100 if not cancelled else 0, asset_id=int(row[0]) if row and not cancelled else None, events=[{"message": "Video iptal edildi." if cancelled else "Video hazır."}], updated_at=datetime.now(UTC).isoformat(timespec="seconds"))
            with db() as connection:
                connection.execute("UPDATE job_records SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("cancelled" if cancelled else "completed", job_id))
        except Exception as exc:
            with MEDIA_JOB_LOCK:
                MEDIA_JOBS[job_id].update(status="failed", progress=0, error=str(exc), events=[{"message": f"Video hatası: {exc}"}], updated_at=datetime.now(UTC).isoformat(timespec="seconds"))
            with db() as connection:
                connection.execute("UPDATE job_records SET status = ?, error = ?, updated_at = CURRENT_TIMESTAMP WHERE job_id = ?", ("failed", str(exc), job_id))

    threading.Thread(target=worker, daemon=True).start()
    return {"job_id": job_id, "status": "queued"}


@app.get("/api/media/video/jobs/{job_id}")
def video_job_status(job_id: str) -> dict[str, Any]:
    with MEDIA_JOB_LOCK:
        job = MEDIA_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Video işi bulunamadı.")
        return {"job_id": job_id, **job}


@app.post("/api/media/video/jobs/{job_id}/cancel")
def cancel_video_job(job_id: str) -> dict[str, str]:
    with MEDIA_JOB_LOCK:
        job = MEDIA_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Video işi bulunamadı.")
        if job["status"] in {"completed", "failed", "cancelled"}:
            return {"status": str(job["status"])}
        job["cancel_requested"] = True
        job["events"].append({"message": "İptal istendi; mevcut model adımı tamamlanıyor."})
        return {"status": "cancel_requested"}


@app.post("/api/media/image/edit")
async def edit_image(file: UploadFile = File(...), operation: str = Form("grayscale"), value: int = Form(0)) -> FileResponse:
    """Apply a small, deterministic local edit to an uploaded image."""
    data = read_upload(file)
    try:
        image = Image.open(io.BytesIO(data)).convert("RGBA")
        if operation == "grayscale":
            image = image.convert("L").convert("RGBA")
        elif operation == "rotate":
            image = image.rotate(max(-180, min(value, 180)), expand=True)
        elif operation == "resize":
            size = max(64, min(value, 2048))
            ratio = size / max(image.width, image.height)
            image = image.resize((max(1, round(image.width * ratio)), max(1, round(image.height * ratio))))
        else:
            raise HTTPException(400, "operation grayscale, rotate veya resize olmali.")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Gorsel duzenlenemedi: {exc}") from exc
    output = Path(tempfile.gettempdir()) / f"localqwen_edited_{uuid.uuid4().hex}.png"
    image.save(output, format="PNG")
    return FileResponse(output, media_type="image/png", filename="localqwen_edited.png", background=BackgroundTask(output.unlink, missing_ok=True))


@app.post("/api/media/video/edit")
async def edit_video(
    file: UploadFile = File(...),
    start_seconds: float = Form(0),
    duration_seconds: float = Form(10),
    output_format: str = Form("mp4"),
) -> FileResponse:
    """Trim and remux an uploaded video locally with FFmpeg."""
    data = read_upload(file)
    suffix = Path(file.filename or "video.mp4").suffix.lower() or ".mp4"
    if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
        raise HTTPException(400, "Video formati desteklenmiyor.")
    start = max(0, min(start_seconds, 86_400))
    duration = max(0.1, min(duration_seconds, 86_400))
    output_format = output_format.lower().lstrip(".")
    if output_format not in {"mp4", "webm"}:
        raise HTTPException(400, "output_format mp4 veya webm olmali.")
    directory = Path(tempfile.mkdtemp(prefix="localqwen_video_"))
    source = directory / f"input{suffix}"
    output = directory / f"edited.{output_format}"
    source.write_bytes(data)
    codec = ["-c:v", "libvpx-vp9", "-c:a", "libopus"] if output_format == "webm" else ["-c:v", "libx264", "-c:a", "aac"]
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(duration), *codec, str(output)],
            check=True, capture_output=True, text=True, timeout=300,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        shutil.rmtree(directory, ignore_errors=True)
        raise HTTPException(422, f"Video duzenleme basarisiz: {exc}") from exc
    return FileResponse(output, media_type=f"video/{output_format}", filename=f"localqwen_edited.{output_format}", background=BackgroundTask(shutil.rmtree, directory, ignore_errors=True))

@app.post("/api/instagram/image/publish")
def publish_instagram_image(request: InstagramImagePublishRequest) -> dict[str, Any]:
    """Publish a public image through Instagram Graph API after explicit approval."""
    if not request.approved:
        return {"status": "approval_required", "image_url": request.image_url, "caption": request.caption}
    parsed = urlparse(request.image_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise HTTPException(400, "image_url public bir http(s) URL olmali.")
    if not INSTAGRAM_ACCESS_TOKEN or not INSTAGRAM_USER_ID:
        raise HTTPException(503, "INSTAGRAM_ACCESS_TOKEN ve INSTAGRAM_USER_ID ayarlanmis olmali.")
    base = f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/{INSTAGRAM_USER_ID}"
    try:
        container_data = urlencode({
            "image_url": request.image_url,
            "caption": request.caption[:2_200],
            "access_token": INSTAGRAM_ACCESS_TOKEN,
        }).encode()
        with urlopen(Request(f"{base}/media", data=container_data, method="POST"), timeout=30) as response:
            container = json.loads(response.read().decode("utf-8"))
        creation_id = container.get("id")
        if not creation_id:
            raise HTTPException(502, f"Instagram medya kapsayicisi olusturulamadi: {container}")
        publish_data = urlencode({"creation_id": creation_id, "access_token": INSTAGRAM_ACCESS_TOKEN}).encode()
        with urlopen(Request(f"{base}/media_publish", data=publish_data, method="POST"), timeout=30) as response:
            published = json.loads(response.read().decode("utf-8"))
        return {"status": "published", "container": container, "published": published}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(502, f"Instagram Graph API hatasi: {detail[:1000]}") from exc
    except (URLError, json.JSONDecodeError) as exc:
        raise HTTPException(502, f"Instagram Graph API baglantisi basarisiz: {exc}") from exc


@app.post("/api/instagram/video/publish")
def publish_instagram_video(request: InstagramVideoPublishRequest) -> dict[str, Any]:
    """Create and publish a public Instagram Reel after explicit approval."""
    if not request.approved:
        return {"status": "approval_required", "video_url": request.video_url, "caption": request.caption}
    parsed = urlparse(request.video_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise HTTPException(400, "video_url public bir http(s) URL olmali.")
    if not INSTAGRAM_ACCESS_TOKEN or not INSTAGRAM_USER_ID:
        raise HTTPException(503, "INSTAGRAM_ACCESS_TOKEN ve INSTAGRAM_USER_ID ayarlanmis olmali.")
    base = f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/{INSTAGRAM_USER_ID}"
    try:
        container_data = urlencode({
            "media_type": "REELS",
            "video_url": request.video_url,
            "caption": request.caption[:2_200],
            "access_token": INSTAGRAM_ACCESS_TOKEN,
        }).encode()
        with urlopen(Request(f"{base}/media", data=container_data, method="POST"), timeout=30) as response:
            container = json.loads(response.read().decode("utf-8"))
        creation_id = container.get("id")
        if not creation_id:
            raise HTTPException(502, f"Instagram Reel kapsayicisi olusturulamadi: {container}")
        status_code = "IN_PROGRESS"
        for _ in range(12):
            status_url = f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/{creation_id}?fields=status_code&access_token={INSTAGRAM_ACCESS_TOKEN}"
            with urlopen(status_url, timeout=30) as response:
                status_code = json.loads(response.read().decode("utf-8")).get("status_code", status_code)
            if status_code in {"FINISHED", "ERROR"}:
                break
            time.sleep(5)
        if status_code != "FINISHED":
            raise HTTPException(502, f"Instagram Reel hazir degil: {status_code}")
        publish_data = urlencode({"creation_id": creation_id, "access_token": INSTAGRAM_ACCESS_TOKEN}).encode()
        with urlopen(Request(f"{base}/media_publish", data=publish_data, method="POST"), timeout=30) as response:
            published = json.loads(response.read().decode("utf-8"))
        return {"status": "published", "container": container, "container_status": status_code, "published": published}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(502, f"Instagram Graph API hatasi: {detail[:1000]}") from exc
    except (URLError, json.JSONDecodeError) as exc:
        raise HTTPException(502, f"Instagram Graph API baglantisi basarisiz: {exc}") from exc


@app.post("/api/instagram/message/send")
def send_instagram_message(request: InstagramMessageRequest) -> dict[str, Any]:
    """Send a message only when the account/app has the required Instagram permissions."""
    if not request.approved:
        return {"status": "approval_required", "recipient_id": request.recipient_id, "text": request.text[:500]}
    if not request.recipient_id.strip() or not request.text.strip():
        raise HTTPException(400, "recipient_id ve text gerekli.")
    if not INSTAGRAM_ACCESS_TOKEN or not INSTAGRAM_USER_ID:
        raise HTTPException(503, "INSTAGRAM_ACCESS_TOKEN ve INSTAGRAM_USER_ID ayarlanmis olmali.")
    endpoint = f"https://graph.facebook.com/{INSTAGRAM_GRAPH_VERSION}/{INSTAGRAM_USER_ID}/messages"
    payload = urlencode({
        "recipient": json.dumps({"id": request.recipient_id}),
        "message": json.dumps({"text": request.text[:2_000]}, ensure_ascii=False),
        "access_token": INSTAGRAM_ACCESS_TOKEN,
    }).encode()
    try:
        with urlopen(Request(endpoint, data=payload, method="POST"), timeout=30) as response:
            return {"status": "sent", "response": json.loads(response.read().decode("utf-8"))}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(502, f"Instagram mesaj API izni veya istegi basarisiz: {detail[:1000]}") from exc
    except (URLError, json.JSONDecodeError) as exc:
        raise HTTPException(502, f"Instagram Graph API baglantisi basarisiz: {exc}") from exc


@app.post("/api/memory")
def add_memory(request: MemoryRequest) -> dict[str, str]:
    note = request.note.strip()
    if not note:
        raise HTTPException(400, "Not bos olamaz.")
    save_typed_memory(note, request.category, request.project, request.source)
    return {"status": "saved", "category": request.category, "project": request.project, "source": request.source}


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)) -> dict[str, str]:
    data = read_upload(file)
    name = file.filename or "upload"
    suffix = Path(name).suffix.lower()
    asset_dir = ROOT / ".asset-store" / "uploads"
    asset_dir.mkdir(parents=True, exist_ok=True)
    asset_path = asset_dir / f"{uuid.uuid4().hex}{suffix}"
    asset_path.write_bytes(data)
    kind = "image" if suffix in {".png", ".jpg", ".jpeg", ".webp"} else "document"
    asset_id = register_asset(asset_path, kind, file.content_type or "", source="upload", metadata={"filename": name})
    if suffix in {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".txt", ".md", ".py", ".json", ".ts", ".tsx"}:
        text = extract_document_text(data, suffix)
    elif suffix in {".png", ".jpg", ".jpeg", ".webp"}:
        structure = document_structure(data, suffix)
        ocr = optional_ocr(data, suffix)
        text = structure + "\nVision analizi:\n" + call_ollama_vision(
            data,
            "Bu gorseli ayrintili ama kanita dayali analiz et. Gorunen metni, nesneleri, duzeni ve belirsizlikleri belirt.",
            suffix,
        )
        text += f"\nOCR ({'hazir' if ocr['available'] else 'kullanilamadi'}):\n{ocr['text'] or ocr['reason']}"
    else:
        text = f"{name} yuklendi; bu dosya turu icin ozel extractor henuz etkin degil."
    note = f"Dosya: {name}\nYapi: {document_structure(data, suffix)}\n{text[:12000]}"
    with db() as connection:
        connection.execute("INSERT INTO memories(note) VALUES (?)", (note,))
    return {"status": "indexed", "filename": name, "preview": text[:1000], "asset_id": str(asset_id)}


@app.post("/api/report/export")
def export_report(request: ReportExportRequest) -> FileResponse:
    if request.format not in {"md", "pdf"}:
        raise HTTPException(400, "Format md veya pdf olmali.")
    markdown = report_markdown(request.title, request.report, request.sources)
    output = Path(tempfile.gettempdir()) / f"localqwen_report_{uuid.uuid4().hex}.{request.format}"
    if request.format == "md":
        output.write_text(markdown, encoding="utf-8")
        return FileResponse(output, media_type="text/markdown", filename="localqwen_report.md")
    pdf_canvas = canvas.Canvas(str(output), pagesize=A4)
    pdf_canvas.setTitle(request.title)
    text_object = pdf_canvas.beginText(48, 800)
    text_object.setFont("Helvetica", 9)
    for line in markdown.encode("ascii", "replace").decode("ascii").splitlines():
        text_object.textLine(line[:115])
        if text_object.getY() < 48:
            pdf_canvas.drawText(text_object)
            pdf_canvas.showPage()
            text_object = pdf_canvas.beginText(48, 800)
            text_object.setFont("Helvetica", 9)
    pdf_canvas.drawText(text_object)
    pdf_canvas.save()
    return FileResponse(output, media_type="application/pdf", filename="localqwen_report.pdf")


@app.post("/api/pdf/append")
async def append_pdf(file: UploadFile = File(...), addition: str = Form(...)) -> FileResponse:
    """Append user-provided text as a new PDF page and return the result."""
    data = read_upload(file)
    if Path(file.filename or "").suffix.lower() != ".pdf":
        raise HTTPException(400, "Bu islem icin PDF dosyasi yukleyin.")
    addition = addition.strip()
    if not addition:
        raise HTTPException(400, "Eklenecek metin bos olamaz.")

    try:
        original = PdfReader(io.BytesIO(data))
        page_buffer = io.BytesIO()
        page_canvas = canvas.Canvas(page_buffer, pagesize=A4)
        width, height = A4
        page_canvas.setFont("Helvetica-Bold", 14)
        page_canvas.drawString(54, height - 60, "Ek Bilgi")
        page_canvas.setFont("Helvetica", 10)
        y = height - 90
        for paragraph in addition.splitlines() or [addition]:
            words = paragraph.split()
            line = ""
            for word in words:
                candidate = f"{line} {word}".strip()
                if page_canvas.stringWidth(candidate, "Helvetica", 10) > width - 108:
                    page_canvas.drawString(54, y, line)
                    y -= 16
                    line = word
                else:
                    line = candidate
            page_canvas.drawString(54, y, line)
            y -= 16
            if y < 54:
                page_canvas.showPage()
                page_canvas.setFont("Helvetica", 10)
                y = height - 54
        page_canvas.save()
        page_buffer.seek(0)

        writer = PdfWriter()
        for page in original.pages:
            writer.add_page(page)
        writer.add_page(PdfReader(page_buffer).pages[0])
        output = Path(tempfile.gettempdir()) / f"localqwen_{next(tempfile._get_candidate_names())}.pdf"
        with output.open("wb") as stream:
            writer.write(stream)
    except Exception as exc:
        raise HTTPException(422, f"PDF olusturulamadi: {exc}") from exc

    return FileResponse(output, media_type="application/pdf", filename="localqwen_modified.pdf")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8787)
