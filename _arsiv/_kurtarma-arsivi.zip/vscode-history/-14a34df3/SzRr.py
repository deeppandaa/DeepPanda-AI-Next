"""Safe, user-facing destinations for remote file transfers."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from services.app_settings_service import AppSettingsService
from services.package_install_service import PackageInstallService


class TransferDestinationService:
    LABELS = {
        "inbox": "Vana Gelen Paketler",
        "downloads": "Indirilenler",
        "desktop": "Masaustu",
        "documents": "Belgeler",
    }

    @classmethod
    def available_destinations(cls) -> list[dict[str, str]]:
        return [
            {"key": key, "label": label, "path": str(cls.resolve(key))}
            for key, label in cls.LABELS.items()
        ]

    @classmethod
    def resolve(cls, destination_key: str) -> Path:
        key = str(destination_key or "inbox").strip().lower()
        if key not in cls.LABELS:
            raise ValueError("Gecersiz aktarim hedefi.")

        user_profile = Path(os.environ.get("USERPROFILE", str(Path.home()))).resolve()
        paths = {
            "inbox": Path(PackageInstallService.ensure_inbox_dir()).resolve(),
            "downloads": (user_profile / "Downloads").resolve(),
            "desktop": (user_profile / "Desktop").resolve(),
            "documents": (user_profile / "Documents").resolve(),
        }
        target = paths[key]
        target.mkdir(parents=True, exist_ok=True)
        return target

    @classmethod
    def default_key(cls) -> str:
        key = str(AppSettingsService.load().get("transfer_destination_default", "inbox")).lower()
        return key if key in cls.LABELS else "inbox"

    @classmethod
    def remember_default(cls, destination_key: str) -> dict[str, Any]:
        key = str(destination_key or "").strip().lower()
        if key not in cls.LABELS:
            return {"status": "error", "message": "Gecersiz aktarim hedefi."}
        AppSettingsService.save({"transfer_destination_default": key})
        return {
            "status": "success",
            "message": "Aktarim hedefi varsayilan olarak kaydedildi.",
            "destination_key": key,
        }
