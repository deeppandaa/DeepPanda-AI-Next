rule Suspicious_PowerShell_Execution {
    meta:
        description = "Detects common malware / persistence patterns in scripts and binaries"
        author = "Copilot"
        date = "2026-08-28"

    strings:
        $p1 = "powershell" ascii wide
        $p2 = "Invoke-Expression" ascii wide
        $p3 = "FromBase64String" ascii wide
        $p4 = "Start-Process" ascii wide
        $p5 = "WScript.Shell" ascii wide
        $p6 = "RunOnce" ascii wide
        $p7 = "cmd.exe /c" ascii wide
        $p8 = "rundll32" ascii wide
        $p9 = "bitsadmin" ascii wide
        $p10 = "schtasks" ascii wide
        $p11 = "regsvr32" ascii wide
        $p12 = "CreateObject" ascii wide
        $p13 = "http://" ascii wide
        $p14 = "https://" ascii wide
        $p15 = "VirtualAlloc" ascii wide
        $p16 = "CreateRemoteThread" ascii wide
        $p17 = "ReflectiveLoader" ascii wide
        $p18 = "mshta" ascii wide

    condition:
        4 of them
}

rule Suspicious_Autorun_Triggers {
    meta:
        description = "Detects common persistence / autorun artifacts"

    strings:
        $a1 = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" ascii wide
        $a2 = "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" ascii wide
        $a3 = "CurrentVersion\\RunOnce" ascii wide
        $a4 = "schtasks /create" ascii wide
        $a5 = "at.exe" ascii wide
        $a6 = "Startup" ascii wide

    condition:
        2 of them
}
