import { Activity, Building2, Clock3, Laptop, Settings2, ShieldCheck, Users } from "lucide-react";
import { requireSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import ManagementClient from "./management-client";

export default async function ManagementPage() {
  const session = await requireSession();
  const devices = await tenantQuery<{ id: string; hostname: string; installation_id: string }>(session.organizationId,
    "SELECT id,hostname,installation_id FROM devices WHERE organization_id=$1 ORDER BY hostname");
  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><ShieldCheck size={22} /><span>VANA<br /><b>RESCUEOPS</b></span></div>
        <nav>
          <a href="/dashboard"><Activity size={18} /> Operasyon</a>
          <a href="/dashboard"><Laptop size={18} /> Cihazlar</a>
          <a href="/dashboard"><Building2 size={18} /> Müşteriler</a>
          <a href="/dashboard"><Users size={18} /> Teknisyenler</a>
          <a href="/dashboard"><Clock3 size={18} /> Denetim kayıtları</a>
          <a className="active" href="/dashboard/manage"><Settings2 size={18} /> Yönetim</a>
        </nav>
        <div className="account-block"><span>{session.name}</span><small>{session.role} · {session.email}</small><form action="/api/auth/logout" method="post"><button>Çıkış</button></form></div>
      </aside>
      <section className="workspace">
        <header className="workspace-header"><div><p className="eyebrow">OPERASYON AYARLARI</p><h1>Yönetim merkezi</h1><p>Müşteri onayı, marka kimliği ve güvenli kapsül şablonları.</p></div><span className="system-state"><i /> Organizasyon kapsamında</span></header>
        <ManagementClient role={session.role} devices={devices.rows} />
      </section>
    </main>
  );
}
