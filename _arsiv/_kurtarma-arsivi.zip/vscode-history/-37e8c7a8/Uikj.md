# AI Execution Protocol

This protocol applies the workflow principles for complex tasks.

## 1) Parallel Task Decomposition
When a request includes multiple goals:
- Split work into independent tasks.
- Execute read-only analysis tasks in parallel when possible.
- Merge outputs into one final implementation plan.

## 2) Audit Before Rewrite
Before major edits:
- Run a project audit.
- Identify architecture risks, security issues, and bottlenecks.
- Prioritize fixes by impact and risk.

## 3) Persistent Context First
At the start of each large session:
- Review PROJECT_CONTEXT.md.
- Append key decisions to DECISION_LOG.md.
- Avoid re-asking known context unless it changed.

## 4) Analysis Depth Gate
For complex issues, do not rush to first answer:
- Clarify objective and constraints.
- List assumptions and unknowns.
- Choose verification steps before implementation.

## 5) Self-Critique Pass
Before finalizing:
- Challenge assumptions.
- Search for failure modes and regressions.
- Validate with tests.

## 6) Long-Run Project Memory
For monthly-scale work:
- Keep decision trail current.
- Keep one source of truth for architecture context.
- Record why alternatives were rejected.

## Prompt Templates

### Multi-task Parallelization
"These tasks must complete in the same window: [task list]. Split into task owners, run independent tasks in parallel, coordinate dependencies, and merge outputs at the end."

### Project Audit
"Analyze the full project. Find architecture decisions to revisit, top technical debt, security gaps, and performance bottlenecks. Return a prioritized action plan with quick wins first."

### Critical Reasoning
"Do not answer immediately. First assess required analysis depth, list missing context, challenge assumptions, then propose a solution path."
