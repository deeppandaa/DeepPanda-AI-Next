import { Activity, Building2, ClipboardList, Clock3, Laptop, Settings2, ShieldCheck, Users } from "lucide-react";
import { requireSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import TicketsClient from "./tickets-client";

type Option = { id: string; name: string };
type DeviceOption = { id: string; hostname: string; customer_id: string | null };
type Ticket = {
  id: string; ticket_number: string; title: string; description: string; category: string;
  priority: string; status: string; sla_due_at: string | null; created_at: string;
  customer_name: string | null; device_name: string | null; technician_name: string | null; sla_breached: boolean;
};

export default async function TicketsPage() {
  const session = await requireSession();
  const [tickets, customers, devices, technicians] = await Promise.all([
    tenantQuery<Ticket>(session.organizationId, `SELECT
      t.id,t.ticket_number::text,t.title,t.description,t.category,t.priority,t.status,t.sla_due_at,t.created_at,
      c.name customer_name,d.hostname device_name,u.name technician_name,
      (t.sla_due_at IS NOT NULL AND t.sla_due_at < now() AND t.status NOT IN ('resolved','closed','cancelled')) sla_breached
      FROM service_tickets t LEFT JOIN customers c ON c.id=t.customer_id LEFT JOIN devices d ON d.id=t.device_id
      LEFT JOIN users u ON u.id=t.assigned_technician_id WHERE t.organization_id=$1
      ORDER BY CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END,t.created_at DESC LIMIT 200`),
    tenantQuery<Option>(session.organizationId, "SELECT id,name FROM customers WHERE organization_id=$1 ORDER BY name"),
    tenantQuery<DeviceOption>(session.organizationId, "SELECT id,hostname,customer_id FROM devices WHERE organization_id=$1 ORDER BY hostname"),
    tenantQuery<Option>(session.organizationId, "SELECT id,name FROM users WHERE organization_id=$1 AND active AND role IN ('owner','admin','technician') ORDER BY name"),
  ]);
  return <main className="app-shell">
    <aside className="sidebar">
      <div className="sidebar-brand"><ShieldCheck size={22} /><span>DeepPanda<br /><b>CONTROL PANEL</b></span></div>
      <nav>
        <a href="/dashboard"><Activity size={18} /> Operasyon</a>
        <a href="/dashboard/devices"><Laptop size={18} /> Cihazlar</a>
        <a href="/dashboard/customers"><Building2 size={18} /> Müşteriler</a>
        <a className="active" href="/dashboard/tickets"><ClipboardList size={18} /> İş Emirleri</a>
        <a href="/dashboard/users"><Users size={18} /> Kullanıcı Yönetimi</a>
        <a href="/dashboard/audit"><Clock3 size={18} /> Denetim kayıtları</a>
        <a href="/dashboard/manage"><Settings2 size={18} /> Yönetim</a>
      </nav>
      <div className="account-block"><span>{session.name}</span><small>{session.role} · {session.email}</small><form action="/api/auth/logout" method="post"><button>Çıkış</button></form></div>
    </aside>
    <section className="workspace ticket-workspace">
      <header className="workspace-header"><div><p className="eyebrow">SAHA SERVİS OPERASYONU</p><h1>İş emirleri</h1><p>Arıza kabulünden SLA takibine kadar tek operasyon kuyruğu.</p></div><span className="system-state"><i /> Tenant izolasyonu etkin</span></header>
      <TicketsClient initialTickets={tickets.rows} customers={customers.rows} devices={devices.rows} technicians={technicians.rows} role={session.role} />
    </section>
  </main>;
}