import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { query, transaction } from "@/lib/db";

const deviceIdSchema = z.uuid();
const deleteSchema = z.object({
  confirmationHostname: z.string().trim().min(1).max(255),
  password: z.string().min(8).max(200),
});

type RouteContext = { params: Promise<{ id: string }> };
type UserRow = { password_hash: string; active: boolean };
type DeviceRow = { id: string; hostname: string; installation_id: string };

export async function DELETE(request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Oturum gerekli." }, { status: 401 });
  if (!["owner", "admin"].includes(session.role)) {
    return NextResponse.json({ message: "Cihaz kaldırma yetkiniz yok." }, { status: 403 });
  }

  const { id } = await context.params;
  if (!deviceIdSchema.safeParse(id).success) {
    return NextResponse.json({ message: "Geçersiz cihaz kimliği." }, { status: 400 });
  }
  const parsed = deleteSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ message: "Cihaz adı ve hesap parolası zorunlu." }, { status: 400 });
  }

  const userResult = await query<UserRow>(
    `SELECT password_hash,active FROM users WHERE id=$1 AND organization_id=$2 LIMIT 1`,
    [session.userId, session.organizationId],
  );
  const user = userResult.rows[0];
  if (!user?.active || !(await bcrypt.compare(parsed.data.password, user.password_hash))) {
    return NextResponse.json({ message: "Hesap parolası doğrulanamadı." }, { status: 401 });
  }

  const outcome = await transaction(async (client) => {
    const deviceResult = await client.query<DeviceRow>(
      `SELECT id,hostname,installation_id FROM devices
       WHERE id=$1 AND organization_id=$2 FOR UPDATE`,
      [id, session.organizationId],
    );
    const device = deviceResult.rows[0];
    if (!device) return "not_found";
    if (device.hostname !== parsed.data.confirmationHostname) return "hostname_mismatch";

    await client.query(
      `INSERT INTO removed_devices (organization_id,installation_id,hostname,removed_by)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (organization_id,installation_id) DO UPDATE SET
         hostname=excluded.hostname,removed_by=excluded.removed_by,removed_at=now()`,
      [session.organizationId, device.installation_id, device.hostname, session.userId],
    );
    await client.query(
      `INSERT INTO audit_events (organization_id,actor_user_id,action,target_type,target_id,detail)
       VALUES ($1,$2,'device.removed','device',$3,$4::jsonb)`,
      [session.organizationId, session.userId, device.id, JSON.stringify({
        hostname: device.hostname,
        installationId: device.installation_id,
        verification: "hostname_and_password",
      })],
    );
    await client.query(
      `UPDATE licenses SET device_id=NULL WHERE organization_id=$1 AND device_id=$2`,
      [session.organizationId, device.id],
    );
    await client.query(
      `UPDATE payment_orders SET device_id=NULL WHERE organization_id=$1 AND device_id=$2`,
      [session.organizationId, device.id],
    );
    await client.query(
      `UPDATE license_issuance_jobs SET device_id=NULL WHERE organization_id=$1 AND device_id=$2`,
      [session.organizationId, device.id],
    );
    await client.query(
      `DELETE FROM support_sessions WHERE organization_id=$1 AND device_id=$2`,
      [session.organizationId, device.id],
    );
    await client.query(`DELETE FROM devices WHERE id=$1 AND organization_id=$2`, [id, session.organizationId]);
    return "removed";
  });

  if (outcome === "not_found") return NextResponse.json({ message: "Cihaz bulunamadı." }, { status: 404 });
  if (outcome === "hostname_mismatch") {
    return NextResponse.json({ message: "Yazılan cihaz adı eşleşmiyor." }, { status: 409 });
  }
  return NextResponse.json({ ok: true, message: "Cihaz kaldırıldı ve yeniden kaydı engellendi." });
}

const patchDeviceSchema = z.object({
  customerId: z.string().uuid().nullable().optional(),
});

export async function PATCH(request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Oturum gerekli." }, { status: 401 });
  if (!["owner", "admin", "technician"].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }

  const { id } = await context.params;
  if (!deviceIdSchema.safeParse(id).success) {
    return NextResponse.json({ message: "Geçersiz cihaz kimliği." }, { status: 400 });
  }

  const parsed = patchDeviceSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ message: "Geçersiz veri." }, { status: 400 });
  }

  await query(
    `UPDATE devices SET customer_id = $3 WHERE id = $1 AND organization_id = $2`,
    [id, session.organizationId, parsed.data.customerId ?? null]
  );

  return NextResponse.json({ ok: true, message: "Cihaz müşteri ataması güncellendi." });
}