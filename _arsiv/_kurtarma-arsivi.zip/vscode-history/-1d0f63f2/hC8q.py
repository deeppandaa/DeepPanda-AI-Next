import sqlite3
from pathlib import Path

path = Path(__file__).with_name('memory.db')
connection = sqlite3.connect(path)
print('INTEGRITY', connection.execute('PRAGMA integrity_check').fetchone()[0])
print('TABLES', [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")])
for table in ('memories', 'operation_journal', 'task_records', 'job_records'):
    print(table.upper(), connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0])
print('LIBRARY_KNOWLEDGE', connection.execute("SELECT COUNT(*) FROM memories WHERE category = ?", ('library_knowledge',)).fetchone()[0])
connection.close()
