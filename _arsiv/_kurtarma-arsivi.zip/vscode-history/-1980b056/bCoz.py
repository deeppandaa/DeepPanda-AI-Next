from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")


def project_path(setting: str, default: str | Path) -> Path:
    configured = os.getenv(setting, "").strip()
    path = Path(configured).expanduser() if configured else Path(default)
    return (path if path.is_absolute() else ROOT / path).resolve()


WORKSPACE_ROOT = project_path("WORKSPACE_ROOT", ".")
_excluded_workspace_entries = [
    entry.strip()
    for entry in os.getenv("WORKSPACE_EXCLUDED_DIRS", "").split(";")
    if entry.strip()
]
WORKSPACE_EXCLUDED_PATHS = tuple(
    candidate
    for entry in _excluded_workspace_entries
    if (candidate := project_path("", WORKSPACE_ROOT / entry)) == WORKSPACE_ROOT
    or WORKSPACE_ROOT in candidate.parents
)
MEMORY_DB = project_path("MEMORY_DB", "data/memory/memory.db")
IMAGE_MODEL_PATH = project_path("IMAGE_MODEL_PATH", "models/tiny-sd")
VIDEO_MODEL_PATH = project_path("VIDEO_MODEL_PATH", "models/text-to-video-ms-1.7b")
PIPER_MODEL_PATH = project_path(
    "PIPER_MODEL_PATH",
    "models/piper-voices/tr_TR-dfki-medium/tr_TR-dfki-medium.onnx",
)
OLLAMA_EXECUTABLE = project_path("OLLAMA_EXECUTABLE", "packages/ollama/ollama.exe")
FFMPEG_EXECUTABLE = project_path("FFMPEG_EXECUTABLE", "packages/ffmpeg/ffmpeg.exe")
PLAYWRIGHT_BROWSERS_PATH = project_path("PLAYWRIGHT_BROWSERS_PATH", "packages/playwright-browsers")
HF_HOME = project_path("HF_HOME", "packages/cache/huggingface")
TORCH_HOME = project_path("TORCH_HOME", "packages/cache/torch")
PIP_CACHE_DIR = project_path("PIP_CACHE_DIR", "packages/pip-cache")
AI_LIBRARIES = ROOT / "AI-Libraries"
LIBRARY_CATALOG = ROOT / "library_catalog.json"
KNOWLEDGE_CATALOG = ROOT / "knowledge_catalog.json"

local_binary_directories = [
    executable.parent
    for executable in (OLLAMA_EXECUTABLE, FFMPEG_EXECUTABLE)
    if executable.is_file()
]
if local_binary_directories:
    existing_path = os.environ.get("PATH", "")
    os.environ["PATH"] = os.pathsep.join([*(str(path) for path in local_binary_directories), existing_path])
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(PLAYWRIGHT_BROWSERS_PATH)
os.environ["HF_HOME"] = str(HF_HOME)
os.environ["TORCH_HOME"] = str(TORCH_HOME)
os.environ["PIP_CACHE_DIR"] = str(PIP_CACHE_DIR)