"""IT operations workspace for diagnostics, inventory, services, and event logs."""

from __future__ import annotations

import json
import os
import threading
from tkinter import messagebox

import customtkinter as ctk

from services.it_operations_service import ITOperationsService
from services.log_service import LogService


class ITOperationsView(ctk.CTkFrame):
    PANEL_BG = "#273544"
    TEXT_PRIMARY = "#F2F5F7"
    TEXT_SECONDARY = "#AEB9C4"

    def __init__(self, parent: ctk.CTkFrame):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.service = ITOperationsService()
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self._build_ui()

    def _build_ui(self):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=18, pady=(16, 8), sticky="ew")
        header.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(
            header,
            text="IT Operasyon Merkezi",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=self.TEXT_PRIMARY,
        ).grid(row=0, column=0, sticky="w")
        self.status_label = ctk.CTkLabel(header, text="Hazir", text_color=self.TEXT_SECONDARY)
        self.status_label.grid(row=0, column=1, padx=12, sticky="e")

        quick = ctk.CTkFrame(self, fg_color=self.PANEL_BG, corner_radius=6)
        quick.grid(row=1, column=0, padx=18, pady=8, sticky="ew")
        quick.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(quick, text="Ag hedefi", text_color=self.TEXT_PRIMARY).grid(row=0, column=0, padx=12, pady=12)
        self.target_entry = ctk.CTkEntry(quick, placeholder_text="1.1.1.1 veya sunucu.local")
        self.target_entry.insert(0, "1.1.1.1")
        self.target_entry.grid(row=0, column=1, padx=8, pady=12, sticky="ew")
        ctk.CTkButton(quick, text="Ag Tanilama", width=110, command=self._run_network).grid(row=0, column=2, padx=6, pady=12)
        ctk.CTkButton(quick, text="Son Hatalar", width=100, fg_color="#8A5A00", command=self._load_events).grid(row=0, column=3, padx=6, pady=12)
        ctk.CTkButton(quick, text="Envanter Raporu", width=125, fg_color="#2E7D32", command=self._export_inventory).grid(row=0, column=4, padx=12, pady=12)

        services = ctk.CTkFrame(self, fg_color=self.PANEL_BG, corner_radius=6)
        services.grid(row=2, column=0, padx=18, pady=8, sticky="ew")
        services.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(services, text="Windows Servisleri", font=ctk.CTkFont(size=14, weight="bold"), text_color=self.TEXT_PRIMARY).grid(row=0, column=0, padx=12, pady=10, sticky="w")
        self.service_query_entry = ctk.CTkEntry(services, placeholder_text="Servis adi veya gorunen ad")
        self.service_query_entry.grid(row=0, column=1, padx=8, pady=10, sticky="ew")
        ctk.CTkButton(services, text="Listele", width=85, command=self._list_services).grid(row=0, column=2, padx=6, pady=10)

        ctk.CTkLabel(services, text="Servis adi", text_color=self.TEXT_PRIMARY).grid(row=1, column=0, padx=12, pady=(0, 10))
        self.service_name_entry = ctk.CTkEntry(services, placeholder_text="ornek: Spooler")
        self.service_name_entry.grid(row=1, column=1, padx=8, pady=(0, 10), sticky="ew")
        self.service_action = ctk.CTkSegmentedButton(services, values=["start", "stop", "restart"])
        self.service_action.set("restart")
        self.service_action.grid(row=1, column=2, padx=6, pady=(0, 10))
        ctk.CTkButton(services, text="Uygula", width=85, fg_color="#7A2635", command=self._manage_service).grid(row=1, column=3, padx=12, pady=(0, 10))

        self.output = ctk.CTkTextbox(
            self,
            fg_color="#111820",
            text_color=self.TEXT_PRIMARY,
            font=("Consolas", 11),
            wrap="word",
        )
        self.output.grid(row=3, column=0, padx=18, pady=(8, 18), sticky="nsew")
        self._write("IT operasyon paneli hazir. Servis degisiklikleri yonetici yetkisi gerektirebilir.")

    def _write(self, text: str, clear: bool = False):
        if clear:
            self.output.delete("1.0", "end")
        self.output.insert("end", str(text).rstrip() + "\n")
        self.output.see("end")

    def _run_async(self, label: str, operation, on_success):
        self.status_label.configure(text=f"{label} calisiyor...")

        def worker():
            try:
                result = operation()
                self.after(0, lambda: self._finish_operation(label, result, on_success))
            except Exception as exc:
                self.after(0, lambda: self._finish_operation(label, {"status": "error", "message": str(exc)}, on_success))

        threading.Thread(target=worker, daemon=True).start()

    def _finish_operation(self, label: str, result: dict, on_success):
        if result.get("status") == "success":
            self.status_label.configure(text=f"{label} tamamlandi")
            on_success(result)
            LogService.add_log("INFO", result.get("message", label), "IT Operasyon")
        else:
            message = result.get("message", f"{label} basarisiz.")
            self.status_label.configure(text="Islem basarisiz")
            self._write(f"HATA: {message}")
            LogService.add_log("ERROR", message, "IT Operasyon")

    def _run_network(self):
        target = self.target_entry.get().strip() or "1.1.1.1"
        self._run_async(
            "Ag tanilama",
            lambda: self.service.network_diagnostics(target),
            lambda result: self._write(json.dumps(result.get("diagnostics", {}), ensure_ascii=False, indent=2), clear=True),
        )

    def _list_services(self):
        query = self.service_query_entry.get().strip()

        def show(result):
            rows = result.get("services", [])
            lines = [f"{'NAME':<30} {'STATE':<10} {'START':<10} DISPLAY NAME", "-" * 95]
            for item in rows[:300]:
                lines.append(
                    f"{str(item.get('Name', ''))[:29]:<30} "
                    f"{str(item.get('State', ''))[:9]:<10} "
                    f"{str(item.get('StartMode', ''))[:9]:<10} "
                    f"{item.get('DisplayName', '')}"
                )
            self._write("\n".join(lines), clear=True)

        self._run_async("Servis listesi", lambda: self.service.list_services(query), show)

    def _manage_service(self):
        action = self.service_action.get()
        name = self.service_name_entry.get().strip()
        if not name:
            self._write("HATA: Servis adi gerekli.")
            return
        if not messagebox.askyesno(
            "Servis islemi onayi",
            f"{name} servisi icin '{action}' islemi uygulansin mi?",
            parent=self.winfo_toplevel(),
        ):
            self._write("Servis islemi kullanici tarafindan iptal edildi.")
            return
        self._run_async(
            "Servis islemi",
            lambda: self.service.manage_service(action, name),
            lambda result: self._write(json.dumps(result.get("service", {}), ensure_ascii=False, indent=2), clear=True),
        )

    def _load_events(self):
        def show(result):
            events = result.get("events", [])
            lines = []
            for item in events:
                message = str(item.get("Message", "")).replace("\r", " ").replace("\n", " ")
                lines.append(
                    f"[{item.get('TimeCreated', '')}] {item.get('LogName', '')} "
                    f"{item.get('LevelDisplayName', '')} ID={item.get('Id', '')} "
                    f"{item.get('ProviderName', '')}\n{message[:700]}\n"
                )
            self._write("\n".join(lines) or "Son iki gunde hata bulunamadi.", clear=True)

        self._run_async("Olay gunlugu", lambda: self.service.recent_errors(50), show)

    def _export_inventory(self):
        def show(result):
            path = result.get("path", "")
            self._write(
                f"Envanter raporu hazir. Program sayisi: {result.get('program_count', 0)}\n{path}",
                clear=True,
            )
            if path and os.path.exists(path):
                os.startfile(os.path.dirname(path))

        self._run_async("Envanter", self.service.export_inventory, show)
