"""Program catalog and installed-program inventory for DeepPanda."""

from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from tkinter import messagebox
from typing import Any

import customtkinter as ctk

from gui.transmission_view import TransmissionView
from services.portable_tools_service import PortableToolsService
from services.program_inventory_service import ProgramInventoryService


class ProgramsView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self._programs: list[dict[str, Any]] = []
        self._selected_program: dict[str, Any] | None = None
        self._transmission_view: TransmissionView | None = None
        self._portable_frame: ctk.CTkFrame | None = None
        self._portable_list: ctk.CTkScrollableFrame | None = None
        self._portable_status: ctk.CTkLabel | None = None
        self._portable_search: ctk.CTkEntry | None = None
        self._portable_tools: list[dict[str, Any]] = []

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=22, pady=(20, 8), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Programlar",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color="#F2F5F7",
        ).grid(row=0, column=0, sticky="w")
        self.refresh_button = ctk.CTkButton(
            header,
            text="Yenile",
            width=96,
            command=self.refresh,
        )
        self.refresh_button.grid(row=0, column=2, sticky="e")
        self.section_switch = ctk.CTkSegmentedButton(
            header,
            values=["Yüklü Programlar", "Taşınabilir Araçlar", "İndirmeler"],
            command=self._switch_section,
        )
        self.section_switch.grid(row=0, column=1, padx=(12, 8), sticky="e")
        self.section_switch.set("Yüklü Programlar")

        self.catalog_description = ctk.CTkLabel(
            self,
            text="DeepPanda araçları ve bilgisayarda kurulu programlar.",
            text_color="#AEB9C4",
        )
        self.catalog_description.grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        self.catalog_controls = ctk.CTkFrame(self, fg_color="#273544", corner_radius=6)
        self.catalog_controls.grid(row=2, column=0, padx=22, pady=(0, 10), sticky="ew")
        self.catalog_controls.grid_columnconfigure(0, weight=1)
        self.search_entry = ctk.CTkEntry(
            self.catalog_controls,
            placeholder_text="Program adı veya yayıncı ara...",
            height=38,
        )
        self.search_entry.grid(row=0, column=0, padx=12, pady=12, sticky="ew")
        self.search_entry.bind("<KeyRelease>", lambda _event: self._render_programs())
        self.status_label = ctk.CTkLabel(self.catalog_controls, text="Hazır", text_color="#AEB9C4")
        self.status_label.grid(row=0, column=1, padx=(8, 14), pady=12)

        self.results = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.results.grid(row=3, column=0, padx=14, pady=(0, 8), sticky="nsew")
        self.results.grid_columnconfigure(0, weight=1)

        self.details = ctk.CTkFrame(self, fg_color="#1E2A36", corner_radius=6)
        self.details.grid(row=4, column=0, padx=22, pady=(0, 16), sticky="ew")
        self.details.grid_columnconfigure(0, weight=1)
        self.detail_name = ctk.CTkLabel(
            self.details,
            text="Bir program seçin",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#F2F5F7",
            anchor="w",
        )
        self.detail_name.grid(row=0, column=0, columnspan=4, padx=14, pady=(12, 2), sticky="ew")
        self.detail_info = ctk.CTkLabel(
            self.details,
            text="Ayrıntılar ve yönetim seçenekleri burada görünür.",
            text_color="#AEB9C4",
            anchor="w",
            justify="left",
        )
        self.detail_info.grid(row=1, column=0, columnspan=4, padx=14, pady=(0, 10), sticky="ew")
        self.uninstall_button = ctk.CTkButton(
            self.details,
            text="Güvenli Kaldır",
            state="disabled",
            command=self._confirm_uninstall,
        )
        self.uninstall_button.grid(row=2, column=0, padx=(14, 6), pady=(0, 12), sticky="w")
        self.modify_button = ctk.CTkButton(
            self.details,
            text="Değiştir / Onar",
            state="disabled",
            fg_color="#41586C",
            command=self._confirm_modify,
        )
        self.modify_button.grid(row=2, column=1, padx=6, pady=(0, 12), sticky="w")
        self.residual_button = ctk.CTkButton(
            self.details,
            text="Kalıntı Tara",
            state="disabled",
            fg_color="#41586C",
            command=self._preview_residuals,
        )
        self.residual_button.grid(row=2, column=2, padx=6, pady=(0, 12), sticky="w")
        self._catalog_widgets = (
            self.catalog_description,
            self.catalog_controls,
            self.results,
            self.details,
        )

        self.refresh()

    def _switch_section(self, selected: str) -> None:
        self._hide_all_sections()
        if selected == "İndirmeler":
            if self._transmission_view is None:
                self._transmission_view = TransmissionView(self)
                self._transmission_view.grid(
                    row=1,
                    column=0,
                    rowspan=4,
                    padx=0,
                    pady=(0, 4),
                    sticky="nsew",
                )
            else:
                self._transmission_view.grid()
            self._transmission_view.set_active(True)
            return
        if selected == "Taşınabilir Araçlar":
            self._show_portable_section()
            return
        for widget in self._catalog_widgets:
            widget.grid()
        self.refresh_button.grid()

    def _hide_all_sections(self) -> None:
        for widget in self._catalog_widgets:
            widget.grid_remove()
        self.refresh_button.grid_remove()
        if self._transmission_view is not None:
            self._transmission_view.set_active(False)
            self._transmission_view.grid_remove()
        if self._portable_frame is not None:
            self._portable_frame.grid_remove()

    def _show_portable_section(self) -> None:
        if self._portable_frame is None:
            self._build_portable_section()
        assert self._portable_frame is not None
        self._portable_frame.grid()
        if not self._portable_tools:
            self.refresh_portable_tools()

    def _build_portable_section(self) -> None:
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.grid(row=1, column=0, rowspan=4, padx=22, pady=(0, 16), sticky="nsew")
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(2, weight=1)

        ctk.CTkLabel(
            frame,
            text="DeepPanda ile birlikte gelen taşınabilir servis araçları (kurulum gerektirmez).",
            text_color="#AEB9C4",
        ).grid(row=0, column=0, pady=(0, 10), sticky="w")

        controls = ctk.CTkFrame(frame, fg_color="#273544", corner_radius=6)
        controls.grid(row=1, column=0, pady=(0, 10), sticky="ew")
        controls.grid_columnconfigure(0, weight=1)
        self._portable_search = ctk.CTkEntry(
            controls,
            placeholder_text="Araç adı ara...",
            height=38,
        )
        self._portable_search.grid(row=0, column=0, padx=12, pady=12, sticky="ew")
        self._portable_search.bind("<KeyRelease>", lambda _event: self._render_portable_tools())
        self._portable_status = ctk.CTkLabel(controls, text="Hazır", text_color="#AEB9C4")
        self._portable_status.grid(row=0, column=1, padx=(8, 8), pady=12)
        ctk.CTkButton(
            controls,
            text="Yenile",
            width=96,
            command=self.refresh_portable_tools,
        ).grid(row=0, column=2, padx=(0, 12), pady=12)

        self._portable_list = ctk.CTkScrollableFrame(frame, fg_color="transparent")
        self._portable_list.grid(row=2, column=0, sticky="nsew")
        self._portable_list.grid_columnconfigure(0, weight=1)

        self._portable_frame = frame

    def refresh_portable_tools(self) -> None:
        if self._portable_status is not None:
            self._portable_status.configure(text="Taranıyor...")
        threading.Thread(target=self._scan_portable_tools, daemon=True).start()

    def _scan_portable_tools(self) -> None:
        result = PortableToolsService.list_tools()
        self.after(0, lambda: self._apply_portable_result(result))

    def _apply_portable_result(self, result: dict[str, Any]) -> None:
        self._portable_tools = result.get("tools", []) if result.get("status") == "success" else []
        if self._portable_status is not None:
            if result.get("status") == "success":
                self._portable_status.configure(text=f"{len(self._portable_tools)} araç")
            else:
                self._portable_status.configure(text=str(result.get("message", "Tarama başarısız.")))
        self._render_portable_tools()

    def _render_portable_tools(self) -> None:
        if self._portable_list is None:
            return
        for widget in self._portable_list.winfo_children():
            widget.destroy()

        query = ""
        if self._portable_search is not None:
            query = self._portable_search.get().strip().lower()

        matches = [
            tool
            for tool in self._portable_tools
            if not query
            or query in str(tool.get("name", "")).lower()
            or query in str(tool.get("package", "")).lower()
        ]

        if not matches:
            ctk.CTkLabel(
                self._portable_list,
                text="Eşleşen taşınabilir araç yok.",
                text_color="#AEB9C4",
            ).grid(row=0, column=0, padx=12, pady=12, sticky="w")
            return

        for row, tool in enumerate(matches[:400]):
            card = ctk.CTkFrame(self._portable_list, fg_color="#1E2A36", corner_radius=6)
            card.grid(row=row, column=0, padx=6, pady=4, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(
                card,
                text=str(tool.get("name", "")),
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color="#F2F5F7",
                anchor="w",
            ).grid(row=0, column=0, padx=12, pady=(10, 0), sticky="w")
            ctk.CTkLabel(
                card,
                text=f"{tool.get('package', '')} · {tool.get('size_kb', 0)} KB",
                text_color="#AEB9C4",
                anchor="w",
            ).grid(row=1, column=0, padx=12, pady=(0, 10), sticky="w")
            ctk.CTkButton(
                card,
                text="Çalıştır",
                width=96,
                command=lambda path=tool.get("path", ""): self._launch_portable_tool(path),
            ).grid(row=0, column=1, rowspan=2, padx=12, pady=10)

    def _launch_portable_tool(self, tool_path: str) -> None:
        result = PortableToolsService.launch(tool_path)
        if result.get("status") != "success":
            messagebox.showerror("Taşınabilir Araç", str(result.get("message", "Araç başlatılamadı.")))
        elif self._portable_status is not None:
            self._portable_status.configure(text=str(result.get("message", "")))

    def refresh(self) -> None:
        self._select_program(None)
        self.refresh_button.configure(state="disabled", text="Taranıyor")
        self.status_label.configure(text="Programlar taranıyor...")
        threading.Thread(target=self._scan_programs, daemon=True).start()

    def _scan_programs(self) -> None:
        result = ProgramInventoryService.scan_installed_programs()
        self.after(0, lambda: self._apply_scan_result(result))

    def _apply_scan_result(self, result: dict[str, Any]) -> None:
        self.refresh_button.configure(state="normal", text="Yenile")
        if result.get("status") != "success":
            self._programs = []
            self.status_label.configure(text=str(result.get("message", "Tarama başarısız.")))
        else:
            programs = result.get("programs", [])
            self._programs = programs if isinstance(programs, list) else []
            self.status_label.configure(text=f"{len(self._programs)} program")
        self._render_programs()

    def _render_programs(self) -> None:
        for widget in self.results.winfo_children():
            widget.destroy()

        query = self.search_entry.get().strip().casefold()
        filtered = [
            program
            for program in self._programs
            if not query
            or query in str(program.get("name", "")).casefold()
            or query in str(program.get("publisher", "")).casefold()
        ]
        if not filtered:
            ctk.CTkLabel(
                self.results,
                text="Eşleşen program bulunamadı.",
                text_color="#AEB9C4",
            ).grid(row=0, column=0, padx=12, pady=28)
            return

        for row, program in enumerate(filtered):
            item = ctk.CTkFrame(self.results, fg_color="#273544", corner_radius=6)
            item.grid(row=row, column=0, padx=8, pady=5, sticky="ew")
            item.grid_columnconfigure(0, weight=1)
            name = str(program.get("name", "Bilinmeyen program"))
            version = str(program.get("version", "") or "Sürüm bilinmiyor")
            publisher = str(program.get("publisher", "") or "Yayıncı bilinmiyor")
            ctk.CTkLabel(
                item,
                text=name,
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color="#F2F5F7",
                anchor="w",
            ).grid(row=0, column=0, padx=14, pady=(11, 2), sticky="ew")
            ctk.CTkLabel(
                item,
                text=f"{publisher}  |  {version}",
                text_color="#AEB9C4",
                anchor="w",
            ).grid(row=1, column=0, padx=14, pady=(0, 11), sticky="ew")
            ctk.CTkButton(
                item,
                text="İncele",
                width=84,
                fg_color="#41586C",
                command=lambda selected=program: self._select_program(selected),
            ).grid(row=0, column=1, rowspan=2, padx=12, pady=10)

    def _select_program(self, program: dict[str, Any] | None) -> None:
        self._selected_program = program
        if program is None:
            self.detail_name.configure(text="Bir program seçin")
            self.detail_info.configure(text="Ayrıntılar ve yönetim seçenekleri burada görünür.")
            self.uninstall_button.configure(state="disabled")
            self.modify_button.configure(state="disabled")
            self.residual_button.configure(state="disabled")
            return

        size_kb = self._number(program.get("estimated_size_kb"))
        size_text = self._format_size(size_kb * 1024) if size_kb else "Bilinmiyor"
        location = str(program.get("install_location", "") or "Bilinmiyor")
        install_date = self._format_date(program.get("install_date", ""))
        self.detail_name.configure(text=str(program.get("name", "Bilinmeyen program")))
        self.detail_info.configure(
            text=(
                f"Yayıncı: {program.get('publisher') or 'Bilinmiyor'}   |   "
                f"Sürüm: {program.get('version') or 'Bilinmiyor'}   |   "
                f"Boyut: {size_text}   |   Kurulum: {install_date}\n"
                f"Konum: {location}"
            )
        )
        self.uninstall_button.configure(
            state="normal" if program.get("uninstall_string") else "disabled"
        )
        self.modify_button.configure(state="normal" if program.get("modify_path") else "disabled")
        plan = ProgramInventoryService.residual_plan(program)
        can_scan = bool(
            plan.get("files") or plan.get("registry_entries") or plan.get("registry_values")
        )
        self.residual_button.configure(state="normal" if can_scan else "disabled")

    def _confirm_uninstall(self) -> None:
        program = self._selected_program
        if not program:
            return
        name = str(program.get("name", "Bu program"))
        if not messagebox.askyesno(
            "Güvenli kaldırma",
            f"{name} için kayıtlı kaldırıcı başlatılsın mı?\n\n"
            "Programın kendi kaldırma sihirbazı açılacaktır.",
            parent=self,
        ):
            return
        result = ProgramInventoryService.launch_registered_action(program, "uninstall")
        if result.get("status") == "broken_uninstaller":
            self.status_label.configure(text=str(result.get("message", "Kaldırıcı bulunamadı.")))
            if messagebox.askyesno(
                "Kaldırıcı bulunamadı",
                f"{result.get('message')}\n\n"
                "Kayıt defteri geçmişi ve program kalıntıları şimdi taransın mı?",
                icon="warning",
                parent=self,
            ):
                self._preview_residuals()
            return
        self._show_action_result(result)

    def _confirm_modify(self) -> None:
        program = self._selected_program
        if not program:
            return
        result = ProgramInventoryService.launch_registered_action(program, "modify")
        self._show_action_result(result)

    def _preview_residuals(self) -> None:
        program = self._selected_program
        if not program:
            return
        plan = ProgramInventoryService.residual_plan(program)
        items = [*(str(value) for value in plan.get("files", []))]
        items.extend(str(value) for value in plan.get("registry_entries", []))
        items.extend(str(value.get("display", "")) for value in plan.get("registry_values", []))
        if not items:
            messagebox.showinfo(
                "Kalıntı analizi",
                "Güvenle eşleştirilen kalıntı bulunamadı.",
                parent=self,
            )
            return
        visible_items = items[:30]
        preview = "\n".join(f"- {value}" for value in visible_items)
        if len(items) > len(visible_items):
            preview += f"\n- ... ve {len(items) - len(visible_items)} öğe daha"
        if not messagebox.askyesno(
            "Kalıntı önizlemesi",
            "Yalnız aşağıdaki kesin eşleşmeler temizlenecek:\n\n"
            f"{preview}\n\nDevam ederseniz tüm öğeler önce DeepPanda yedeğine taşınır.",
            parent=self,
        ):
            return
        if not messagebox.askyesno(
            "Zorla kaldırmayı onayla",
            "Bu işlem normal kaldırma başarısız olduğunda kullanılmalıdır. "
            "Yedekli temizleme başlatılsın mı?",
            icon="warning",
            parent=self,
        ):
            return
        self._set_actions_enabled(False)
        self.status_label.configure(text="Kalıntılar yedeklenip temizleniyor...")
        threading.Thread(target=self._run_force_cleanup, args=(program,), daemon=True).start()

    def _run_force_cleanup(self, program: dict[str, Any]) -> None:
        result = ProgramInventoryService.force_cleanup(program)
        self.after(0, lambda: self._finish_force_cleanup(result))

    def _finish_force_cleanup(self, result: dict[str, Any]) -> None:
        if result.get("status") == "requires_elevation":
            if not messagebox.askyesno(
                "Yönetici izni gerekli",
                f"{result.get('message')}\n\n"
                "Yalnız kalıntı temizleme yardımcısı yönetici olarak başlatılsın mı?",
                icon="warning",
                parent=self,
            ):
                self._select_program(self._selected_program)
                return
            launch = ProgramInventoryService.launch_elevated_cleanup(
                self._selected_program or {}
            )
            if launch.get("status") != "pending":
                self._show_action_result(launch)
                self._select_program(self._selected_program)
                return
            self.status_label.configure(text=str(launch.get("message")))
            self.after(500, lambda: self._poll_elevated_cleanup(launch["result_path"], 0))
            return
        self._show_action_result(result)
        if result.get("status") in {"success", "partial"}:
            backup = result.get("backup_path", "")
            details = f"Silinen öğeler geri alınabilmesi için buraya yedeklendi:\n{backup}"
            if result.get("status") == "partial":
                errors = "\n".join(str(value) for value in result.get("errors", [])[:8])
                messagebox.showwarning(
                    "Temizlik kısmen tamamlandı",
                    f"{details}\n\nTamamlanamayan işlemler:\n{errors}",
                    parent=self,
                )
            else:
                messagebox.showinfo("Yedekli temizlik tamamlandı", details, parent=self)
            self.refresh()
        else:
            self._select_program(self._selected_program)

    def _poll_elevated_cleanup(self, result_value: str, attempt: int) -> None:
        result_path = Path(result_value)
        if result_path.is_file():
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                self.after(500, lambda: self._poll_elevated_cleanup(result_value, attempt + 1))
                return
            result_path.unlink(missing_ok=True)
            self._finish_force_cleanup(result)
            return
        if attempt >= 600:
            messagebox.showerror(
                "Yönetici temizliği",
                "Yönetici temizliği zaman aşımına uğradı veya iptal edildi.",
                parent=self,
            )
            self._select_program(self._selected_program)
            return
        self.after(500, lambda: self._poll_elevated_cleanup(result_value, attempt + 1))

    def _set_actions_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.uninstall_button.configure(state=state)
        self.modify_button.configure(state=state)
        self.residual_button.configure(state=state)

    def _show_action_result(self, result: dict[str, Any]) -> None:
        message = str(result.get("message", "İşlem tamamlandı."))
        self.status_label.configure(text=message)
        if result.get("status") == "error":
            messagebox.showerror("Programlar", message, parent=self)

    @staticmethod
    def _number(value: Any) -> int:
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        size = float(max(size_bytes, 0))
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024 or unit == "TB":
                return f"{size:.1f} {unit}"
            size /= 1024
        return "Bilinmiyor"

    @staticmethod
    def _format_date(value: Any) -> str:
        raw = str(value or "").strip()
        if re_match := re.fullmatch(r"(\d{4})(\d{2})(\d{2})", raw):
            return f"{re_match.group(3)}.{re_match.group(2)}.{re_match.group(1)}"
        return raw or "Bilinmiyor"
