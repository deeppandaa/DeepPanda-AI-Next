# Developer Agent Playbook

This is a self-contained, ZIP-independent distillation of the Gemma developer-agent harness material reviewed on 2026-09-28. The source archive is not required at runtime. Its SHA-256 was `6a3e5826ef930823db259d257dd34224fa521f984e9b3f4cbbe86f985436abe7`.

## What Was Reviewed

- The full 671-line harness guide, including architecture, declarative agent configuration, sandbox lifecycle, tool contracts, budgets, patch verification, and operational gotchas.
- All 129 task records and their patch/test-patch metadata: 67 FastAPI, 48 Rich, 13 Requests, and 1 HTTPX task; 27,603 patch lines and 20,993 test-patch lines.
- The sample system/analyzer prompts, agent/sub-agent YAML, sampling and evaluation config, Docker definitions, and sandbox setup source, read statically without executing them.
- Archive inventory: 129 repository snapshots, 127 code graphs, 127 embedding files, and 124 wheels. The 129 compressed source snapshots account for about 21.5 GB and were not copied into this knowledge archive or executed.

## Transferable Engineering Method

1. Parse the user-visible failure/request into an observable acceptance condition.
2. Locate the owning function and nearest relevant tests; inspect only enough code to form a falsifiable hypothesis.
3. Keep reads bounded and use symbol/call relationships where available. Treat generated graphs and embeddings as navigation aids, not evidence that replaces source inspection.
4. Make the smallest reversible change in production code. Never make a test pass by weakening or deleting the test.
5. Run the cheapest targeted check first, then the relevant regression suite and static checks.
6. Verify the resulting patch and changed-file scope; keep temporary reproductions and generated artifacts out of the source patch.
7. Report what was verified, what remains uncertain, and any environmental limitation.

## Agent Architecture Lessons

- Separate orchestration, model serving, tools, and evaluation/verification boundaries.
- Prefer declarative configuration resolved through a closed registry over dynamically importing arbitrary agent code.
- Give tools narrow contracts, validated inputs, bounded output, structured success/error results, and explicit timeouts.
- Make tool budgets and wall-clock budgets visible. Keep a small reserve for validation and finalization.
- A free status/checkpoint operation is useful near budget exhaustion; do not spend the remaining budget on repeated broad scans.
- Separate analysis from mutation: read-only analysis can be delegated or summarized, while writes and commands remain approval-gated.
- Treat continuation after truncation as state recovery: resume from the last completed step, do not repeat the full prior reasoning or action.

## Isolation and Verification Lessons

- A strong evaluator uses one environment for the agent and a fresh environment for verification, both based on the same pinned revision.
- Offline sandboxes should consume pre-staged dependencies and must not silently download packages.
- Establish a clean baseline before edits, exclude generated artifacts, and verify the proposed diff against that baseline.
- Re-run required tests in a clean environment after applying the patch. Test files and test-runner configuration are not implementation targets unless the request explicitly changes test behavior.
- Path traversal, symlink escape, arbitrary imports, shell execution, and unbounded resource use require explicit barriers.
- The source harness uses some competition-specific patch mechanics, including `git apply --unsafe-paths`; that mechanism is intentionally NOT adopted here. LocalQwenAgent retains its stricter workspace checks and approval gates.

## Task Corpus Findings

The 129 tasks are mainly realistic regression work rather than greenfield generation. Repeated themes include HTTP/header/URL behavior, validation and error contracts, dependency/routing semantics, schema/OpenAPI output, Python compatibility, and terminal rendering. Frequently touched FastAPI modules include dependency resolution, routing, compatibility, and OpenAPI generation; test patches target corresponding focused test modules.

The reusable lesson is to test behavior at the contract boundary: malformed input, aliases, optional values, wrapped callables, backward compatibility, and exact output/error semantics. Keep a regression test adjacent to the behavior and avoid unrelated refactors.

## Non-Transferable Source Constraints

The original harness targets a specific competition: Google ADK, a Gemma model registry, 4x L4 GPUs, fixed context/budget settings, Kaggle submission-size rules, and benchmark-specific CLI behavior. Those values are not universal and are not copied into LocalQwenAgent. This playbook retains only the engineering and safety principles applicable to this Windows/offline-first project.

The archive's repository snapshots, embeddings, graph data, wheels, and LoRA weights remain external. This file and the matching `memory.db` notes contain the operational knowledge needed by the agent without depending on the ZIP.