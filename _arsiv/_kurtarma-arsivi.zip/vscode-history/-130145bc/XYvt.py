"""Vendor-only DeepPanda offline license generator.

Never distribute the Ed25519 private key or this admin workflow with customer installers.
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import time
import uuid
from pathlib import Path

from cryptography.hazmat.primitives import serialization


def b64_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def normalize_machine_id(value: str) -> str:
    machine_id = "".join(character for character in str(value or "").upper() if character in "0123456789ABCDEF")
    if len(machine_id) != 64:
        raise ValueError("Kurulum kimligi 64 hexadecimal karakter icermeli.")
    return machine_id


def generate_license(private_key_path: Path, customer: str, plan: str, installation_id: str) -> tuple[str, dict]:
    if plan not in {"annual", "unlimited"}:
        raise ValueError("Plan annual veya unlimited olmali.")
    customer = str(customer or "").strip()
    if len(customer) < 2:
        raise ValueError("Musteri adi zorunlu.")
    machine_id = normalize_machine_id(installation_id)
    private_key = serialization.load_pem_private_key(private_key_path.read_bytes(), password=None)
    issued_at = int(time.time())
    payload = {
        "version": 1,
        "license_id": uuid.uuid4().hex,
        "customer": customer,
        "plan": plan,
        "machine_id": machine_id,
        "issued_at": issued_at,
        "expires_at": issued_at + 365 * 24 * 60 * 60 if plan == "annual" else None,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    key = f"VANA1.{b64_encode(raw)}.{b64_encode(private_key.sign(raw))}"
    return key, payload


def main() -> int:
    default_private = Path(__file__).resolve().parents[2] / "DeepPanda-License-Admin" / "license_private_key.pem"
    parser = argparse.ArgumentParser(description="DeepPanda lisans anahtari uretir.")
    parser.add_argument("--customer", required=True, help="Musteri veya firma adi")
    parser.add_argument("--plan", required=True, choices=["annual", "unlimited"])
    parser.add_argument("--installation-id", required=True, help="Uygulamadaki tam Kurulum Kimligi")
    parser.add_argument("--private-key", type=Path, default=default_private)
    parser.add_argument("--output", type=Path, help="Anahtari yazilacak dosya")
    args = parser.parse_args()
    try:
        key, payload = generate_license(
            args.private_key, args.customer, args.plan, args.installation_id
        )
    except Exception as exc:
        print(f"HATA: {exc}", file=sys.stderr)
        return 1
    output = args.output or (
        Path(__file__).resolve().parents[2]
        / "DeepPanda-License-Admin"
        / f"license_{payload['customer'].replace(' ', '_')}_{payload['license_id'][:8]}.txt"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(key, encoding="utf-8")
    print(f"Lisans olusturuldu: {output}")
    print(f"Plan: {payload['plan']} | License ID: {payload['license_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
