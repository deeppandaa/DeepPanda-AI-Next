import { NextResponse } from "next/server";
import { z } from "zod";
import { transaction } from "@/lib/db";
import { verifyIyzicoHppWebhook } from "@/lib/payments";

const schema = z.object({
  paymentConversationId: z.string().min(1).max(200),
  merchantId: z.string().min(1).max(100),
  token: z.string().min(1).max(500),
  status: z.string().min(1).max(60),
  iyziReferenceCode: z.string().min(1).max(200),
  iyziEventType: z.string().min(1).max(100),
  iyziEventTime: z.number(),
  iyziPaymentId: z.number(),
});

export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Geçersiz webhook." }, { status: 400 });
  const signature = request.headers.get("x-iyz-signature-v3") ?? "";
  const secret = process.env.IYZICO_SECRET_KEY ?? "";
  if (!verifyIyzicoHppWebhook(parsed.data, signature, secret)) {
    return NextResponse.json({ message: "Webhook imzası geçersiz." }, { status: 401 });
  }
  const body = parsed.data;
  await transaction(async (client) => {
    const inserted = await client.query(
      `INSERT INTO payment_webhook_events (provider,reference_code,conversation_id,payload)
       VALUES ('iyzico',$1,$2,$3::jsonb)
       ON CONFLICT (provider,reference_code) DO NOTHING RETURNING id`,
      [body.iyziReferenceCode, body.paymentConversationId, JSON.stringify(body)],
    );
    if (inserted.rowCount !== 1) return;
    const paid = body.status === "SUCCESS";
    const order = await client.query<{ id: string; organization_id: string; device_id: string | null; plan: string }>(
      `UPDATE payment_orders SET status=$1,payment_reference=$2,
        paid_at=CASE WHEN $1='paid' THEN now() ELSE paid_at END,updated_at=now()
       WHERE conversation_id=$3 AND status='pending'
       RETURNING id,organization_id,device_id,plan`,
      [paid ? "paid" : "failed", String(body.iyziPaymentId), body.paymentConversationId],
    );
    if (!paid || order.rows.length !== 1) return;
    const row = order.rows[0];
    await client.query(
      `INSERT INTO license_issuance_jobs
        (organization_id,payment_order_id,device_id,plan)
       VALUES ($1,$2,$3,$4) ON CONFLICT (payment_order_id) DO NOTHING`,
      [row.organization_id, row.id, row.device_id, row.plan],
    );
    await client.query(
      `INSERT INTO audit_events (organization_id,action,target_type,target_id,detail)
       VALUES ($1,'payment.success','payment_order',$2,$3::jsonb)`,
      [row.organization_id, row.id, JSON.stringify({ conversationId: body.paymentConversationId })],
    );
  });
  return NextResponse.json({ ok: true });
}
