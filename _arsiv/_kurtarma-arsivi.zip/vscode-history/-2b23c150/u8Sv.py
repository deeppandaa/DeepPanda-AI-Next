"""
DeepPanda - Ana Giriş Dosyası
"""

import sys
import io
import os
import subprocess
import traceback
from pathlib import Path

# Windows konsol ve Python standart çıktı akışlarını UTF-8 moduna zorla
if sys.platform.startswith("win"):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    except Exception:
        pass

# Proje kök dizinini sys.path'e ekle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

REQUIRED_MODULES = (
    "customtkinter",
    "psutil",
    "pynvml",
    "serial",
    "jsonschema",
    "PIL",
    "pyautogui",
)


def ensure_runtime_dependencies() -> None:
    """Uygulama çalıştırılmadan önce gerekli bağımlılıkların kurulu olduğunu kontrol eder."""
    # PyInstaller paketinde import denetimi yalancı negatif üretebilir.
    if getattr(sys, "frozen", False):
        return

    missing = []
    for module_name in REQUIRED_MODULES:
        try:
            __import__(module_name)
        except ModuleNotFoundError:
            missing.append(module_name)

    if missing:
        print("[SystemCore] Eksik bağımlılıklar tespit edildi:", ", ".join(missing))
        print("[SystemCore] Kurulum komutu:")
        print("py -m pip install --break-system-packages -r requirements.txt")
        raise SystemExit(1)


ensure_runtime_dependencies()

if __name__ == "__main__" and "--cleanup-manifest" in sys.argv:
    from services.program_inventory_service import ProgramInventoryService

    manifest_index = sys.argv.index("--cleanup-manifest") + 1
    if manifest_index >= len(sys.argv):
        raise SystemExit(2)
    raise SystemExit(ProgramInventoryService.run_cleanup_manifest(sys.argv[manifest_index]))

from gui.main_window import MainWindow


def _ensure_desktop_launcher_for_windows() -> None:
    """Create a desktop launcher for installed EXE builds on Windows."""
    if not sys.platform.startswith("win"):
        return

    if not getattr(sys, "frozen", False):
        return

    exe_path = str(Path(sys.executable).resolve())
    desktop = Path(os.environ.get("USERPROFILE", "")) / "Desktop"
    if not desktop.exists():
        return

    shortcut_path = desktop / "DeepPanda Baslatici.lnk"
    escaped_shortcut = str(shortcut_path).replace("'", "''")
    escaped_exe = exe_path.replace("'", "''")
    shortcut_script = (
        "$WshShell = New-Object -ComObject WScript.Shell;"
        f"$Shortcut = $WshShell.CreateShortcut('{escaped_shortcut}');"
        f"$Shortcut.TargetPath = '{escaped_exe}';"
        "$Shortcut.WorkingDirectory = Split-Path $Shortcut.TargetPath;"
        "$Shortcut.Save();"
    )

    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", shortcut_script],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return
    except Exception:
        pass

    # Fallback launcher file if .lnk creation is blocked by policy.
    fallback_cmd = desktop / "DeepPanda_Baslatici.cmd"
    try:
        fallback_cmd.write_text(f'@echo off\nstart "" "{exe_path}"\n', encoding="utf-8")
    except Exception:
        pass


def _report_startup_error(exc: Exception) -> None:
    """Persist startup crash details and show a user-facing error on Windows."""
    log_dir = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DeepPanda"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "startup_error.log"
    detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    log_path.write_text(detail, encoding="utf-8")

    if sys.platform.startswith("win"):
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(
                0,
                f"DeepPanda baslatilamadi.\nDetay: {log_path}",
                "DeepPanda Baslangic Hatasi",
                0x10,
            )
        except Exception:
            pass

if __name__ == "__main__":
    try:
        _ensure_desktop_launcher_for_windows()
        app = MainWindow()
        app.run()
    except Exception as exc:
        _report_startup_error(exc)
        raise
