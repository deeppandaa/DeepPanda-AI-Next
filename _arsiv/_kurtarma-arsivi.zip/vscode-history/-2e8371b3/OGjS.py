"""
Multi-User Service - Farklı profiller ve izin yönetimi.
"""

import sqlite3
import json
import hashlib
import time
from typing import Dict, List, Any
import secrets


class MultiUserService:
    """Kullanıcı hesapları ve rol tabanlı erişim kontrolü."""

    ROLES = {
        "admin": ["all"],
        "operator": ["view", "execute_safe_tasks", "restart_services"],
        "viewer": ["view"],
    }

    def __init__(self, db_path: str = "systemcore.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Kullanıcı tablosunu oluştur."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL,
                    enabled BOOLEAN DEFAULT 1,
                    created_at REAL NOT NULL,
                    last_login REAL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS user_permissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    permission TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """)
            conn.commit()

    def create_user(self, username: str, password: str, role: str = "viewer") -> bool:
        """Yeni kullanıcı oluştur."""
        if role not in self.ROLES:
            return False

        password_hash = self._hash_password(password)
        with sqlite3.connect(self.db_path) as conn:
            try:
                conn.execute(
                    """INSERT INTO users (username, password_hash, role, created_at)
                       VALUES (?, ?, ?, ?)""",
                    (username, password_hash, role, time.time()),
                )
                conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False

    def authenticate(self, username: str, password: str) -> Dict[str, Any] | None:
        """Kullanıcı doğrulaması."""
        with sqlite3.connect(self.db_path) as conn:
            user = conn.execute(
                "SELECT id, username, password_hash, role FROM users WHERE username = ?", (username,)
            ).fetchone()

        if user and self._verify_password(password, user[2]):
            return {"id": user[0], "username": user[1], "role": user[3]}
        return None

    def get_user_permissions(self, user_id: int) -> List[str]:
        """Kullanıcının izinlerini getir."""
        with sqlite3.connect(self.db_path) as conn:
            perms = conn.execute(
                "SELECT permission FROM user_permissions WHERE user_id = ?", (user_id,)
            ).fetchall()
        return [p[0] for p in perms]

    def has_permission(self, user_id: int, permission: str) -> bool:
        """Kullanıcının belirli izni var mı kontrol et."""
        user_perms = self.get_user_permissions(user_id)
        return "all" in user_perms or permission in user_perms

    def list_users(self) -> List[Dict[str, Any]]:
        """Tüm kullanıcıları listele."""
        with sqlite3.connect(self.db_path) as conn:
            users = conn.execute(
                "SELECT id, username, role, enabled FROM users ORDER BY created_at DESC"
            ).fetchall()
        return [{"id": u[0], "username": u[1], "role": u[2], "enabled": u[3]} for u in users]

    def _hash_password(self, password: str) -> str:
        """Parolayı hash et."""
        salt = secrets.token_hex(16)
        h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
        return f"{salt}${h.hex()}"

    def _verify_password(self, password: str, password_hash: str) -> bool:
        """Parolayı doğrula."""
        try:
            salt, h = password_hash.split("$")
            computed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000).hex()
            return computed == h
        except Exception:
            return False
