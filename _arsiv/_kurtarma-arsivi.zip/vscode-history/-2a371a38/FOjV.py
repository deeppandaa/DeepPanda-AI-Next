from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

import requests


class HybridRouter:
    def __init__(
        self,
        base_url: str,
        model: str,
        max_context_tokens: int = 1200,
        max_response_tokens: int = 300,
    ) -> None:
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.max_context_tokens = max_context_tokens
        self.max_response_tokens = max_response_tokens

    def process(self, query: str, context: str = '') -> Dict[str, str]:
        route = self.route_query(query)
        compressed_context = self.compress_context(context, query)

        if route == 'fast':
            answer = self.fast_reply(query, compressed_context)
        else:
            answer = self.qwen_reply(query, compressed_context)

        return {'route': route, 'answer': answer}

    def route_query(self, query: str) -> str:
        q = (query or '').lower()
        fast_keywords = ['özet', 'kısa', 'başlık', 'tanımla', 'ne demek', 'güncelle', 'sor']
        deep_keywords = ['kod', 'debug', 'analiz', 'plan', 'karar', 'optimize', 'compare', 'açıkla', 'yapılandır', 'hata']

        if any(k in q for k in deep_keywords):
            return 'qwen'
        if any(k in q for k in fast_keywords):
            return 'fast'

        if len(q) < 160:
            return 'fast'
        return 'qwen'

    def compress_context(self, context: str, query: str) -> str:
        text = (context or '').strip()
        if not text:
            return ''

        if len(text) <= self.max_context_tokens * 3:
            return text

        sentences = text.split('. ')
        # keep the most relevant tail and strongest sentences
        kept = sentences[-8:]
        return ' '.join(kept)

    def fast_reply(self, query: str, context: str) -> str:
        answer = 'Kısa bir yanıt veriyorum:\n'
        if context:
            answer += f"Bağlam: {context[:220]}\n"
        answer += f"İstek: {query}"
        return answer

    def qwen_reply(self, query: str, context: str) -> str:
        prompt = self.build_prompt(query, context)
        try:
            payload = {
                'model': self.model,
                'prompt': prompt,
                'stream': False,
                'options': {
                    'num_predict': self.max_response_tokens
                },
            }
            response = requests.post(f'{self.base_url}/api/generate', json=payload, timeout=120)
            response.raise_for_status()
            data = response.json()
            return data.get('response', 'Qwen yanıtı alınamadı.')
        except Exception:
            fallback = (
                'Qwen erişilemedi; düşük maliyetli yerel akış devreye alındı.\n'
                'İsteği daha kısa ve daha net biçimde tekrar sorabilir veya yalnızca gerekli bağlamı ekleyebilirsiniz.'
            )
            return fallback

    def build_prompt(self, query: str, context: str) -> str:
        rules = [
            'Sen Qwen 3.6 gibisin.',
            'Yanıtın kısa, net ve yalnızca istenen konuda olsun.',
            'Gereksiz detay ekleme.',
            'İsteğe göre adım adım çözüm üret.',
            'Eğer çok uzun bağlam varsa yalnızca gerekli kısımları kullan.',
        ]
        context_block = f"\nBağlam:\n{context}\n" if context else ''
        return (
            '\n'.join(rules)
            + '\n\nİstek:\n'
            + query
            + context_block
            + '\n\nCevap:'
        )
