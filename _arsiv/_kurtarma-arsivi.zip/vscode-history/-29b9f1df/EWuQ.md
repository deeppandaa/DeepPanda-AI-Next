---
name: Analyze ARC-AGI Solver
description: Review an ARC-AGI solver or transformation rule, identify correctness risks, and propose focused improvements.
argument-hint: Optional task ID, failing example, or solver behavior to investigate
agent: agent
---
Analyze the selected code, active file, or relevant ARC-AGI workspace files for the requested task: $ARGUMENTS

Work from concrete evidence in the repository. Inspect the owning solver path, nearby tests, representative ARC input/output grids, and any validation or submission artifacts needed to verify the behavior. Preserve existing architecture and avoid unrelated refactors.

Determine:
- What transformation or solver behavior the code is intended to implement
- Whether the implementation matches that behavior for training, test, and edge-case grids
- The smallest root-cause fix when a defect exists
- Which existing or new focused test would most clearly validate the conclusion

Return a concise report with these sections:

1. **Finding**: State the result and severity.
2. **Evidence**: Cite relevant workspace files and concrete examples, including task IDs when available.
3. **Recommended change**: Describe the minimal code or rule change. If implementation is requested or clearly necessary, make it and keep the edit scoped.
4. **Validation**: Run the narrowest relevant test or validation command and report its result. If no executable check is available, state the remaining uncertainty.

Do not infer a rule from a single example when multiple examples are available. Distinguish confirmed defects from hypotheses, and do not claim a solver is correct without checking its validation path.