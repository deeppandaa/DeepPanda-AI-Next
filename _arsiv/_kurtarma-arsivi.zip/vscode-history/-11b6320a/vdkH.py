from game import check_guess


def test_guess_is_higher():
    assert check_guess(50, 20) == "higher"


def test_guess_is_lower():
    assert check_guess(50, 80) == "lower"


def test_guess_is_correct():
    assert check_guess(50, 50) == "correct"
