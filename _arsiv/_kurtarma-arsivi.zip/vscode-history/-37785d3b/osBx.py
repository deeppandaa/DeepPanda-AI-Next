"""Vendor-only GUI for creating signed RescueOps update manifests."""

from __future__ import annotations

import json
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from update_manifest_generator import generate_manifest


class UpdatePublisherApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("DeepPanda Update Publisher")
        self.root.geometry("760x620")
        self.root.minsize(680, 560)
        self.admin_dir = self._admin_dir()
        self.project_dir = self.admin_dir.parent
        self.private_key = self.admin_dir / "keys" / "update_private_key.pem"
        self._build_ui()

    @staticmethod
    def _admin_dir() -> Path:
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
        return Path(__file__).resolve().parents[2] / "DeepPanda-License-Admin"

    def _entry(self, parent, row, label, default=""):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6)
        entry = ttk.Entry(parent)
        entry.insert(0, default)
        entry.grid(row=row, column=1, sticky="ew", padx=(12, 0), pady=6)
        return entry

    def _build_ui(self):
        frame = ttk.Frame(self.root, padding=20)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text="Imzali Guncelleme Yayincisi", font=("Segoe UI", 18, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 14)
        )
        self.base_url = self._entry(frame, 1, "Yayin Base URL", "https://updates.example.com/vana")
        self.desktop_version = self._entry(frame, 2, "Desktop Surumu", "2.7.1")
        self.android_code = self._entry(frame, 3, "Android Version Code", "10")
        self.android_name = self._entry(frame, 4, "Android Version Name", "1.9")
        ttk.Label(frame, text="Degisiklik Notlari").grid(row=5, column=0, sticky="nw", pady=6)
        self.changelog = tk.Text(frame, height=7, wrap="word")
        self.changelog.grid(row=5, column=1, sticky="nsew", padx=(12, 0), pady=6)
        self.force_update = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame, text="Zorunlu guncelleme", variable=self.force_update).grid(
            row=6, column=1, sticky="w", pady=6
        )
        ttk.Button(frame, text="Imzali Manifest Uret", command=self.publish).grid(
            row=7, column=0, columnspan=2, sticky="ew", pady=(14, 8)
        )
        self.status = ttk.Label(frame, text="Hazir")
        self.status.grid(row=8, column=0, columnspan=2, sticky="w")
        self.output = tk.Text(frame, height=8, state="disabled", font=("Consolas", 9), wrap="word")
        self.output.grid(row=9, column=0, columnspan=2, sticky="nsew", pady=(10, 0))
        frame.rowconfigure(9, weight=1)

    def publish(self):
        try:
            base = self.base_url.get().strip().rstrip("/")
            if not base.startswith("https://"):
                raise ValueError("Yayin URL HTTPS olmali.")
            desktop_file = self.project_dir / "Kurulum" / "DeepPanda_kurulum.exe"
            android_file = self.project_dir / "DeepPanda-App" / "assets" / "mobile" / "DeepPandaMobile-release.apk"
            document = generate_manifest(
                self.private_key,
                desktop_file,
                self.desktop_version.get().strip(),
                f"{base}/DeepPanda_kurulum.exe",
                android_file,
                int(self.android_code.get().strip()),
                self.android_name.get().strip(),
                f"{base}/DeepPandaMobile-release.apk",
                self.changelog.get("1.0", "end").strip(),
                self.force_update.get(),
            )
            output = self.admin_dir / "publish" / "update-manifest.json"
            output.write_text(json.dumps(document, indent=2), encoding="utf-8")
        except Exception as exc:
            self.status.configure(text=f"HATA: {exc}", foreground="#a32626")
            messagebox.showerror("Manifest Uretilemedi", str(exc))
            return
        summary = (
            f"Manifest: {output}\n\nSunucuya yuklenecek 3 dosya:\n"
            f"- {output.name}\n- {desktop_file.name}\n- {android_file.name}\n\n"
            f"Uygulamadaki manifest URL:\n{base}/{output.name}"
        )
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", summary)
        self.output.configure(state="disabled")
        self.status.configure(text="Imzali manifest hazir.", foreground="#256d3d")
        messagebox.showinfo("Manifest Hazir", "Manifest ve iki kurulum dosyasini HTTPS sunucuya yukleyin.")


def main():
    root = tk.Tk()
    try:
        ttk.Style(root).theme_use("vista")
    except tk.TclError:
        pass
    UpdatePublisherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
