import { strict as assert } from "assert";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import { createSessionToken } from "../src/lib/auth";
import { pool } from "../src/lib/db";

const baseUrl = process.env.TEST_BASE_URL ?? "http://127.0.0.1:3101";

async function deleteRequest(path: string, token: string, body?: unknown) {
  return fetch(`${baseUrl}${path}`, {
    method: "DELETE",
    headers: {
      cookie: `vana_session=${token}`,
      ...(body ? { "content-type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
}

async function main() {
  const organizationId = randomUUID();
  const userId = randomUUID();
  const deviceId = randomUUID();
  const pendingOrderId = randomUUID();
  const paidOrderId = randomUUID();
  const ticketId = randomUUID();
  const hostname = `DELETE-TEST-${Date.now()}`;
  const password = `Delete-${randomUUID()}`;

  await pool.query(
    `INSERT INTO organizations(id,name,slug) VALUES ($1,$2,$3)`,
    [organizationId, "Deletion Test", `deletion-test-${randomUUID()}`],
  );
  try {
    await pool.query(
      `INSERT INTO users(id,organization_id,email,name,password_hash,role)
       VALUES ($1,$2,$3,'Test Owner',$4,'owner')`,
      [userId, organizationId, `${randomUUID()}@test.invalid`, await bcrypt.hash(password, 10)],
    );
    await pool.query(
      `INSERT INTO devices(id,organization_id,installation_id,hostname)
       VALUES ($1,$2,$3,$4)`,
      [deviceId, organizationId, `test-installation-${randomUUID()}`, hostname],
    );
    await pool.query(
      `INSERT INTO payment_orders(id,organization_id,device_id,conversation_id,plan,amount_kurus,status)
       VALUES ($1,$2,$3,$4,'annual',100,'pending'),($5,$2,NULL,$6,'annual',100,'paid')`,
      [pendingOrderId, organizationId, deviceId, `pending-${randomUUID()}`, paidOrderId, `paid-${randomUUID()}`],
    );
    await pool.query(
      `INSERT INTO licenses(organization_id,device_id,license_id,plan,status,issued_at)
       VALUES ($1,$2,$3,'annual','active',now())`,
      [organizationId, deviceId, `test-license-${randomUUID()}`],
    );
    await pool.query(
      `INSERT INTO license_issuance_jobs(organization_id,payment_order_id,device_id,plan)
       VALUES ($1,$2,$3,'annual')`,
      [organizationId, pendingOrderId, deviceId],
    );
    await pool.query(
      `INSERT INTO support_sessions(organization_id,device_id,technician_id,status,reason)
       VALUES ($1,$2,$3,'completed','Deletion regression test')`,
      [organizationId, deviceId, userId],
    );
    await pool.query(
      `INSERT INTO service_tickets(id,organization_id,created_by,title,status)
       VALUES ($1,$2,$3,'Completed deletion test','resolved')`,
      [ticketId, organizationId, userId],
    );

    const token = await createSessionToken({
      userId,
      organizationId,
      email: "owner@test.invalid",
      name: "Test Owner",
      role: "owner",
    });
    const deviceResponse = await deleteRequest(`/api/devices/${deviceId}`, token, {
      confirmationHostname: hostname,
      password,
    });
    assert.equal(deviceResponse.status, 200, await deviceResponse.text());

    const deviceState = await pool.query(
      `SELECT
        (SELECT count(*) FROM devices WHERE id=$1) AS devices,
        (SELECT count(*) FROM removed_devices WHERE organization_id=$2) AS tombstones,
        (SELECT count(*) FROM support_sessions WHERE device_id=$1) AS sessions,
        (SELECT count(*) FROM payment_orders WHERE id=$3 AND device_id IS NULL) AS detached_orders,
        (SELECT count(*) FROM licenses WHERE organization_id=$2 AND device_id IS NULL) AS detached_licenses,
        (SELECT count(*) FROM license_issuance_jobs WHERE payment_order_id=$3 AND device_id IS NULL) AS detached_jobs`,
      [deviceId, organizationId, pendingOrderId],
    );
    assert.deepEqual(deviceState.rows[0], {
      devices: "0",
      tombstones: "1",
      sessions: "0",
      detached_orders: "1",
      detached_licenses: "1",
      detached_jobs: "1",
    });

    const pendingResponse = await deleteRequest(`/api/payments/orders/${pendingOrderId}`, token);
    assert.equal(pendingResponse.status, 200, await pendingResponse.text());
    const pendingState = await pool.query(`SELECT count(*) FROM payment_orders WHERE id=$1`, [pendingOrderId]);
    assert.equal(pendingState.rows[0].count, "0");

    const paidResponse = await deleteRequest(`/api/payments/orders/${paidOrderId}`, token);
    assert.equal(paidResponse.status, 409, await paidResponse.text());
    const paidState = await pool.query(`SELECT count(*) FROM payment_orders WHERE id=$1`, [paidOrderId]);
    assert.equal(paidState.rows[0].count, "1");
    const ticketResponse = await deleteRequest(`/api/tickets/${ticketId}`, token);
    assert.equal(ticketResponse.status, 200, await ticketResponse.text());
    const ticketState = await pool.query(`SELECT count(*) FROM service_tickets WHERE id=$1`, [ticketId]);
    assert.equal(ticketState.rows[0].count, "0");
    console.log("Deletion API OK: device removed, test order deleted, paid order protected, completed ticket deleted");
  } finally {
    await pool.query(`DELETE FROM organizations WHERE id=$1`, [organizationId]);
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});