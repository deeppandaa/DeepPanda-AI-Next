"""Vendor-only signed update manifest generator."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import time
from pathlib import Path

from cryptography.hazmat.primitives import serialization


def b64_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def artifact(path: Path, version_fields: dict, url: str) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return {**version_fields, "url": url, "sha256": digest, "size": path.stat().st_size}


def generate_manifest(
    private_key_path: Path,
    desktop_path: Path,
    desktop_version: str,
    desktop_url: str,
    android_path: Path,
    android_version_code: int,
    android_version_name: str,
    android_url: str,
    changelog: str,
    force_update: bool,
) -> dict:
    private_key = serialization.load_pem_private_key(private_key_path.read_bytes(), password=None)
    payload = {
        "format": 1,
        "published_at": int(time.time()),
        "force_update": bool(force_update),
        "changelog": str(changelog or ""),
        "desktop": artifact(desktop_path, {"version": desktop_version}, desktop_url),
        "android": artifact(
            android_path,
            {"version_code": int(android_version_code), "version_name": android_version_name},
            android_url,
        ),
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return {"payload": b64_encode(raw), "signature": b64_encode(private_key.sign(raw))}


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    admin = root.parent / "DeepPanda-License-Admin"
    parser = argparse.ArgumentParser(description="Imzali DeepPanda update manifesti uretir.")
    parser.add_argument("--desktop-version", required=True)
    parser.add_argument("--desktop-url", required=True)
    parser.add_argument("--android-version-code", type=int, required=True)
    parser.add_argument("--android-version-name", required=True)
    parser.add_argument("--android-url", required=True)
    parser.add_argument("--changelog", default="")
    parser.add_argument("--force-update", action="store_true")
    parser.add_argument("--desktop-file", type=Path, default=root.parent / "DeepPanda_kurulum.exe")
    parser.add_argument("--android-file", type=Path, default=root.parent / "DeepPandaMobile-release.apk")
    parser.add_argument("--private-key", type=Path, default=admin / "update_private_key.pem")
    parser.add_argument("--output", type=Path, default=admin / "update-manifest.json")
    args = parser.parse_args()
    try:
        document = generate_manifest(
            args.private_key,
            args.desktop_file,
            args.desktop_version,
            args.desktop_url,
            args.android_file,
            args.android_version_code,
            args.android_version_name,
            args.android_url,
            args.changelog,
            args.force_update,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(document, indent=2), encoding="utf-8")
    except Exception as exc:
        print(f"HATA: {exc}")
        return 1
    print(f"Imzali manifest olusturuldu: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
