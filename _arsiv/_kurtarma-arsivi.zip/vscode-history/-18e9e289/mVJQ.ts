import { NextResponse } from "next/server";
import { z } from "zod";
import { auditEvent } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";

const updateSchema = z.object({
  status: z.enum(["open", "assigned", "in_progress", "waiting_customer", "resolved", "closed", "cancelled"]),
  technicianId: z.string().uuid().nullable().optional(),
});

const noteSchema = z.object({ note: z.string().trim().min(2).max(4000) });
const ticketIdSchema = z.string().uuid();

async function ticketId(context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  return ticketIdSchema.safeParse(id);
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  const parsedId = await ticketId(context);
  if (!parsedId.success) return NextResponse.json({ message: "Geçersiz iş emri kimliği." }, { status: 400 });
  const ticket = await tenantQuery(session.organizationId, `SELECT
    t.id,t.ticket_number::text,t.title,t.description,t.category,t.priority,t.status,t.sla_due_at,
    t.created_at,t.updated_at,c.name customer_name,d.hostname device_name,u.name technician_name
    FROM service_tickets t
    LEFT JOIN customers c ON c.id=t.customer_id
    LEFT JOIN devices d ON d.id=t.device_id
    LEFT JOIN users u ON u.id=t.assigned_technician_id
    WHERE t.organization_id=$1 AND t.id=$2`, [parsedId.data]);
  if (!ticket.rowCount) return NextResponse.json({ message: "İş emri bulunamadı." }, { status: 404 });
  const activities = await tenantQuery(session.organizationId, `SELECT
    a.id::text,a.event_type,a.body,a.detail,a.created_at,u.name actor_name
    FROM service_ticket_activities a
    LEFT JOIN users u ON u.id=a.actor_user_id
    WHERE a.organization_id=$1 AND a.ticket_id=$2
    ORDER BY a.created_at DESC,a.id DESC LIMIT 200`, [parsedId.data]);
  return NextResponse.json({ ticket: ticket.rows[0], activities: activities.rows });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!["owner", "admin", "technician"].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }
  const parsedId = await ticketId(context);
  if (!parsedId.success) return NextResponse.json({ message: "Geçersiz iş emri kimliği." }, { status: 400 });
  const parsed = noteSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Not 2-4000 karakter olmalıdır." }, { status: 400 });
  const result = await tenantQuery(session.organizationId,
    `INSERT INTO service_ticket_activities (organization_id,ticket_id,actor_user_id,event_type,body)
     SELECT $1,id,$3,'note',$4 FROM service_tickets WHERE organization_id=$1 AND id=$2 RETURNING id::text`,
    [parsedId.data, session.userId, parsed.data.note]);
  if (!result.rowCount) return NextResponse.json({ message: "İş emri bulunamadı." }, { status: 404 });
  await auditEvent({ organizationId: session.organizationId, actorUserId: session.userId,
    action: "ticket.note.create", targetType: "service_ticket", targetId: parsedId.data,
    detail: { activityId: result.rows[0].id } });
  return NextResponse.json({ ok: true }, { status: 201 });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!['owner', 'admin', 'technician'].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }
  const parsedId = await ticketId(context);
  if (!parsedId.success) return NextResponse.json({ message: "Geçersiz iş emri kimliği." }, { status: 400 });
  const id = parsedId.data;
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Geçersiz güncelleme." }, { status: 400 });
  if (parsed.data.status === "cancelled") return NextResponse.json({ message: "İptal için web onayı gereklidir." }, { status: 403 });
  if (parsed.data.technicianId) {
    const technician = await tenantQuery(session.organizationId,
      `SELECT id FROM users WHERE organization_id=$1 AND id=$2 AND role IN ('owner','admin','technician') AND active`,
      [parsed.data.technicianId]);
    if (!technician.rowCount) return NextResponse.json({ message: "Teknisyen bulunamadı." }, { status: 400 });
  }
  const result = await tenantQuery<{ id: string; ticket_number: string }>(session.organizationId,
    `UPDATE service_tickets SET status=$3,
      assigned_technician_id=COALESCE($4,assigned_technician_id),
      resolved_at=CASE WHEN $3='resolved' THEN now() ELSE resolved_at END,
      closed_at=CASE WHEN $3='closed' THEN now() ELSE closed_at END,
      updated_at=now()
     WHERE organization_id=$1 AND id=$2 RETURNING id,ticket_number::text`,
    [id, parsed.data.status, parsed.data.technicianId ?? null]);
  if (!result.rowCount) return NextResponse.json({ message: "İş emri bulunamadı." }, { status: 404 });
  const ticket = result.rows[0];
  await tenantQuery(session.organizationId,
    `INSERT INTO service_ticket_activities (organization_id,ticket_id,actor_user_id,event_type,body,detail)
     VALUES ($1,$2,$3,'status',$4,$5::jsonb)`,
    [ticket.id, session.userId, "İş emri durumu güncellendi.", JSON.stringify({ status: parsed.data.status })]);
  await auditEvent({ organizationId: session.organizationId, actorUserId: session.userId,
    action: "ticket.update", targetType: "service_ticket", targetId: ticket.id,
    detail: { ticketNumber: ticket.ticket_number, status: parsed.data.status, technicianId: parsed.data.technicianId ?? null } });
  return NextResponse.json({ ok: true });
}