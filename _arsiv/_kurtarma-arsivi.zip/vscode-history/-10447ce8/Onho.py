"""
DeepPanda - USB Seri Port Servisi
COM portlarını tarar, otomatik bağlanır ve veri alışverişini yönetir.
"""

import serial
import serial.tools.list_ports
import time
import re
from typing import List, Optional, Tuple

class SerialService:
    """USB/COM Port yönetim sınıfı."""

    def __init__(self):
        self.ser: Optional[serial.Serial] = None
        self.connected_port: Optional[str] = None

    @staticmethod
    def list_available_ports() -> List[Tuple[str, str]]:
        """Sistemdeki aktif COM portlarını ve cihaz açıklamalarını döndürür."""
        try:
            ports = serial.tools.list_ports.comports()
            return [(p.device, p.description) for p in ports]
        except Exception:
            return []

    def auto_connect(self, baudrate: int = 9600) -> Tuple[bool, str]:
        """Sistemde bulunan ilk aktif USB seri portuna otomatik bağlanır."""
        available_ports = self.list_available_ports()
        if not available_ports:
            return False, "Takılı seri cihaz (COM Port) bulunamadı."

        for port_name, desc in available_ports:
            success, msg = self.connect(port_name, baudrate)
            if success:
                return True, f"Otomatik bağlandı: {port_name} ({desc})"

        return False, "Hiçbir porta bağlanılamadı."

    def connect(self, port: str, baudrate: int = 9600, timeout: float = 1.0) -> Tuple[bool, str]:
        """Belirtilen porta bağlanır."""
        self.disconnect()
        if not port or not port.strip():
            return False, "COM portu boş olamaz."
        if __import__("sys").platform.startswith("win") and not re.fullmatch(r"COM\d+", port.strip(), re.IGNORECASE):
            return False, "Windows üzerinde geçerli bir COM portu girin; örnek: COM3."
        try:
            baudrate = int(baudrate)
        except (TypeError, ValueError):
            return False, "Baud hızı sayı olmalıdır."
        if not 110 <= baudrate <= 4_000_000:
            return False, "Baud hızı geçersiz."
        try:
            self.ser = serial.Serial(port=port, baudrate=baudrate, timeout=timeout)
            if self.ser.is_open:
                self.connected_port = port
                return True, f"{port} portuna başarıyla bağlandı."
            return False, f"{port} portu açılamadı."
        except (serial.SerialException, OSError) as e:
            return False, f"Bağlantı hatası ({port}): {str(e)}"
        except Exception as e:
            return False, f"Beklenmedik hata ({port}): {str(e)}"

    def disconnect(self):
        """Mevcut bağlantıyı kapatır."""
        if self.ser:
            try:
                if self.ser.is_open:
                    self.ser.close()
            except Exception:
                pass
        self.ser = None
        self.connected_port = None

    def is_connected(self) -> bool:
        """Bağlantı durumunu döner."""
        return self.ser is not None and self.ser.is_open

    def send_data(self, data: str) -> bool:
        """Porta string veri gönderir."""
        if self.is_connected():
            try:
                # Buffer temizliği ve güvenli gönderim
                self.ser.reset_output_buffer()
                self.ser.write((data + "\n").encode('utf-8'))
                self.ser.flush()
                return True
            except (serial.SerialException, OSError):
                self.disconnect()
                return False
            except Exception:
                return False
        return False

    def read_line(self) -> Optional[str]:
        """Porttan bir satır veri okur."""
        if self.is_connected():
            try:
                if self.ser.in_waiting > 0:
                    line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                    return line
            except (serial.SerialException, OSError):
                self.disconnect()
            except Exception:
                pass
        return None
