"""Gumroad için ürün hazırlama ve paketleme otomasyonu."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


class GumroadAutopilot:
    """Mevcut proje klasörünü Gumroad'a uygun ürün paketine dönüştürür."""

    def __init__(self, workspace_root: str | None = None):
        self.workspace_root = Path(workspace_root or ".").resolve()

    def build_product_bundle(
        self,
        project_dir: str,
        product_name: str,
        price: float,
        description: str,
        thumbnail: str | None = None,
    ) -> Dict[str, Any]:
        source = Path(project_dir).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Proje dizini bulunamadı: {project_dir}")

        bundle_dir = source / "gumroad_bundle"
        bundle_dir.mkdir(exist_ok=True)

        zip_path = source / f"{source.name}.zip"
        shutil.make_archive(str(source / source.name), "zip", root_dir=str(source))

        manifest = {
            "product_name": product_name,
            "price": float(price),
            "description": description,
            "thumbnail": thumbnail,
            "bundle_dir": str(bundle_dir),
            "archive": str(zip_path),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

        bundle_manifest_path = source / "gumroad_bundle.json"
        bundle_manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

        package_info = {
            "status": "bundled",
            "project_dir": str(source),
            "product": {
                "name": product_name,
                "price": float(price),
                "description": description,
            },
            "bundle_manifest": str(bundle_manifest_path),
            "archive": str(zip_path),
        }

        return package_info

    def build_promotional_bundle(
        self,
        project_dir: str,
        product_name: str,
        price: float,
        description: str,
    ) -> Dict[str, Any]:
        """Kaynak kodu ve dokümantasyonu hassas/runtime dosyalar olmadan paketler."""
        source = Path(project_dir).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Proje dizini bulunamadı: {project_dir}")

        output_dir = self.workspace_root / "generated_products" / "deeppanda-promotional"
        staging_dir = output_dir / "DeepPanda-Promotional"
        if output_dir.exists():
            shutil.rmtree(output_dir)
        staging_dir.mkdir(parents=True)

        excluded_names = {
            ".env",
            ".git",
            ".pytest_cache",
            "__pycache__",
            ".aider.chat.history.md",
            ".aider.input.history",
            "backups",
            "build",
            "dist",
            "generated_products",
            "incoming_packages",
            "ollama-models",
            "archive",
            "android-client",
            "app_settings.json",
            "assets",
            "control-plane",
            "installer",
            "package_install_history.json",
            "rollback_plans.json",
            "systemcore.db",
            "tools",
            "gui_error.log",
        }
        excluded_suffixes = {".db", ".log", ".zip", ".pyc", ".pyo", ".pyd"}

        def ignore_entries(directory: str, names: List[str]) -> List[str]:
            ignored: List[str] = []
            for name in names:
                path = Path(directory) / name
                if name in excluded_names or path.suffix.lower() in excluded_suffixes:
                    ignored.append(name)
            return ignored

        shutil.copytree(source, staging_dir, dirs_exist_ok=True, ignore=ignore_entries)
        (staging_dir / "PROMOTIONAL_BUNDLE_NOTICE.md").write_text(
            "# DeepPanda Promotional Bundle\n\n"
            "Bu paket tanıtım ve değerlendirme amaçlı kaynak kodu sürümüdür. "
            "Yerel sırlar, çalışma zamanı verileri, modeller ve derleme çıktıları dahil edilmemiştir.\n\n"
            "Bu paket üçüncü taraf bağımlılıkların lisanslarını devretmez. "
            "Bağımlılıkları kurmadan ve ürünü dağıtmadan önce requirements.txt içindeki lisans koşullarını kontrol edin.\n",
            encoding="utf-8",
        )
        manifest = {
            "product_name": product_name,
            "price": float(price),
            "description": description,
            "source": str(source),
            "archive": str(output_dir / "deeppanda-promotional.zip"),
            "excluded_categories": sorted(excluded_names),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        manifest_path = output_dir / "gumroad_promotional_bundle.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        archive_path = Path(
            shutil.make_archive(
                str(output_dir / "deeppanda-promotional"),
                "zip",
                root_dir=str(output_dir),
                base_dir=staging_dir.name,
            )
        )
        return {
            "status": "bundled",
            "project_dir": str(source),
            "bundle_dir": str(staging_dir),
            "manifest": str(manifest_path),
            "archive": str(archive_path),
            "excluded_categories": sorted(excluded_names),
        }

    def open_browser_session(self, url: str = "https://gumroad.com") -> Dict[str, Any]:
        """Tarayıcı üzerinden Gumroad sayfasını açmayı dener."""
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["cmd", "/c", "start", "", url], shell=True)
            else:
                subprocess.Popen(["xdg-open", url])
            return {"status": "opened", "url": url}
        except Exception as exc:  # pragma: no cover
            return {"status": "error", "message": str(exc)}

    def list_ready_products(self) -> List[Dict[str, Any]]:
        """Workspace içindeki hazır ürün paketlerini listeler."""
        results: List[Dict[str, Any]] = []
        for child in sorted(self.workspace_root.iterdir(), key=lambda p: p.name.lower()):
            if not child.is_dir():
                continue
            manifest_path = child / "gumroad_bundle.json"
            if manifest_path.exists():
                try:
                    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
                    results.append({"project": child.name, "product_name": payload.get("product_name"), "price": payload.get("price")})
                except Exception:
                    results.append({"project": child.name, "product_name": child.name, "price": None})
        return results
