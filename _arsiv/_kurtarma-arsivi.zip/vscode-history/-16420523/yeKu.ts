import { createPrivateKey, createPublicKey, randomUUID, sign } from "crypto";
import { readFile } from "fs/promises";
import { pathToFileURL } from "url";
import { pool, transaction } from "../src/lib/db";

type Plan = "annual" | "unlimited";
type Job = {
  id: string;
  organization_id: string;
  payment_order_id: string;
  device_id: string | null;
  plan: Plan;
  installation_id: string | null;
  customer: string;
};

type LicensePayload = {
  customer: string;
  expires_at: number | null;
  issued_at: number;
  license_id: string;
  machine_id: string;
  plan: Plan;
  version: 1;
};

function base64Url(value: Buffer) {
  return value.toString("base64url");
}

export function normalizeMachineId(value: string) {
  const machineId = String(value ?? "").toUpperCase().replace(/[^0-9A-F]/g, "");
  if (machineId.length !== 64) throw new Error("Kurulum kimliği 64 hexadecimal karakter içermeli.");
  return machineId;
}

export function publicKeyBase64(privateKeyPem: Buffer) {
  const jwk = createPublicKey(createPrivateKey(privateKeyPem)).export({ format: "jwk" });
  if (!jwk.x) throw new Error("Ed25519 açık anahtarı okunamadı.");
  return Buffer.from(jwk.x, "base64url").toString("base64");
}

export function generateLicense(
  privateKeyPem: Buffer,
  customer: string,
  plan: Plan,
  installationId: string,
  nowSeconds = Math.floor(Date.now() / 1000),
) {
  const normalizedCustomer = customer.trim();
  if (normalizedCustomer.length < 2) throw new Error("Müşteri adı zorunlu.");
  const payload: LicensePayload = {
    customer: normalizedCustomer,
    expires_at: plan === "annual" ? nowSeconds + 365 * 24 * 60 * 60 : null,
    issued_at: nowSeconds,
    license_id: randomUUID().replaceAll("-", ""),
    machine_id: normalizeMachineId(installationId),
    plan,
    version: 1,
  };
  const raw = Buffer.from(JSON.stringify(payload), "utf8");
  const signature = sign(null, raw, createPrivateKey(privateKeyPem));
  return { key: `VANA1.${base64Url(raw)}.${base64Url(signature)}`, payload };
}

async function claimAndIssue(privateKeyPem: Buffer) {
  return transaction(async (client) => {
    const result = await client.query<Job>(
      `SELECT j.id,j.organization_id,j.payment_order_id,j.device_id,j.plan,
              d.installation_id,o.name customer
         FROM license_issuance_jobs j
         LEFT JOIN devices d ON d.id=j.device_id AND d.organization_id=j.organization_id
         JOIN organizations o ON o.id=j.organization_id
        WHERE j.status='pending'
        ORDER BY j.created_at
        FOR UPDATE OF j SKIP LOCKED LIMIT 1`,
    );
    const job = result.rows[0];
    if (!job) return false;
    try {
      if (!job.device_id || !job.installation_id) throw new Error("Lisans işi geçerli bir cihaza bağlı değil.");
      const issued = generateLicense(privateKeyPem, job.customer, job.plan, job.installation_id);
      await client.query(
        `INSERT INTO licenses
          (organization_id,device_id,license_id,license_key,plan,status,issued_at,expires_at)
         VALUES ($1,$2,$3,$4,$5,'active',to_timestamp($6),
                 CASE WHEN $7::bigint IS NULL THEN NULL ELSE to_timestamp($7) END)`,
        [job.organization_id, job.device_id, issued.payload.license_id, issued.key, job.plan,
          issued.payload.issued_at, issued.payload.expires_at],
      );
      await client.query(
        `UPDATE license_issuance_jobs SET status='issued',error_message=NULL,completed_at=now()
          WHERE id=$1`, [job.id],
      );
      await client.query(
        `UPDATE organizations SET plan=$2,license_ends_at=
          CASE WHEN $3::bigint IS NULL THEN NULL ELSE to_timestamp($3) END WHERE id=$1`,
        [job.organization_id, job.plan, issued.payload.expires_at],
      );
      await client.query(
        `INSERT INTO audit_events (organization_id,action,target_type,target_id,detail)
         VALUES ($1,'license.issued','license',$2,$3::jsonb)`,
        [job.organization_id, issued.payload.license_id, JSON.stringify({ plan: job.plan, deviceId: job.device_id })],
      );
    } catch (error) {
      await client.query(
        `UPDATE license_issuance_jobs SET status='failed',error_message=$2,completed_at=now() WHERE id=$1`,
        [job.id, String((error as Error).message).slice(0, 1000)],
      );
    }
    return true;
  });
}

async function main() {
  const privateKeyPath = process.env.LICENSE_PRIVATE_KEY_PATH;
  const expectedPublicKey = process.env.LICENSE_PUBLIC_KEY_B64;
  if (!privateKeyPath) throw new Error("LICENSE_PRIVATE_KEY_PATH zorunlu.");
  if (!expectedPublicKey) throw new Error("LICENSE_PUBLIC_KEY_B64 zorunlu.");
  const privateKeyPem = await readFile(privateKeyPath);
  if (publicKeyBase64(privateKeyPem) !== expectedPublicKey.trim()) {
    throw new Error("Lisans özel anahtarı masaüstü açık anahtarıyla eşleşmiyor.");
  }
  let processed = 0;
  while (await claimAndIssue(privateKeyPem)) processed += 1;
  console.log(`Lisans worker tamamlandı: ${processed} iş işlendi.`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((error) => {
    console.error(`Lisans worker hatası: ${(error as Error).message}`);
    process.exitCode = 1;
  }).finally(() => pool.end());
}
