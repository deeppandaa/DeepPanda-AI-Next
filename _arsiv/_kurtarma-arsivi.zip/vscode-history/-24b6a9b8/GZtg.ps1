$ErrorActionPreference = "Stop"
$body = @{
    model = "vana-yardimci"
    messages = @(
        @{ role = "user"; content = "PostgreSQL 5432 portu doluysa ne yapmaliyim? Iki cumleyle cevapla." }
    )
    stream = $false
} | ConvertTo-Json -Depth 5

$response = Invoke-RestMethod `
    -Uri "http://127.0.0.1:11434/api/chat" `
    -Method Post `
    -ContentType "application/json" `
    -Body $body

$response.message.content
