import { createHash } from "crypto";
import { pool } from "../src/lib/db";

const installationId = `legacy-${createHash("sha256").update("deeppanda-legacy-live-test").digest("hex").slice(0, 40)}`;

async function main() {
  const result = await pool.query("DELETE FROM devices WHERE installation_id=$1", [installationId]);
  const remaining = await pool.query<{ count: string }>(
    "SELECT count(*)::text count FROM devices WHERE installation_id=$1",
    [installationId],
  );
  if (remaining.rows[0].count !== "0") throw new Error("Legacy test device cleanup failed");
  console.log(`Legacy test cleanup OK: ${result.rowCount ?? 0} device removed`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(() => pool.end());