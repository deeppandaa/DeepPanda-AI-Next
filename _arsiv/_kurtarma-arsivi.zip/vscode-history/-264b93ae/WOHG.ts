import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import { auditEvent } from "@/lib/audit";

const updateSchema = z.object({
  name: z.string().trim().min(2).max(200).optional(),
  contactEmail: z.string().email().optional().or(z.literal("")),
  contactPhone: z.string().trim().max(40).optional().or(z.literal("")),
  notes: z.string().trim().max(2000).optional(),
});

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!["owner", "admin", "technician"].includes(session.role)) {
    return NextResponse.json({ message: "Yetkiniz yok." }, { status: 403 });
  }

  const { id } = await context.params;
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ message: "Geçersiz güncelleme verisi." }, { status: 400 });
  }

  const existingRes = await tenantQuery<{ id: string; name: string }>(
    session.organizationId,
    `SELECT id, name FROM customers WHERE organization_id=$1 AND id=$2`,
    [id]
  );
  if (existingRes.rows.length === 0) {
    return NextResponse.json({ message: "Müşteri bulunamadı." }, { status: 404 });
  }

  await tenantQuery(
    session.organizationId,
    `UPDATE customers SET
      name = COALESCE($3, name),
      contact_email = COALESCE($4, contact_email),
      contact_phone = COALESCE($5, contact_phone),
      notes = COALESCE($6, notes)
     WHERE organization_id=$1 AND id=$2`,
    [
      id,
      parsed.data.name ?? null,
      parsed.data.contactEmail !== undefined ? (parsed.data.contactEmail || null) : null,
      parsed.data.contactPhone !== undefined ? (parsed.data.contactPhone || null) : null,
      parsed.data.notes ?? null,
    ]
  );

  await auditEvent({
    organizationId: session.organizationId,
    actorUserId: session.userId,
    action: "customer.update",
    targetType: "customer",
    targetId: id,
    detail: { name: parsed.data.name ?? existingRes.rows[0].name },
  });

  return NextResponse.json({ message: "Müşteri güncellendi." });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ message: "Yetkisiz." }, { status: 401 });
  if (!["owner", "admin"].includes(session.role)) {
    return NextResponse.json({ message: "Müşteri silme yetkiniz yok." }, { status: 403 });
  }

  const { id } = await context.params;
  const existingRes = await tenantQuery<{ id: string; name: string }>(
    session.organizationId,
    `SELECT id, name FROM customers WHERE organization_id=$1 AND id=$2`,
    [id]
  );
  if (existingRes.rows.length === 0) {
    return NextResponse.json({ message: "Müşteri bulunamadı." }, { status: 404 });
  }

  await tenantQuery(session.organizationId, `DELETE FROM customers WHERE organization_id=$1 AND id=$2`, [id]);

  await auditEvent({
    organizationId: session.organizationId,
    actorUserId: session.userId,
    action: "customer.delete",
    targetType: "customer",
    targetId: id,
    detail: { name: existingRes.rows[0].name },
  });

  return NextResponse.json({ message: "Müşteri silindi." });
}
