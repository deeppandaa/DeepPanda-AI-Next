# DeepPanda Medikal RMM Uygulama Yol Haritasi

Tarih: 2026-08-26

## Hedef

DeepPanda'yi tek bir urunde birlestirmek:

1. IT Remote Monitoring and Management
2. Medikal/DICOM cihaz entegrasyonu
3. Saha teknik servis ve is emri yonetimi

## Mevcut ve dogrulanmis temel

- Multi-tenant organizasyon izolasyonu
- Owner, admin, technician, viewer RBAC
- JWT oturumu ve bcrypt parola dogrulamasi
- Degistirilemez operasyon audit kayitlari
- Windows agent heartbeat ve cihaz risk skoru
- Uzak destek onayi, dosya aktarimi ve guvenli komut akisi
- Lisans, odeme, musteri ve marka yonetimi
- Tasinabilir PostgreSQL ve standalone Next.js panel
- Servis is emirleri: oncelik, SLA, musteri/cihaz/teknisyen atama, durum akisi ve audit

## Faz 1 - Teknik Servis Operasyonu

Durum: Baslatildi, ilk dikey dilim tamamlandi.

- [x] Tenant-izole is emri veri modeli
- [x] Dusuk/normal/yuksek/kritik oncelik ve otomatik SLA
- [x] Musteri, cihaz ve teknisyen baglantilari
- [x] Is emri listeleme, filtreleme, olusturma ve durum guncelleme
- [x] Audit olaylari ve dashboard acik is emri sayaci
- [ ] Is emri ayrinti/zaman cizelgesi ve teknisyen notlari
- [ ] QR/seri numarasi ile cihaz kabul
- [ ] Garanti, yedek parca, stok hareketleri
- [ ] Dijital imza ve PDF servis raporu
- [ ] SLA eskalasyonu ve bildirim kuyrugu

## Faz 2 - RMM Control Plane

- [ ] WebSocket veya gRPC komut kuyrugu
- [ ] Agent komut sonucu ve teslim makbuzu
- [ ] Web terminali icin oturum bazli izin ve kayit
- [ ] Uzak ekran akisini panel onay sistemiyle birlestirme
- [ ] Linux servis agenti
- [ ] Android arka plan servis agenti
- [ ] Imzali otomatik agent guncellemesi

## Faz 3 - Medikal Cihaz Envanteri

- [x] Medikal cihaz ve zaman serisi telemetri veri modeli
- [x] Donanim soyutlama katmani (HAL)
- [x] Deterministik DR dedektor simulatoru
- [x] Localhost UDP IPC adaptoru
- [x] Surumlu `medical-telemetry/v1` JSON veri sozlesmesi
- [x] Agent heartbeat ile tenant-izole telemetri saklama
- [ ] Modalite, uretici, model ve seri numarasi envanter ekrani
- [ ] Kalibrasyon ve periyodik bakim takvimi
- [ ] Garanti ve sozlesme/SLA baglantisi
- [ ] USB-UART/RS232 baglanti profilleri ve vendor adaptoru
- [ ] Vendor protokol adaptoru arayuzu
- [x] Fiziksel cihazdan once simulator ve test fixture'lari

## Faz 4 - DICOM/PACS

- [ ] DICOM metadata alma ve dogrulama servisi
- [ ] C-ECHO, C-STORE ve Storage Commitment test akisi
- [ ] Tenant bazli AE Title ve PACS hedefleri
- [ ] DICOM de-identification profili
- [ ] Sifreli nesne depolama ve saklama politikalari
- [ ] 12/16-bit viewer, Window Level/Width ve histogram
- [ ] Yetkili erisim ve goruntu audit izi

## Faz 5 - Uyum ve Canli Altyapi

- [ ] KVKK veri envanteri, saklama/silme politikalari ve acik riza metinleri
- [ ] Tehdit modeli, SBOM, SAST/DAST ve bagimsiz sizma testi
- [ ] HA PostgreSQL, Redis, nesne depolama ve otomatik yedekleme
- [ ] Prometheus/Grafana ve alarm yonetimi
- [ ] E-posta/SMS saglayici entegrasyonu
- [ ] Alan adi, kurumsal TLS ve felaket kurtarma tatbikati
- [ ] CE/MDR/UTS kapsam siniflandirmasi (tani ozelligi varsa)

## Kalite kapilari

Her faz icin zorunlu:

- Tenant sizinti testleri
- RBAC negatif testleri
- Audit kaydi dogrulamasi
- Migration geri uyumlulugu
- Yedekten geri donus testi
- Masaustu ve mobil gorunum testi
- Gercek cihazdan once simulator testi
- Yuksek riskli islemlerde acik kullanici onayi
