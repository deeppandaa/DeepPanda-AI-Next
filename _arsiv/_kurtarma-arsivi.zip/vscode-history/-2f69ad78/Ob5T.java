package com.systemcore.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MeetingActivity extends Activity {
    public static final String EXTRA_MEETING_URL = "meeting_url";
    private static final int MEDIA_PERMISSION_REQUEST = 8101;
    private static final String ALLOWED_HOST = "meet.jit.si";
    private static final String ALLOWED_ROOM_PREFIX = "/DeepPanda-";

    private WebView meetingView;
    private PermissionRequest pendingWebPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String meetingUrl = getIntent().getStringExtra(EXTRA_MEETING_URL);
        if (!isAllowedMeetingUrl(meetingUrl)) {
            Toast.makeText(this, "Gecersiz gorusme adresi", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        meetingView = new WebView(this);
        meetingView.setBackgroundColor(Color.BLACK);
        WebSettings settings = meetingView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " DeepPandaMobileMeeting/1.10");

        meetingView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAllowedNavigation(request.getUrl());
            }
        });
        meetingView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermission == request) pendingWebPermission = null;
            }
        });
        setContentView(meetingView);
        meetingView.loadUrl(meetingUrl + "#config.prejoinPageEnabled=false&config.disableDeepLinking=true");
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (!ALLOWED_HOST.equalsIgnoreCase(request.getOrigin().getHost())) {
            request.deny();
            return;
        }
        pendingWebPermission = request;
        List<String> missing = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (missing.isEmpty()) {
            grantPendingWebPermission();
        } else {
            requestPermissions(missing.toArray(new String[0]), MEDIA_PERMISSION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MEDIA_PERMISSION_REQUEST || pendingWebPermission == null) return;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                pendingWebPermission.deny();
                pendingWebPermission = null;
                Toast.makeText(this, "Kamera ve mikrofon izni verilmedi", Toast.LENGTH_LONG).show();
                return;
            }
        }
        grantPendingWebPermission();
    }

    private void grantPendingWebPermission() {
        if (pendingWebPermission == null) return;
        List<String> allowed = new ArrayList<>();
        for (String resource : pendingWebPermission.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    || PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                allowed.add(resource);
            }
        }
        if (allowed.isEmpty()) {
            pendingWebPermission.deny();
        } else {
            pendingWebPermission.grant(allowed.toArray(new String[0]));
        }
        pendingWebPermission = null;
    }

    private boolean isAllowedMeetingUrl(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        Uri uri = Uri.parse(value);
        return "https".equalsIgnoreCase(uri.getScheme())
                && ALLOWED_HOST.equalsIgnoreCase(uri.getHost())
                && uri.getPath() != null
                && uri.getPath().startsWith(ALLOWED_ROOM_PREFIX);
    }

    private boolean isAllowedNavigation(Uri uri) {
        return uri != null
                && "https".equalsIgnoreCase(uri.getScheme())
                && ALLOWED_HOST.equalsIgnoreCase(uri.getHost());
    }

    @Override
    public void onBackPressed() {
        if (meetingView != null && meetingView.canGoBack()) {
            meetingView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingWebPermission != null) {
            pendingWebPermission.deny();
            pendingWebPermission = null;
        }
        if (meetingView != null) {
            meetingView.stopLoading();
            meetingView.loadUrl("about:blank");
            meetingView.clearHistory();
            meetingView.removeAllViews();
            meetingView.destroy();
            meetingView = null;
        }
        super.onDestroy();
    }
}