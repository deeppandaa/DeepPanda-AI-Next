$node = "C:\Users\emre\Desktop\DeepPanda-Proje\DeepPanda\DeepPanda-Panel\node\node.exe"
$webDir = "C:\Users\emre\Desktop\DeepPanda-Proje\DeepPanda\DeepPanda-Panel\web"
$env:PORT = "3101"
$env:HOSTNAME = "127.0.0.1"

$p = Start-Process -FilePath $node -ArgumentList "server.js" -WorkingDirectory $webDir -PassThru
Start-Sleep -Seconds 3

try {
    $res = Invoke-WebRequest -Uri "http://127.0.0.1:3101/login" -UseBasicParsing
    Write-Host "LOGIN_STATUS: $($res.StatusCode)"
    $matches = [regex]::Matches($res.Content, 'href="([^"]+)"')
    foreach ($m in $matches) {
        $h = $m.Groups[1].Value
        if ($h.Contains("_next")) {
            try {
                $r = Invoke-WebRequest -Uri "http://127.0.0.1:3101$h" -UseBasicParsing
                Write-Host "ASSET_OK: $h (Size: $($r.Content.Length))"
            } catch {
                Write-Host "ASSET_FAIL: $h (Error: $($_.Exception.Message))"
            }
        }
    }
} finally {
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
}
