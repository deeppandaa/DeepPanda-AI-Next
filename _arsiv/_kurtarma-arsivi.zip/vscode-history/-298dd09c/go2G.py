"""Program catalog and installed-program inventory for DeepPanda."""

from __future__ import annotations

import threading
from typing import Any

import customtkinter as ctk

from services.program_inventory_service import ProgramInventoryService


class ProgramsView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self._programs: list[dict[str, Any]] = []

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=22, pady=(20, 8), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Programlar",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color="#F2F5F7",
        ).grid(row=0, column=0, sticky="w")
        self.refresh_button = ctk.CTkButton(
            header,
            text="Yenile",
            width=96,
            command=self.refresh,
        )
        self.refresh_button.grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(
            self,
            text="DeepPanda araclari ve bilgisayarda kurulu programlar.",
            text_color="#AEB9C4",
        ).grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        controls = ctk.CTkFrame(self, fg_color="#273544", corner_radius=6)
        controls.grid(row=2, column=0, padx=22, pady=(0, 10), sticky="ew")
        controls.grid_columnconfigure(0, weight=1)
        self.search_entry = ctk.CTkEntry(
            controls,
            placeholder_text="Program adi veya yayinci ara...",
            height=38,
        )
        self.search_entry.grid(row=0, column=0, padx=12, pady=12, sticky="ew")
        self.search_entry.bind("<KeyRelease>", lambda _event: self._render_programs())
        self.status_label = ctk.CTkLabel(controls, text="Hazir", text_color="#AEB9C4")
        self.status_label.grid(row=0, column=1, padx=(8, 14), pady=12)

        self.results = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.results.grid(row=3, column=0, padx=14, pady=(0, 16), sticky="nsew")
        self.results.grid_columnconfigure(0, weight=1)

        self.refresh()

    def refresh(self) -> None:
        self.refresh_button.configure(state="disabled", text="Taraniyor")
        self.status_label.configure(text="Programlar taraniyor...")
        threading.Thread(target=self._scan_programs, daemon=True).start()

    def _scan_programs(self) -> None:
        result = ProgramInventoryService.scan_installed_programs()
        self.after(0, lambda: self._apply_scan_result(result))

    def _apply_scan_result(self, result: dict[str, Any]) -> None:
        self.refresh_button.configure(state="normal", text="Yenile")
        if result.get("status") != "success":
            self._programs = []
            self.status_label.configure(text=str(result.get("message", "Tarama basarisiz.")))
        else:
            programs = result.get("programs", [])
            self._programs = programs if isinstance(programs, list) else []
            self.status_label.configure(text=f"{len(self._programs)} program")
        self._render_programs()

    def _render_programs(self) -> None:
        for widget in self.results.winfo_children():
            widget.destroy()

        query = self.search_entry.get().strip().casefold()
        filtered = [
            program
            for program in self._programs
            if not query
            or query in str(program.get("name", "")).casefold()
            or query in str(program.get("publisher", "")).casefold()
        ]
        if not filtered:
            ctk.CTkLabel(
                self.results,
                text="Eslesen program bulunamadi.",
                text_color="#AEB9C4",
            ).grid(row=0, column=0, padx=12, pady=28)
            return

        for row, program in enumerate(filtered):
            item = ctk.CTkFrame(self.results, fg_color="#273544", corner_radius=6)
            item.grid(row=row, column=0, padx=8, pady=5, sticky="ew")
            item.grid_columnconfigure(0, weight=1)
            name = str(program.get("name", "Bilinmeyen program"))
            version = str(program.get("version", "") or "Surum bilinmiyor")
            publisher = str(program.get("publisher", "") or "Yayinci bilinmiyor")
            ctk.CTkLabel(
                item,
                text=name,
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color="#F2F5F7",
                anchor="w",
            ).grid(row=0, column=0, padx=14, pady=(11, 2), sticky="ew")
            ctk.CTkLabel(
                item,
                text=f"{publisher}  |  {version}",
                text_color="#AEB9C4",
                anchor="w",
            ).grid(row=1, column=0, padx=14, pady=(0, 11), sticky="ew")
