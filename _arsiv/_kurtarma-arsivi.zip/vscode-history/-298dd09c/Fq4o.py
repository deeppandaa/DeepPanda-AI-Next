"""Program catalog and installed-program inventory for DeepPanda."""

from __future__ import annotations

import threading
from tkinter import messagebox
from typing import Any

import customtkinter as ctk

from services.program_inventory_service import ProgramInventoryService


class ProgramsView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=parent.cget("fg_color"))
        self.grid(row=0, column=0, sticky="nsew")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self._programs: list[dict[str, Any]] = []
        self._selected_program: dict[str, Any] | None = None

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, padx=22, pady=(20, 8), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Programlar",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color="#F2F5F7",
        ).grid(row=0, column=0, sticky="w")
        self.refresh_button = ctk.CTkButton(
            header,
            text="Yenile",
            width=96,
            command=self.refresh,
        )
        self.refresh_button.grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(
            self,
            text="DeepPanda araclari ve bilgisayarda kurulu programlar.",
            text_color="#AEB9C4",
        ).grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        controls = ctk.CTkFrame(self, fg_color="#273544", corner_radius=6)
        controls.grid(row=2, column=0, padx=22, pady=(0, 10), sticky="ew")
        controls.grid_columnconfigure(0, weight=1)
        self.search_entry = ctk.CTkEntry(
            controls,
            placeholder_text="Program adi veya yayinci ara...",
            height=38,
        )
        self.search_entry.grid(row=0, column=0, padx=12, pady=12, sticky="ew")
        self.search_entry.bind("<KeyRelease>", lambda _event: self._render_programs())
        self.status_label = ctk.CTkLabel(controls, text="Hazir", text_color="#AEB9C4")
        self.status_label.grid(row=0, column=1, padx=(8, 14), pady=12)

        self.results = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.results.grid(row=3, column=0, padx=14, pady=(0, 8), sticky="nsew")
        self.results.grid_columnconfigure(0, weight=1)

        self.details = ctk.CTkFrame(self, fg_color="#1E2A36", corner_radius=6)
        self.details.grid(row=4, column=0, padx=22, pady=(0, 16), sticky="ew")
        self.details.grid_columnconfigure(0, weight=1)
        self.detail_name = ctk.CTkLabel(
            self.details,
            text="Bir program secin",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#F2F5F7",
            anchor="w",
        )
        self.detail_name.grid(row=0, column=0, columnspan=4, padx=14, pady=(12, 2), sticky="ew")
        self.detail_info = ctk.CTkLabel(
            self.details,
            text="Ayrintilar ve yonetim secenekleri burada gorunur.",
            text_color="#AEB9C4",
            anchor="w",
            justify="left",
        )
        self.detail_info.grid(row=1, column=0, columnspan=4, padx=14, pady=(0, 10), sticky="ew")
        self.uninstall_button = ctk.CTkButton(
            self.details,
            text="Guvenli Kaldir",
            state="disabled",
            command=self._confirm_uninstall,
        )
        self.uninstall_button.grid(row=2, column=0, padx=(14, 6), pady=(0, 12), sticky="w")
        self.modify_button = ctk.CTkButton(
            self.details,
            text="Degistir / Onar",
            state="disabled",
            fg_color="#41586C",
            command=self._confirm_modify,
        )
        self.modify_button.grid(row=2, column=1, padx=6, pady=(0, 12), sticky="w")
        self.residual_button = ctk.CTkButton(
            self.details,
            text="Kalinti Tara",
            state="disabled",
            fg_color="#41586C",
            command=self._preview_residuals,
        )
        self.residual_button.grid(row=2, column=2, padx=6, pady=(0, 12), sticky="w")

        self.refresh()

    def refresh(self) -> None:
        self._select_program(None)
        self.refresh_button.configure(state="disabled", text="Taraniyor")
        self.status_label.configure(text="Programlar taraniyor...")
        threading.Thread(target=self._scan_programs, daemon=True).start()

    def _scan_programs(self) -> None:
        result = ProgramInventoryService.scan_installed_programs()
        self.after(0, lambda: self._apply_scan_result(result))

    def _apply_scan_result(self, result: dict[str, Any]) -> None:
        self.refresh_button.configure(state="normal", text="Yenile")
        if result.get("status") != "success":
            self._programs = []
            self.status_label.configure(text=str(result.get("message", "Tarama basarisiz.")))
        else:
            programs = result.get("programs", [])
            self._programs = programs if isinstance(programs, list) else []
            self.status_label.configure(text=f"{len(self._programs)} program")
        self._render_programs()

    def _render_programs(self) -> None:
        for widget in self.results.winfo_children():
            widget.destroy()

        query = self.search_entry.get().strip().casefold()
        filtered = [
            program
            for program in self._programs
            if not query
            or query in str(program.get("name", "")).casefold()
            or query in str(program.get("publisher", "")).casefold()
        ]
        if not filtered:
            ctk.CTkLabel(
                self.results,
                text="Eslesen program bulunamadi.",
                text_color="#AEB9C4",
            ).grid(row=0, column=0, padx=12, pady=28)
            return

        for row, program in enumerate(filtered):
            item = ctk.CTkFrame(self.results, fg_color="#273544", corner_radius=6)
            item.grid(row=row, column=0, padx=8, pady=5, sticky="ew")
            item.grid_columnconfigure(0, weight=1)
            name = str(program.get("name", "Bilinmeyen program"))
            version = str(program.get("version", "") or "Surum bilinmiyor")
            publisher = str(program.get("publisher", "") or "Yayinci bilinmiyor")
            ctk.CTkLabel(
                item,
                text=name,
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color="#F2F5F7",
                anchor="w",
            ).grid(row=0, column=0, padx=14, pady=(11, 2), sticky="ew")
            ctk.CTkLabel(
                item,
                text=f"{publisher}  |  {version}",
                text_color="#AEB9C4",
                anchor="w",
            ).grid(row=1, column=0, padx=14, pady=(0, 11), sticky="ew")
            ctk.CTkButton(
                item,
                text="Incele",
                width=84,
                fg_color="#41586C",
                command=lambda selected=program: self._select_program(selected),
            ).grid(row=0, column=1, rowspan=2, padx=12, pady=10)

    def _select_program(self, program: dict[str, Any] | None) -> None:
        self._selected_program = program
        if program is None:
            self.detail_name.configure(text="Bir program secin")
            self.detail_info.configure(text="Ayrintilar ve yonetim secenekleri burada gorunur.")
            self.uninstall_button.configure(state="disabled")
            self.modify_button.configure(state="disabled")
            self.residual_button.configure(state="disabled")
            return

        size_kb = self._number(program.get("estimated_size_kb"))
        size_text = self._format_size(size_kb * 1024) if size_kb else "Bilinmiyor"
        location = str(program.get("install_location", "") or "Bilinmiyor")
        install_date = self._format_date(program.get("install_date", ""))
        self.detail_name.configure(text=str(program.get("name", "Bilinmeyen program")))
        self.detail_info.configure(
            text=(
                f"Yayinci: {program.get('publisher') or 'Bilinmiyor'}   |   "
                f"Surum: {program.get('version') or 'Bilinmiyor'}   |   "
                f"Boyut: {size_text}   |   Kurulum: {install_date}\n"
                f"Konum: {location}"
            )
        )
        self.uninstall_button.configure(
            state="normal" if program.get("uninstall_string") else "disabled"
        )
        self.modify_button.configure(state="normal" if program.get("modify_path") else "disabled")
        plan = ProgramInventoryService.residual_plan(program)
        can_scan = bool(plan.get("files") or plan.get("registry_entries"))
        self.residual_button.configure(state="normal" if can_scan else "disabled")

    def _confirm_uninstall(self) -> None:
        program = self._selected_program
        if not program:
            return
        name = str(program.get("name", "Bu program"))
        if not messagebox.askyesno(
            "Guvenli kaldirma",
            f"{name} icin kayitli kaldirici baslatilsin mi?\n\n"
            "Programin kendi kaldirma sihirbazi acilacaktir.",
            parent=self,
        ):
            return
        result = ProgramInventoryService.launch_registered_action(program, "uninstall")
        self._show_action_result(result)

    def _confirm_modify(self) -> None:
        program = self._selected_program
        if not program:
            return
        result = ProgramInventoryService.launch_registered_action(program, "modify")
        self._show_action_result(result)

    def _preview_residuals(self) -> None:
        program = self._selected_program
        if not program:
            return
        plan = ProgramInventoryService.residual_plan(program)
        items = [*(str(value) for value in plan.get("files", []))]
        items.extend(str(value) for value in plan.get("registry_entries", []))
        if not items:
            messagebox.showinfo("Kalinti analizi", "Guvenle eslestirilen kalinti bulunamadi.", parent=self)
            return
        preview = "\n".join(f"- {value}" for value in items)
        if not messagebox.askyesno(
            "Kalinti onizlemesi",
            "Yalniz asagidaki kesin eslesmeler temizlenecek:\n\n"
            f"{preview}\n\nDevam ederseniz tum ogeler once DeepPanda yedegine tasinir.",
            parent=self,
        ):
            return
        if not messagebox.askyesno(
            "Zorla kaldirmayi onayla",
            "Bu islem normal kaldirma basarisiz oldugunda kullanilmalidir. "
            "Yedekli temizleme baslatilsin mi?",
            icon="warning",
            parent=self,
        ):
            return
        self._set_actions_enabled(False)
        self.status_label.configure(text="Kalintilar yedeklenip temizleniyor...")
        threading.Thread(target=self._run_force_cleanup, args=(program,), daemon=True).start()

    def _run_force_cleanup(self, program: dict[str, Any]) -> None:
        result = ProgramInventoryService.force_cleanup(program)
        self.after(0, lambda: self._finish_force_cleanup(result))

    def _finish_force_cleanup(self, result: dict[str, Any]) -> None:
        self._show_action_result(result)
        if result.get("status") == "success":
            backup = result.get("backup_path", "")
            messagebox.showinfo(
                "Yedekli temizlik tamamlandi",
                f"Silinen ogeler geri alinabilmesi icin buraya yedeklendi:\n{backup}",
                parent=self,
            )
            self.refresh()
        else:
            self._select_program(self._selected_program)

    def _set_actions_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.uninstall_button.configure(state=state)
        self.modify_button.configure(state=state)
        self.residual_button.configure(state=state)

    def _show_action_result(self, result: dict[str, Any]) -> None:
        message = str(result.get("message", "Islem tamamlandi."))
        self.status_label.configure(text=message)
        if result.get("status") != "success":
            messagebox.showerror("Programlar", message, parent=self)

    @staticmethod
    def _number(value: Any) -> int:
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        size = float(max(size_bytes, 0))
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024 or unit == "TB":
                return f"{size:.1f} {unit}"
            size /= 1024
        return "Bilinmiyor"

    @staticmethod
    def _format_date(value: Any) -> str:
        raw = str(value or "").strip()
        if re_match := __import__("re").fullmatch(r"(\d{4})(\d{2})(\d{2})", raw):
            return f"{re_match.group(3)}.{re_match.group(2)}.{re_match.group(1)}"
        return raw or "Bilinmiyor"
