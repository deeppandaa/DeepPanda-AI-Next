"""Gumroad oturumunu tarayıcı üzerinden izleyen güvenli yardımcı modül."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


class GumroadBrowserAutopilot:
    """Kullanıcı açık Gumroad oturumunu tespit etmeye ve iş akışını hazırlamaya yardım eder."""

    def __init__(self, browser_profile: str | None = None):
        self.browser_profile = browser_profile
        self.base_url = "https://gumroad.com"

    def check_session_state(self) -> Dict[str, Any]:
        """Oturum durumunu güvenli bir şekilde bildirir; gerçek giriş doyrulamasını kullanıcı tarayıcıdan bekler."""
        return {
            "status": "not_authenticated",
            "authenticated": False,
            "url": self.base_url,
            "message": "Gumroad açık oturumu kullanılacak; bu akış kullanıcı tarayıcı doğrulaması gerektirir.",
            "checked_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

    def open_gumroad(self) -> Dict[str, Any]:
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["cmd", "/c", "start", "", self.base_url], shell=True)
            else:
                subprocess.Popen(["xdg-open", self.base_url])
            return {"status": "opened", "url": self.base_url}
        except Exception as exc:  # pragma: no cover
            return {"status": "error", "message": str(exc)}

    def create_product_flow(self, product_name: str, price: float, description: str) -> Dict[str, Any]:
        """Gumroad için ürün yükleme formu için hazırlanmış akış verisi döndürür."""
        return {
            "status": "ready",
            "product": {
                "name": product_name,
                "price": float(price),
                "description": description,
            },
            "steps": [
                "Gumroad sayfasını aç",
                "Ürün ekle ekranına git",
                "Dosyayı yükle",
                "Fiyat ve açıklama kontrol et",
                "Yayınla",
            ],
        }
