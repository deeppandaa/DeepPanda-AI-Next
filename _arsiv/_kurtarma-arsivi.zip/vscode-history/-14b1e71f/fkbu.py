from __future__ import annotations

import asyncio
import json
import unittest
from typing import Any

from app.plugins.analysis_workflow import (
    AnalysisWorkflowApprovalRequired,
    AnalysisWorkflowPlugin,
    AnalysisWorkflowProviderError,
)


class AnalysisWorkflowPluginTests(unittest.TestCase):
    document_id = "a" * 32

    class FakeGateway:
        def __init__(self, report: str | None = None, models: list[str] | None = None) -> None:
            self.report = report or json.dumps({
                "summary": "The file exports a startup entrypoint.",
                "findings": [{
                    "title": "Dynamic runtime selection",
                    "severity": "info",
                    "evidence": "main.ts:0042 imports eagerRuntime dynamically.",
                    "analysis": "The entrypoint selects a deferred or eager runtime based on configuration.",
                    "recommendation": "Review the runtime-specific configuration before enabling optional providers.",
                }],
            })
            self.models = models or ["gemma:7b", "deepseek-coder:6.7b"]
            self.calls: list[tuple[str, str, dict[str, Any]]] = []

        async def invoke(self, plugin_id: str, action: str, payload: dict[str, Any]) -> dict[str, Any]:
            self.calls.append((plugin_id, action, payload))
            if (plugin_id, action) == ("documents", "preview"):
                return {
                    "document_id": AnalysisWorkflowPluginTests.document_id,
                    "filename": "morluto-rea-main.ts",
                    "extension": ".ts",
                    "content": (
                        "Source: https://github.com/morluto/rea/blob/abc/src/main.ts\n"
                        "Repository: morluto/rea\nPath: src/main.ts\nGitHub blob: abc\n\n"
                        "export const entrypoint = true;\n"
                    ),
                    "indexed_characters": 140,
                }
            if (plugin_id, action) == ("ollama", "models"):
                return {"models": [{"name": name} for name in self.models]}
            if (plugin_id, action) == ("ollama", "chat"):
                return {"model": payload["model"], "message": {"content": self.report}}
            raise AssertionError(f"Unexpected gateway action: {plugin_id}/{action}")

    def test_analysis_requires_explicit_approval(self) -> None:
        plugin = AnalysisWorkflowPlugin(self.FakeGateway())  # type: ignore[arg-type]

        async def exercise() -> None:
            with self.assertRaises(AnalysisWorkflowApprovalRequired):
                await plugin.invoke("run", {
                    "document_id": self.document_id,
                    "question": "Review the entrypoint",
                    "model": "gemma:7b",
                })

        asyncio.run(exercise())

    def test_langgraph_inspects_analyzes_and_returns_attributed_report(self) -> None:
        gateway = self.FakeGateway()
        plugin = AnalysisWorkflowPlugin(gateway)  # type: ignore[arg-type]

        async def exercise() -> dict[str, Any]:
            return await plugin.invoke("run", {
                "approved": True,
                "document_id": self.document_id,
                "question": "Summarize the entrypoint and review trust boundaries.",
                "model": "gemma:7b",
            })

        report = asyncio.run(exercise())

        self.assertEqual(report["status"], "analyzed")
        self.assertTrue(report["static_only"])
        self.assertEqual(report["model"], "gemma:7b")
        self.assertEqual(report["source"]["document_id"], self.document_id)
        self.assertIn("github.com/morluto/rea/blob/abc/src/main.ts", report["source"]["url"])
        self.assertEqual(report["findings"][0]["severity"], "info")
        self.assertEqual([call[:2] for call in gateway.calls], [
            ("documents", "preview"), ("ollama", "models"), ("ollama", "chat"),
        ])
        system_prompt = gateway.calls[-1][2]["system_prompt"]
        self.assertIn("untrusted data", system_prompt)
        self.assertIn("execute code", system_prompt)
        self.assertIn("0006 export const entrypoint", gateway.calls[-1][2]["message"])

    def test_analysis_rejects_uninstalled_and_cloud_models(self) -> None:
        plugin = AnalysisWorkflowPlugin(self.FakeGateway(models=["gemma:7b", "remote:cloud"]))  # type: ignore[arg-type]

        async def exercise(model: str) -> None:
            with self.assertRaisesRegex(ValueError, "installed local"):
                await plugin.invoke("run", {
                    "approved": True,
                    "document_id": self.document_id,
                    "question": "Review the entrypoint",
                    "model": model,
                })

        asyncio.run(exercise("missing:latest"))
        asyncio.run(exercise("remote:cloud"))

    def test_invalid_model_report_is_rejected(self) -> None:
        plugin = AnalysisWorkflowPlugin(self.FakeGateway(report="not-json"))  # type: ignore[arg-type]

        async def exercise() -> None:
            with self.assertRaises(AnalysisWorkflowProviderError):
                await plugin.invoke("run", {
                    "approved": True,
                    "document_id": self.document_id,
                    "question": "Review the entrypoint",
                    "model": "gemma:7b",
                })

        asyncio.run(exercise())


if __name__ == "__main__":
    unittest.main()