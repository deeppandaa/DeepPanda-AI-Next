"""
Multi-User Management View - Kullanıcı hesapları ve izinleri.
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
from typing import Callable


class MultiUserManagementView:
    """Kullanıcı hesapları ve rol yönetimi."""

    def __init__(self, parent: ctk.CTkFrame, on_action: Callable = None):
        self.parent = parent
        self.on_action = on_action

        self.frame = ctk.CTkFrame(parent, fg_color="transparent")
        self.frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Başlık
        title_label = ctk.CTkLabel(
            self.frame, text="👥 Kullanıcı Yönetimi", font=("Segoe UI", 20, "bold")
        )
        title_label.pack(pady=(0, 15))

        # Yeni kullanıcı formu
        self._create_user_form()

        # Kullanıcı listesi
        self._create_user_table()

    def _create_user_form(self):
        """Yeni kullanıcı oluşturma formu."""
        form_frame = ctk.CTkFrame(self.frame, fg_color="#2d2d2d")
        form_frame.pack(fill="x", pady=(0, 15), padx=0)

        form_label = ctk.CTkLabel(form_frame, text="Yeni Kullanıcı Oluştur", font=("Segoe UI", 12, "bold"))
        form_label.pack(pady=(10, 10))

        # Username
        ctk.CTkLabel(form_frame, text="Kullanıcı Adı:").pack(anchor="w", padx=20, pady=(5, 0))
        self.username_entry = ctk.CTkEntry(form_frame, width=300)
        self.username_entry.pack(padx=20, pady=(0, 10))

        # Password
        ctk.CTkLabel(form_frame, text="Parola:").pack(anchor="w", padx=20, pady=(5, 0))
        self.password_entry = ctk.CTkEntry(form_frame, width=300, show="*")
        self.password_entry.pack(padx=20, pady=(0, 10))

        # Role
        ctk.CTkLabel(form_frame, text="Rol:").pack(anchor="w", padx=20, pady=(5, 0))
        self.role_combo = ctk.CTkComboBox(form_frame, values=["admin", "operator", "viewer"], width=300)
        self.role_combo.set("viewer")
        self.role_combo.pack(padx=20, pady=(0, 15))

        # Buttons
        btn_frame = ctk.CTkFrame(form_frame)
        btn_frame.pack(fill="x", padx=20, pady=(0, 15))

        ctk.CTkButton(
            btn_frame,
            text="✅ Kullanıcı Oluştur",
            command=lambda: self.on_action("create_user") if self.on_action else None,
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            btn_frame,
            text="🔄 Temizle",
            command=self._clear_form,
        ).pack(side="left", padx=5)

    def _create_user_table(self):
        """Kullanıcı listesi tablosu."""
        table_label = ctk.CTkLabel(self.frame, text="Mevcut Kullanıcılar", font=("Segoe UI", 12, "bold"))
        table_label.pack(anchor="w", pady=(15, 5))

        tree_frame = ctk.CTkFrame(self.frame)
        tree_frame.pack(fill="both", expand=True)

        columns = ("Kullanıcı Adı", "Rol", "Durum", "Son Giriş", "İşlemler")
        self.tree = ttk.Treeview(tree_frame, columns=columns, height=15)

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)

        self.tree.heading("#0", text="ID")
        self.tree.column("#0", width=30)

        self.tree.pack(fill="both", expand=True)

        # Örnek veriler
        sample_users = [
            (1, "admin", "✓ Aktif", "2026-08-29 14:00", "Gümrük İdari"),
            (2, "operator", "✓ Aktif", "2026-08-28 10:30", "Düzenle Sil"),
            (3, "viewer", "✓ Aktif", "2026-08-27 16:45", "Düzenle Sil"),
        ]

        for user in sample_users:
            self.tree.insert("", "end", text=user[0], values=user[1:])

    def _clear_form(self):
        """Formu temizle."""
        self.username_entry.delete(0, "end")
        self.password_entry.delete(0, "end")
        self.role_combo.set("viewer")
