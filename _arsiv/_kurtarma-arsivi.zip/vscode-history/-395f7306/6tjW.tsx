import { Activity, Building2, ClipboardList, Clock3, Laptop, Settings2, ShieldCheck, Users } from "lucide-react";
import { requireSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import CustomersClient from "./customers-client";

type CustomerItem = {
  id: string;
  name: string;
  contact_email: string | null;
  contact_phone: string | null;
  notes: string;
  created_at: string;
  device_count: number;
};

export default async function CustomersPage() {
  const session = await requireSession();
  const result = await tenantQuery<CustomerItem>(
    session.organizationId,
    `SELECT c.id, c.name, c.contact_email, c.contact_phone, c.notes, c.created_at,
            count(d.id)::int AS device_count
     FROM customers c
     LEFT JOIN devices d ON d.customer_id = c.id
     WHERE c.organization_id = $1
     GROUP BY c.id
     ORDER BY c.name`
  );

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <ShieldCheck size={22} />
          <span>
            DeepPanda<br />
            <b>CONTROL PANEL</b>
          </span>
        </div>
        <nav>
          <a href="/dashboard"><Activity size={18} /> Operasyon</a>
          <a href="/dashboard/devices"><Laptop size={18} /> Cihazlar</a>
          <a className="active" href="/dashboard/customers"><Building2 size={18} /> Müşteriler</a>
          <a href="/dashboard/tickets"><ClipboardList size={18} /> İş Emirleri</a>
          <a href="/dashboard/users"><Users size={18} /> Kullanıcı Yönetimi</a>
          <a href="/dashboard/audit"><Clock3 size={18} /> Denetim kayıtları</a>
          <a href="/dashboard/manage"><Settings2 size={18} /> Yönetim</a>
        </nav>
        <div className="account-block">
          <span>{session.name}</span>
          <small>{session.role} · {session.email}</small>
          <form action="/api/auth/logout" method="post"><button>Çıkış</button></form>
        </div>
      </aside>
      <section className="workspace">
        <header className="workspace-header">
          <div>
            <p className="eyebrow">MÜŞTERİ HİZMETLERİ & PORTFÖY</p>
            <h1>Müşteri Yönetimi</h1>
            <p>Hizmet verilen kurumlar, iletişim bilgileri, cihaz sayıları ve özel operasyon notları.</p>
          </div>
          <span className="system-state"><i /> Müşteri Portföyü Aktif</span>
        </header>
        <CustomersClient initialCustomers={result.rows} role={session.role} />
      </section>
    </main>
  );
}
