$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = Join-Path $Root '.venv\Scripts\python.exe'
$BackupRoot = Join-Path $Root 'data\memory\backups'
$WeeklyLog = Join-Path $Root '.job-artifacts\weekly-maintenance.log'
$HealthUrl = 'http://127.0.0.1:8787/api/health'
$ReportUrl = 'http://127.0.0.1:8787/api/health/report'

function Write-Log {
    param([string]$Message)
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $WeeklyLog) | Out-Null
    $stamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$stamp] $Message"
    Add-Content -Path $WeeklyLog -Value $line -Encoding UTF8
    Write-Host $line
}

function Test-Health {
    try {
        $response = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 5
        return ($response.StatusCode -ge 200 -and $response.StatusCode -lt 400)
    }
    catch {
        return $false
    }
}

Write-Log 'Weekly maintenance started.'

if (-not (Test-Path $Python)) {
    throw "Python venv not found: $Python"
}

if (-not (Test-Health)) {
    Write-Log 'Health endpoint unavailable; trying launcher restart.'
    $Launcher = Join-Path $Root 'Start-LocalQwenAgent.ps1'
    if (Test-Path $Launcher) {
        & $Launcher *>$null
        Start-Sleep -Seconds 5
    }
}

if (Test-Health) {
    Write-Log 'Health endpoint ok.'
    try {
        $report = Invoke-RestMethod -Uri $ReportUrl -Method Get -UseBasicParsing -TimeoutSec 10
        if ($report.backup_root) {
            Write-Log "Backup root: $($report.backup_root)"
        }
    }
    catch {
        Write-Log "Health report unavailable; continuing with health endpoint only. $($_.Exception.Message)"
    }
}
else {
    Write-Log 'Health endpoint still unavailable after restart.'
}

New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
$sourceDb = Join-Path $Root 'data\memory\memory.db'
$backupStamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
$destDb = Join-Path $BackupRoot ("memory-$backupStamp.db")

if (Test-Path $sourceDb) {
    Copy-Item -Path $sourceDb -Destination $destDb -Force
    Write-Log "Database backup created: $destDb"
}
else {
    Write-Log "No memory database found at $sourceDb"
}

& $Python -c "import sys; sys.path.insert(0, r'$Root'); import app; pruned = app.prune_chat_history(); print(f'pruned={pruned}')" *> $null
Write-Log 'Chat retention policy applied.'

Get-ChildItem -Path $Root -Recurse -File -Force -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -like '*\.job-artifacts\*' -or $_.FullName -like '*\.media-work\*'
    } |
    Where-Object {
        $_.LastWriteTime -lt (Get-Date).AddDays(-30)
    } |
    ForEach-Object {
        try {
            Remove-Item $_.FullName -Force
            Write-Log "Removed stale artifact: $($_.FullName)"
        }
        catch {
            Write-Log "Could not remove stale artifact: $($_.FullName)"
        }
    }

Write-Log 'Weekly maintenance finished.'
