import tempfile
import unittest
from pathlib import Path

from services.policy_engine_service import PolicyEngineService


class PolicyEngineServiceTests(unittest.TestCase):
    def test_structured_policy_triggers_and_cooldown_suppresses_repeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            service = PolicyEngineService(Path(tmp) / "state.json")
            snapshot = {"disk": {"max_usage_percent": 95}}
            policy = [{"id": "disk", "name": "Disk", "metric": "disk.max_usage_percent", "operator": "gte", "threshold": 90, "severity": "high", "cooldown_seconds": 3600, "recommendation": "Clean"}]
            first = service.evaluate(snapshot, policy, now=1000)
            self.assertEqual(1, len(first["active_alerts"]))
            self.assertEqual(35, first["risk_score"])
            second = service.evaluate(snapshot, policy, now=1100)
            self.assertEqual(0, len(second["active_alerts"]))
            self.assertTrue(second["alerts"][0]["suppressed"])

    def test_missing_metric_does_not_trigger(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = PolicyEngineService(Path(tmp) / "state.json").evaluate({}, now=1000)
            self.assertEqual([], result["alerts"])

    def test_invalid_operator_is_rejected_without_eval(self):
        with tempfile.TemporaryDirectory() as tmp:
            policy = [{"id": "bad", "name": "Bad", "metric": "x", "operator": "exec", "threshold": 1, "severity": "high", "cooldown_seconds": 0, "recommendation": "None"}]
            with self.assertRaises(ValueError):
                PolicyEngineService(Path(tmp) / "state.json").evaluate({"x": 2}, policy)


if __name__ == "__main__":
    unittest.main()
