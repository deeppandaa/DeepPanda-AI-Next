import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from services.lockhunter_service import LockHunterService


class LockHunterServiceTests(unittest.TestCase):
    @patch("services.lockhunter_service.subprocess.Popen")
    def test_installed_copy_is_launched_without_opening_download_page(self, popen):
        with tempfile.TemporaryDirectory() as temp_dir:
            executable = Path(temp_dir) / "LockHunter.exe"
            executable.write_bytes(b"external-tool")
            popen.return_value = Mock(pid=42)
            with (
                patch.object(LockHunterService, "_candidate_paths", return_value=(executable,)),
                patch("services.lockhunter_service.webbrowser.open") as browser,
            ):
                result = LockHunterService.launch_or_download()

        self.assertEqual(result["status"], "starting")
        popen.assert_called_once_with([str(executable)], cwd=str(executable.parent), shell=False)
        browser.assert_not_called()

    def test_missing_copy_opens_only_official_download_page(self):
        missing = Path("missing-lockhunter.exe")
        with (
            patch.object(LockHunterService, "_candidate_paths", return_value=(missing,)),
            patch("services.lockhunter_service.webbrowser.open", return_value=True) as browser,
            patch("services.lockhunter_service.subprocess.Popen") as popen,
        ):
            result = LockHunterService.launch_or_download()

        self.assertEqual(result["status"], "download")
        browser.assert_called_once_with(LockHunterService.OFFICIAL_DOWNLOAD_URL)
        popen.assert_not_called()


if __name__ == "__main__":
    unittest.main()