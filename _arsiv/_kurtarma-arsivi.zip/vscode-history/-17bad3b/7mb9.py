import json
import tempfile
import unittest
from pathlib import Path

from llama_cpp_windows_ollama_bridge.runtime import BridgeError, LlamaCppServer, discover_ollama_model


class RuntimeTests(unittest.TestCase):
    def test_discovers_gguf_blob_from_ollama_manifest(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            digest = "a" * 64
            manifest = root / "manifests" / "registry.ollama.ai" / "library" / "demo" / "latest"
            manifest.parent.mkdir(parents=True)
            manifest.write_text(json.dumps({"layers": [{
                "mediaType": "application/vnd.ollama.image.model",
                "digest": f"sha256:{digest}",
            }]}), encoding="utf-8")
            blob = root / "blobs" / f"sha256-{digest}"
            blob.parent.mkdir()
            blob.write_bytes(b"GGUFtest")

            self.assertEqual(discover_ollama_model("demo:latest", root), blob)

    def test_rejects_non_gguf_model_layer(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            digest = "b" * 64
            manifest = root / "manifests" / "registry.ollama.ai" / "library" / "demo" / "latest"
            manifest.parent.mkdir(parents=True)
            manifest.write_text(json.dumps({"layers": [{
                "mediaType": "application/vnd.ollama.image.model",
                "digest": f"sha256:{digest}",
            }]}), encoding="utf-8")
            blob = root / "blobs" / f"sha256-{digest}"
            blob.parent.mkdir()
            blob.write_bytes(b"NOPE")

            with self.assertRaisesRegex(BridgeError, "not a GGUF"):
                discover_ollama_model("demo", root)

    def test_server_command_is_loopback_and_api_key_protected(self):
        server = LlamaCppServer(Path("llama-server.exe"), Path("model.gguf"))
        command = server.command()

        self.assertEqual(command[command.index("--host") + 1], "127.0.0.1")
        self.assertEqual(command[command.index("--api-key") + 1], server.api_key)
        self.assertNotIn("0.0.0.0", command)


if __name__ == "__main__":
    unittest.main()
