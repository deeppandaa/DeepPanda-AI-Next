@echo off
if not exist C:\Users\flc\AppData\Local\DeepPandaLegacy mkdir C:\Users\flc\AppData\Local\DeepPandaLegacy
copy /y Y:\vm-heartbeat-settings.json C:\Users\flc\AppData\Local\DeepPandaLegacy\settings.json
type C:\Users\flc\AppData\Local\DeepPandaLegacy\settings.json | findstr control_plane_url
