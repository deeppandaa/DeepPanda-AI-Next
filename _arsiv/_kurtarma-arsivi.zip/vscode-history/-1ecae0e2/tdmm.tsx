"use client";

import { FormEvent, useState } from "react";
import { AlertTriangle, Building2, CheckCircle2, Laptop, Search, ShieldAlert, Trash2, UserX, X } from "lucide-react";

type DeviceItem = {
  id: string;
  hostname: string;
  installation_id: string;
  os_name: string;
  app_version: string;
  tailscale_ip: string | null;
  online: boolean;
  last_seen_at: string | null;
  risk_score: number;
  customer_id: string | null;
  customer_name: string | null;
};

type Option = { id: string; name: string };
type Notice = { kind: "ok" | "error"; text: string } | null;

async function requestJson(url: string, init?: RequestInit) {
  const response = await fetch(url, init);
  const body = await response.json();
  if (!response.ok) throw new Error(body.message ?? "İşlem tamamlanamadı.");
  return body;
}

export default function DevicesClient({
  initialDevices,
  customers,
  role,
}: {
  initialDevices: DeviceItem[];
  customers: Option[];
  role: string;
}) {
  const [devices, setDevices] = useState<DeviceItem[]>(initialDevices);
  const [notice, setNotice] = useState<Notice>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [deleteTarget, setDeleteTarget] = useState<DeviceItem | null>(null);
  const [confirmationHostname, setConfirmationHostname] = useState("");
  const [password, setPassword] = useState("");

  const canDelete = ["owner", "admin"].includes(role);
  const canAssign = ["owner", "admin", "technician"].includes(role);

  async function refreshDevices() {
    try {
      const data = await requestJson("/api/devices");
      setDevices(data.devices);
    } catch {
      // Fallback
    }
  }

  async function handleAssignCustomer(deviceId: string, customerId: string) {
    if (!canAssign) return;
    setBusy(true);
    try {
      await requestJson(`/api/devices/${deviceId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ customerId: customerId || null }),
      });
      const selectedCustomer = customers.find((c) => c.id === customerId);
      setNotice({
        kind: "ok",
        text: `Cihaz müşteri ataması güncellendi (${selectedCustomer ? selectedCustomer.name : "Müşteri kaldırıldı"}).`,
      });
      setDevices((prev) =>
        prev.map((d) =>
          d.id === deviceId
            ? { ...d, customer_id: customerId || null, customer_name: selectedCustomer ? selectedCustomer.name : null }
            : d
        )
      );
    } catch (err) {
      setNotice({ kind: "error", text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  async function handleRemoveDevice(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!deleteTarget || !canDelete) return;
    setBusy(true);
    try {
      await requestJson(`/api/devices/${deleteTarget.id}`, {
        method: "DELETE",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          confirmationHostname,
          password,
        }),
      });
      setNotice({ kind: "ok", text: `${deleteTarget.hostname} kaldırıldı.` });
      setDevices((prev) => prev.filter((d) => d.id !== deleteTarget.id));
      setDeleteTarget(null);
      setConfirmationHostname("");
      setPassword("");
    } catch (err) {
      setNotice({ kind: "error", text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  const filtered = devices.filter((d) => {
    const matchesSearch =
      d.hostname.toLowerCase().includes(search.toLowerCase()) ||
      (d.customer_name && d.customer_name.toLowerCase().includes(search.toLowerCase())) ||
      (d.tailscale_ip && d.tailscale_ip.includes(search)) ||
      (d.app_version && d.app_version.includes(search));

    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "online" && d.online) ||
      (statusFilter === "offline" && !d.online) ||
      (statusFilter === "high_risk" && d.risk_score >= 70);

    return matchesSearch && matchesStatus;
  });

  const onlineCount = devices.filter((d) => d.online).length;
  const highRiskCount = devices.filter((d) => d.risk_score >= 70).length;

  return (
    <div className="devices-container">
      {notice && (
        <div className={`manage-notice ${notice.kind}`}>
          {notice.kind === "ok" ? <CheckCircle2 size={18} /> : <UserX size={18} />}
          <span>{notice.text}</span>
        </div>
      )}

      <div className="metrics-grid">
        <article className="metric">
          <div className="metric-icon"><Laptop /></div>
          <p>Toplam Filo Cihazı</p>
          <strong>{devices.length}</strong>
          <span>Kayıtlı sistem ajanı</span>
        </article>
        <article className="metric">
          <div className="metric-icon"><Laptop /></div>
          <p>Çevrimiçi Cihazlar</p>
          <strong>{onlineCount}</strong>
          <span>Aktif heartbeat veren cihazlar</span>
        </article>
        <article className="metric metric-warning">
          <div className="metric-icon"><AlertTriangle /></div>
          <p>Yüksek Riskli Cihazlar</p>
          <strong>{highRiskCount}</strong>
          <span>Risk skoru ≥ 70 olan cihazlar</span>
        </article>
      </div>

      <div className="management-grid">
        <section className="manage-panel manage-wide">
          <div className="manage-title">
            <Laptop size={22} />
            <div>
              <h2>Cihaz Envanter Tablosu</h2>
              <p>Bağlantı durumu, müşteri eşleştirmesi, sürüm ve risk puanı.</p>
            </div>
          </div>

          <div className="ticket-toolbar" style={{ marginTop: "14px", padding: 0, border: 0 }}>
            <label style={{ margin: 0 }}>
              <Search size={16} />
              <input
                type="text"
                placeholder="Cihaz adı, müşteri veya Tailscale IP ile ara..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{ border: "1px solid #bdc8c7", padding: "8px 12px", background: "#fbfcfb", outline: "none", fontSize: "13px" }}
            >
              <option value="all">Tüm Durumlar</option>
              <option value="online">Çevrimiçi</option>
              <option value="offline">Çevrimdışı</option>
              <option value="high_risk">Yüksek Risk Skoru (≥70)</option>
            </select>
          </div>

          <div className="device-table" style={{ marginTop: "16px" }}>
            <div className="table-row table-header" style={{ gridTemplateColumns: "1.2fr 1.3fr .8fr 1fr .5fr .8fr auto" }}>
              <span>Cihaz Adı</span>
              <span>Atanmış Müşteri</span>
              <span>Ajan Sürümü</span>
              <span>Tailscale IP</span>
              <span>Risk</span>
              <span>Durum</span>
              <span>İşlem</span>
            </div>

            {filtered.length === 0 && (
              <div className="empty-state">Arama kriterlerine uygun cihaz bulunamadı.</div>
            )}

            {filtered.map((device) => (
              <div
                key={device.id}
                className="table-row"
                style={{ gridTemplateColumns: "1.2fr 1.3fr .8fr 1fr .5fr .8fr auto", padding: "12px 14px" }}
              >
                <strong>{device.hostname}</strong>

                <div>
                  {canAssign ? (
                    <select
                      value={device.customer_id ?? ""}
                      onChange={(e) => handleAssignCustomer(device.id, e.target.value)}
                      disabled={busy}
                      style={{ border: "1px solid #c0ccc9", fontSize: "12px", padding: "4px 6px", width: "100%" }}
                    >
                      <option value="">Atanmamış</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  ) : (
                    <span>{device.customer_name ?? "Atanmamış"}</span>
                  )}
                </div>

                <span>{device.app_version || "—"}</span>
                <code>{device.tailscale_ip ?? "—"}</code>
                <span className={device.risk_score >= 70 ? "risk-high" : "risk-normal"}>
                  {device.risk_score}
                </span>
                <span className={device.online ? "online" : "offline"}>
                  <i /> {device.online ? "Çevrimiçi" : "Çevrimdışı"}
                </span>

                <div>
                  {canDelete && (
                    <button
                      onClick={() => setDeleteTarget(device)}
                      disabled={busy}
                      title="Cihazı Kaldır"
                      style={{ border: 0, background: "#f7e8e8", color: "var(--red)", padding: "6px 9px" }}
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {deleteTarget && (
        <div className="dialog-backdrop">
          <div className="delete-dialog">
            <button className="dialog-close" onClick={() => setDeleteTarget(null)}><X size={18} /></button>
            <ShieldAlert size={28} />
            <h2>Cihazı Kalıcı Olarak Kaldır</h2>
            <p>
              <strong>{deleteTarget.hostname}</strong> cihazı organizasyondan kaldırılacaktır. Onaylamak için cihaz adını ve hesap şifrenizi girin.
            </p>
            <form className="manage-form" onSubmit={handleRemoveDevice} style={{ marginTop: "16px" }}>
              <label>
                Cihaz Adı Doğrulaması
                <input
                  type="text"
                  required
                  placeholder={deleteTarget.hostname}
                  value={confirmationHostname}
                  onChange={(e) => setConfirmationHostname(e.target.value)}
                />
              </label>
              <label>
                Hesap Parolanız
                <input
                  type="password"
                  required
                  placeholder="Hesap şifreniz"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </label>
              <button
                type="submit"
                className="danger-button"
                disabled={busy || confirmationHostname !== deleteTarget.hostname || !password}
              >
                {busy ? "Kaldırılıyor..." : "Cihazı Kaldır"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
