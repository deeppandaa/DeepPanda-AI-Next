import { Activity, AlertTriangle, Building2, ClipboardList, Clock3, Laptop, Settings2, ShieldCheck, Users } from "lucide-react";
import { requireSession } from "@/lib/auth";
import { tenantQuery } from "@/lib/db";
import { LiveRefresh } from "./live-refresh";

type Summary = { devices: string; online: string; customers: string; technicians: string; open_sessions: string; open_tickets: string };
type Device = { id: string; hostname: string; customer_name: string | null; app_version: string; tailscale_ip: string | null; online: boolean; risk_score: number; last_seen_at: string | null };
type Event = { id: string; action: string; target_type: string; target_id: string; created_at: string; actor_name: string | null; detail: { detail?: string; severity?: string; status?: string } };

export default async function DashboardPage() {
  const session = await requireSession();
  const [summaryResult, devicesResult, auditResult] = await Promise.all([
    tenantQuery<Summary>(session.organizationId, `SELECT
      count(*)::text AS devices,
      count(*) FILTER (WHERE online AND last_seen_at > now() - interval '3 minutes')::text AS online,
      (SELECT count(*)::text FROM customers WHERE organization_id=$1) AS customers,
      (SELECT count(*)::text FROM users WHERE organization_id=$1 AND role='technician' AND active) AS technicians,
      (SELECT count(*)::text FROM support_sessions WHERE organization_id=$1 AND status IN ('requested','approved','active')) AS open_sessions,
      (SELECT count(*)::text FROM service_tickets WHERE organization_id=$1 AND status NOT IN ('resolved','closed','cancelled')) AS open_tickets
      FROM devices WHERE organization_id=$1`),
    tenantQuery<Device>(session.organizationId, `SELECT d.id,d.hostname,c.name customer_name,d.app_version,
      host(d.tailscale_ip) tailscale_ip,
      (d.online AND d.last_seen_at > now() - interval '3 minutes') online,d.risk_score,d.last_seen_at
      FROM devices d LEFT JOIN customers c ON c.id=d.customer_id
      WHERE d.organization_id=$1 ORDER BY d.online DESC,d.risk_score DESC,d.last_seen_at DESC NULLS LAST LIMIT 8`),
    tenantQuery<Event>(session.organizationId, `SELECT a.id::text,a.action,a.target_type,a.target_id,a.created_at,a.detail,u.name actor_name
      FROM audit_events a LEFT JOIN users u ON u.id=a.actor_user_id
      WHERE a.organization_id=$1 ORDER BY a.created_at DESC LIMIT 8`),
  ]);
  const summary = summaryResult.rows[0] ?? { devices: "0", online: "0", customers: "0", technicians: "0", open_sessions: "0", open_tickets: "0" };

  return (
    <main className="app-shell">
      <LiveRefresh />
      <aside className="sidebar">
        <div className="sidebar-brand"><ShieldCheck size={22} /><span>DeepPanda<br /><b>CONTROL PANEL</b></span></div>
        <nav>
          <a className="active" href="/dashboard"><Activity size={18} /> Operasyon</a>
          <a href="/dashboard"><Laptop size={18} /> Cihazlar</a>
          <a href="/dashboard"><Building2 size={18} /> Müşteriler</a>
          <a href="/dashboard/tickets"><ClipboardList size={18} /> İş Emirleri</a>
          <a href="/dashboard/users"><Users size={18} /> Kullanıcı Yönetimi</a>
          <a href="/dashboard"><Clock3 size={18} /> Denetim kayıtları</a>
          <a href="/dashboard/manage"><Settings2 size={18} /> Yönetim</a>
        </nav>
        <div className="account-block"><span>{session.name}</span><small>{session.role} · {session.email}</small><form action="/api/auth/logout" method="post"><button>Çıkış</button></form></div>
      </aside>
      <section className="workspace">
        <header className="workspace-header"><div><p className="eyebrow">CANLI OPERASYON</p><h1>Filo özeti</h1><p>Son üç dakikadaki cihaz telemetrisi ve destek hareketleri.</p></div><span className="system-state"><i /> Sistem çalışıyor</span></header>
        <div className="metrics-grid">
          <Metric label="Toplam cihaz" value={summary.devices} detail={`${summary.online} çevrimiçi`} icon={<Laptop />} />
          <Metric label="Müşteri" value={summary.customers} detail="Aktif organizasyon kapsamı" icon={<Building2 />} />
          <Metric label="Teknisyen" value={summary.technicians} detail={`${summary.open_tickets} iş emri · ${summary.open_sessions} oturum`} icon={<Users />} />
          <Metric label="Riskli cihaz" value={String(devicesResult.rows.filter((d) => d.risk_score >= 70).length)} detail="Skor ≥ 70" icon={<AlertTriangle />} warning />
        </div>
        <section className="data-section">
          <div className="section-heading"><div><h2>Cihaz durumu</h2><p>Bağlantı, sürüm ve risk görünümü</p></div><button className="quiet-button">Tüm cihazlar</button></div>
          <div className="device-table">
            <div className="table-row table-header"><span>Cihaz</span><span>Müşteri</span><span>Sürüm</span><span>Tailscale</span><span>Risk</span><span>Durum</span></div>
            {devicesResult.rows.length === 0 && <div className="empty-state">Henüz cihaz heartbeat verisi gelmedi.</div>}
            {devicesResult.rows.map((device) => <div className="table-row" key={device.id}><strong>{device.hostname}</strong><span>{device.customer_name ?? "Atanmamış"}</span><span>{device.app_version || "—"}</span><code>{device.tailscale_ip ?? "—"}</code><span className={device.risk_score >= 70 ? "risk-high" : "risk-normal"}>{device.risk_score}</span><span className={device.online ? "online" : "offline"}><i />{device.online ? "Çevrimiçi" : "Çevrimdışı"}</span></div>)}
          </div>
        </section>
        <section className="audit-section"><div className="section-heading"><div><h2>Son hareketler</h2><p>Değiştirilemez operasyon izi için başlangıç görünümü</p></div></div><div className="audit-list">{auditResult.rows.length === 0 && <div className="empty-state">Henüz denetim kaydı yok.</div>}{auditResult.rows.map((event) => <div key={event.id}><span className={`audit-dot audit-${event.detail.severity ?? "info"}`} /><p><strong>{event.action}</strong><small>{event.detail.detail || `${event.actor_name ?? "Sistem"} · ${event.target_type} ${event.target_id}`}</small></p><span className={`event-status status-${event.detail.status ?? "info"}`}>{event.detail.status === "detected" ? "Sorun" : event.detail.status === "repairing" ? "Düzeltiliyor" : event.detail.status === "resolved" ? "Çözüldü" : "Kayıt"}</span><time>{new Date(event.created_at).toLocaleTimeString("tr-TR")}</time></div>)}</div></section>
      </section>
    </main>
  );
}

function Metric({ label, value, detail, icon, warning = false }: { label: string; value: string; detail: string; icon: React.ReactNode; warning?: boolean }) {
  return <article className={`metric ${warning ? "metric-warning" : ""}`}><div className="metric-icon">{icon}</div><p>{label}</p><strong>{value}</strong><span>{detail}</span></article>;
}
